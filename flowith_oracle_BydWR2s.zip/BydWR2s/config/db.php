<?php
/**
 * Database Configuration File
 *
 * This file contains configuration settings for connecting to the database.
 * In a production environment, these values would typically be stored in environment variables
 * or in a configuration file outside of the web root.
 *
 * These settings should be updated with your actual database credentials.
 * IMPORTANT: Avoid hardcoding sensitive credentials directly in production code.
 * Use environment variables or a secure configuration loading mechanism.
 */

// Database settings - REPLACE WITH YOUR ACTUAL CREDENTIALS or load from environment variables
// Esempio: Ottenere da variabili d'ambiente
$db_host = getenv('DB_HOST') ?: 'localhost'; // Host del database
$db_name = getenv('DB_NAME') ?: 'prodotto_recensioni'; // Nome del database
$db_user = getenv('DB_USER') ?: 'db_user'; // Nome utente del database - placeholder, user should fill this
$db_pass = getenv('DB_PASS') ?: 'db_password'; // Password del database - placeholder, user should fill this
$db_charset = 'utf8mb4'; // Set di caratteri

// PDO options for the connection
$db_options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Modalità di gestione degli errori (eccezioni)
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Modalità di fetch predefinita (array associativo)
    PDO::ATTR_EMULATE_PREPARES   => false,                // Disabilita emulazione prepared statements (più sicuro)
];

// Define constants if not using environment variables
if (!getenv('DB_HOST')) { // Check one to assume others might not be set via env
    define('DB_HOST', $db_host);
    define('DB_NAME', $db_name);
    define('DB_USER', $db_user); // User should replace 'db_user'
    define('DB_PASS', $db_pass); // User should replace 'db_password'
} else {
    // Use environment variable values if DB_HOST is set via getenv
    define('DB_HOST', getenv('DB_HOST'));
    define('DB_NAME', getenv('DB_NAME'));
    define('DB_USER', getenv('DB_USER'));
    define('DB_PASS', getenv('DB_PASS'));
}

define('DB_CHARSET', $db_charset);
define('DB_OPTIONS', serialize($db_options)); // Serialize to store in a constant


/**
 * Establishes a database connection using PDO.
 *
 * @return PDO A PDO instance representing a connection to the database.
 * @throws PDOException If the connection fails.
 */
function connectDB() {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = unserialize(DB_OPTIONS);

    try {
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        // In un ambiente di produzione, non mostrare l'errore direttamente all'utente.
        // Registrare l'errore in un file di log e mostrare un messaggio generico.
        error_log("Errore di connessione al database: " . $e->getMessage());
        // Throw a new exception or handle gracefully
        throw new PDOException("Impossibile connettersi al database. Verificare la configurazione e riprovare più tardi.", (int)$e->getCode());
    }
}

/**
 * Helper function to execute a SQL query with prepared statements.
 *
 * @param string $sql The SQL query string.
 * @param array $params An associative array of parameters to bind (optional).
 * @param bool $fetch_all Whether to fetch all results (default true) or just one.
 * @return array|mixed|false Returns an array of results for SELECT, the number of affected rows for INSERT/UPDATE/DELETE,
 *                          a single row for fetch_all=false SELECT, or false on failure.
 * @throws PDOException On query execution failure.
 */
function executeQuery($sql, $params = [], $fetch_all = true) {
    try {
        $pdo = connectDB();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        $sql_parts = explode(' ', trim(strtoupper($sql)));
        $command = $sql_parts[0];

        if ($command === 'SELECT' || (isset($sql_parts[1]) && $command === 'SHOW') || (isset($sql_parts[1]) && $command === 'DESCRIBE')) {
            return $fetch_all ? $stmt->fetchAll() : $stmt->fetch();
        } else {
            return $stmt->rowCount(); // Return number of affected rows for INSERT, UPDATE, DELETE
        }
    } catch (PDOException $e) {
        error_log("Database query error: " . $e->getMessage() . " SQL: " . $sql . " Params: " . json_encode($params));
        // Rethrow the exception to be caught by calling code if needed
        throw $e; // Throw the original exception for better debugging caller side
    }
}

/**
 * Generate SQL CREATE TABLE statements for the application's database schema.
 * This function is intended for initial setup or migrations.
 * It doesn't execute SQL, but returns the statements as a string or array.
 *
 * @return array An array of SQL CREATE TABLE statements.
 */
function getDatabaseSchemaSQL() {
    return [
        "CREATE TABLE IF NOT EXISTS Categories (
            category_id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL UNIQUE, /* Added UNIQUE constraint */
            description TEXT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS Products (
            product_id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL, /* Consider adding UNIQUE or composite UNIQUE */
            description TEXT NULL,
            category_id INT NULL,
            image_url VARCHAR(255) NULL,
            average_rating DECIMAL(3,2) NULL, /* Changed: Removed DEFAULT 0.00 */
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES Categories(category_id) ON DELETE SET NULL ON UPDATE CASCADE
            /* Consider Adding a UNIQUE constraint on name if product names should be unique globally */
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS Users (
            user_id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) UNIQUE NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(50) DEFAULT 'user' COMMENT 'e.g., user, admin',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_username (username),
            INDEX idx_email (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS Reviews (
            review_id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            user_id INT NOT NULL,
            rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
            comment_text TEXT NOT NULL,
            pros TEXT NULL,
            cons TEXT NULL,
            is_approved BOOLEAN DEFAULT FALSE, /* MySQL 0 is FALSE, 1 is TRUE */
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES Products(product_id) ON DELETE CASCADE ON UPDATE CASCADE,
            FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE ON UPDATE CASCADE,
            UNIQUE KEY unique_review (product_id, user_id), -- Prevent multiple reviews from the same user on the same product
            INDEX idx_product_id (product_id),
            INDEX idx_user_id (user_id),
            INDEX idx_is_approved (is_approved)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS Review_Votes (
            vote_id INT AUTO_INCREMENT PRIMARY KEY,
            review_id INT NOT NULL,
            user_id INT NOT NULL,
            vote_type ENUM('up', 'down') NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (review_id) REFERENCES Reviews(review_id) ON DELETE CASCADE ON UPDATE CASCADE,
            FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE ON UPDATE CASCADE,
            UNIQUE KEY unique_vote (review_id, user_id) -- Previene voti multipli dallo stesso utente sulla stessa recensione
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
         "CREATE TABLE IF NOT EXISTS Password_Resets (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            selector VARCHAR(32) NOT NULL UNIQUE, /* Public part of the token */
            hashed_verifier VARCHAR(255) NOT NULL, /* Hashed secret part of the token */
            expires_at DATETIME NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
         "CREATE INDEX idx_password_resets_selector ON Password_Resets (selector);",
         "CREATE INDEX idx_password_resets_user_id ON Password_Resets (user_id);"
    ];
}

/**
 * Executes the SQL schema creation statements.
 * This function can be used to set up the database tables programmatically.
 * BE CAREFUL: Running this on an existing database might encounter errors
 * if tables already exist or constraints conflict.
 *
 * @return bool True if all statements executed without throwing an exception, false otherwise.
 * @throws PDOException if connection fails or a statement execution fails critically.
 */
function createDatabaseSchema() {
    $sqlStatements = getDatabaseSchemaSQL();
    $pdo = null; // Initialize pdo to null
    try {
        $pdo = connectDB();
        $pdo->beginTransaction();
        foreach ($sqlStatements as $sql) {
            $pdo->exec($sql); // Use exec for queries that don't return results (like CREATE TABLE)
        }
        $pdo->commit();
        return true;
    } catch (PDOException $e) {
        if ($pdo && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("Errore durante la creazione dello schema del database: " . $e->getMessage());
        // Depending on your application, you might want to throw the exception
        // or return false to indicate failure. For setup, throwing might be better.
        throw new PDOException("Errore critico durante la creazione dello schema del database: " . $e->getMessage(), (int)$e->getCode(), $e);
        // return false; // Uncomment this and comment throw if you prefer to handle false return
    }
}

/**
 * Helper function to safely escape HTML output.
 * Use this whenever echoing user-generated or dynamic content into HTML.
 *
 * @param string|null $string The string to escape.
 * @return string The escaped string.
 */
function e(?string $string): string {
    return htmlspecialchars((string)$string, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

// Example usage (commented out - you would typically run this via a dedicated script or installer):
/*
echo "Tentativo di creazione/verifica dello schema del database...\n";
try {
    if (createDatabaseSchema()) {
        echo "Schema del database creato o verificato con successo!\n";
    } else {
        // This part might not be reached if createDatabaseSchema throws an exception on failure
        echo "Errore durante la creazione dello schema del database (restituito falso).\n";
    }
} catch (PDOException $e) {
    echo "Si è verificato un errore critico del database durante l'installazione: " . $e->getMessage() . "\n";
    echo "Controllare i log per maggiori dettagli.\n";
}
*/

?>

/**
 * Form validation utility functions for Prodotto Recensioni Aggregate
 * Provides specialized validation for different input types
 */

/**
 * Validates an email address
 * @param {string} email - The email to validate
 * @returns {boolean} True if valid, false if invalid
 */
function validateEmail(email) {
    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return pattern.test(email);
}

/**
 * Validates a password for strength requirements
 * @param {string} password - The password to validate
 * @returns {object} Object with validation results
 */
function validatePassword(password) {
    const results = {
        isValid: false,
        errors: []
    };
    
    // Check length
    if (password.length < 8) {
        results.errors.push('La password deve essere di almeno 8 caratteri.');
    }
    
    // Check for uppercase
    if (!/[A-Z]/.test(password)) {
        results.errors.push('La password deve contenere almeno una lettera maiuscola.');
    }
    
    // Check for lowercase
    if (!/[a-z]/.test(password)) {
        results.errors.push('La password deve contenere almeno una lettera minuscola.');
    }
    
    // Check for numbers
    if (!/\d/.test(password)) {
        results.errors.push('La password deve contenere almeno un numero.');
    }
    
    results.isValid = results.errors.length === 0;
    
    return results;
}

/**
 * Compares two passwords to check if they match
 * @param {string} password - The original password
 * @param {string} confirm - The confirmation password
 * @returns {boolean} True if matching, false if not
 */
function passwordsMatch(password, confirm) {
    return password === confirm;
}

/**
 * Validates a username
 * @param {string} username - The username to validate
 * @returns {object} Object with validation results
 */
function validateUsername(username) {
    const results = {
        isValid: false,
        errors: []
    };
    
    // Check length
    if (username.length < 3) {
        results.errors.push('Il nome utente deve essere di almeno 3 caratteri.');
    }
    
    // Check for invalid characters
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
        results.errors.push('Il nome utente può contenere solo lettere, numeri e underscore.');
    }
    
    results.isValid = results.errors.length === 0;
    
    return results;
}

/**
 * Validates a review rating
 * @param {number} rating - The rating value
 * @returns {boolean} True if valid, false if invalid
 */
function validateRating(rating) {
    const numRating = parseInt(rating);
    return !isNaN(numRating) && numRating >= 1 && numRating <= 5;
}

/**
 * Validates review content
 * @param {string} content - The review text content
 * @returns {boolean} True if valid, false if invalid
 */
function validateReviewContent(content) {
    return content.trim().length >= 10;
}

/**
 * Shows validation error messages for a form field
 * @param {HTMLElement} input - The input element
 * @param {Array} errors - Array of error messages
 */
function showValidationErrors(input, errors) {
    // Clear existing errors
    const existingErrors = input.parentNode.querySelectorAll('.error-text');
    existingErrors.forEach(el => el.remove());
    
    // Add error class to input
    input.classList.add('form-input-error');
    
    // Create error container
    const errorContainer = document.createElement('div');
    errorContainer.className = 'error-text';
    
    // Add each error message
    errors.forEach(error => {
        const errorMessage = document.createElement('p');
        errorMessage.textContent = error;
        errorContainer.appendChild(errorMessage);
    });
    
    // Insert after input
    input.parentNode.insertBefore(errorContainer, input.nextSibling);
}

/**
 * Clears validation errors for a form field
 * @param {HTMLElement} input - The input element
 */
function clearValidationErrors(input) {
    input.classList.remove('form-input-error');
    
    const existingErrors = input.parentNode.querySelectorAll('.error-text');
    existingErrors.forEach(el => el.remove());
}









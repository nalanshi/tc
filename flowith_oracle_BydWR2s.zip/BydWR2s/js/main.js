/**
 * Main JavaScript file for Prodotto Recensioni Aggregate
 * Handles general site interactions, including accessibility features like skip links and focus outlines.
 */

document.addEventListener('DOMContentLoaded', function() {
    // console.log("Prodotto Recensioni Aggregate - JS Loaded"); // Removed log for condensation

    
    // Mobile menu toggle (if one exists and is identified by these IDs)
    // This is primarily implemented in the admin layout footer, but keeping a general reference here if a public site mobile nav was intended.
    const mobileMenuButton = document.getElementById('mobile-menu-button'); // Assuming a button with this ID
    const mobileMenu = document.getElementById('mobile-menu'); // Assuming a menu container with this ID

    if (mobileMenuButton && mobileMenu) {
        mobileMenuButton.addEventListener('click', function() {
            const isExpanded = mobileMenuButton.getAttribute('aria-expanded') === 'true';
            mobileMenuButton.setAttribute('aria-expanded', !isExpanded);
            mobileMenu.classList.toggle('hidden'); // Or toggle a class that controls visibility via CSS
             // Optional: Manage inert or visibility states for accessibility
             if (!isExpanded) {
                 mobileMenu.removeAttribute('aria-hidden');
                 // Maybe focus the first element in the menu
                 const firstMenuItem = mobileMenu.querySelector('a, button, input');
                 if (firstMenuItem) {
                     firstMenuItem.focus();
                 }
             } else {
                 mobileMenu.setAttribute('aria-hidden', 'true');
                 // Return focus to the button that opened the menu
                 mobileMenuButton.focus();
             }

        });
         // Optional: Add event listener to close menu on click outside or on escape key
         document.addEventListener('click', function(event) {
             if (!mobileMenu.contains(event.target) && !mobileMenuButton.contains(event.target) && !mobileMenu.classList.contains('hidden')) {
                  mobileMenu.classList.add('hidden');
                  mobileMenuButton.setAttribute('aria-expanded', 'false');
                  mobileMenu.setAttribute('aria-hidden', 'true');
             }
         });
         document.addEventListener('keydown', function(event) {
             if (event.key === 'Escape' && !mobileMenu.classList.contains('hidden')) {
                  mobileMenu.classList.add('hidden');
                  mobileMenuButton.setAttribute('aria-expanded', 'false');
                   mobileMenu.setAttribute('aria-hidden', 'true');
             }
         });
    }


    // Example: Interactive rating stars on product cards (if not server-rendered static)
    // This function is illustrative. It would need to be called for each product card
    // that has a `div.rating-stars` and a `span.rating-value` or data attribute.
    // As per current PHP, stars are rendered server-side. This JS might be for interactive forms.
    function initRatingStarsDisplay(containerSelector = '.product-card') {
        const elements = document.querySelectorAll(containerSelector); 
        elements.forEach(element => {
            const ratingValueElement = element.querySelector('.rating-value'); 
            const starsContainer = element.querySelector('.rating-stars'); 

            if (ratingValueElement && starsContainer) {
                const rating = parseFloat(ratingValueElement.textContent);
                if (!isNaN(rating)) {
                    starsContainer.innerHTML = ''; // Clear any existing static stars
                    // Create accessible stars (using SVGs or characters)
                    const fullStars = Math.floor(rating);
                    const halfStar = rating - fullStars >= 0.5;
                    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);

                    for (let i = 0; i < fullStars; i++) {
                       const star = document.createElement('span');
                       star.setAttribute('aria-hidden', 'true'); // Hide from screen readers as value is available
                       star.classList.add('star', 'filled');
                       star.innerHTML = '★'; // Or an SVG
                       starsContainer.appendChild(star);
                    }
                    if (halfStar) {
                         const star = document.createElement('span');
                         star.setAttribute('aria-hidden', 'true');
                          // Use a half-star character or a partially filled SVG
                         star.classList.add('star', 'half-filled'); // Add specific class for styling
                         star.innerHTML = '★'; // Or a specific half-star SVG
                         starsContainer.appendChild(star);
                    }
                    for (let i = 0; i < emptyStars; i++) {
                         const star = document.createElement('span');
                         star.setAttribute('aria-hidden', 'true');
                         star.classList.add('star');
                         star.innerHTML = '☆'; // Or an empty SVG
                         starsContainer.appendChild(star);
                     }
                      // Add accessible text for overall rating if not already present
                     if (!element.querySelector('[aria-label^="Valutazione media:"]')) {
                          const srOnlyRating = document.createElement('span');
                          srOnlyRating.classList.add('sr-only');
                           // Format the rating appropriately for locale (e.g., use comma for decimals in Italy)
                          const formattedRating = rating.toLocaleString('it-IT', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
                          srOnlyRating.textContent = `Valutazione media: ${formattedRating} su 5 stelle`;
                         // Where to append this? Maybe next to the visible stars, inside an accessible wrapper
                          starsContainer.parentNode.insertBefore(srOnlyRating, starsContainer.nextSibling); // Example placement, after stars
                     }
                }
            }
        });
    }
    // Call initRatingStarsDisplay if your listings populate dynamically or need client-side rendering
    // initRatingStarsDisplay(); // If product listing is static HTML, this is not strictly necessary if PHP renders correctly

    // Alert dismissal (generic, for any alert with a close button)
    // Ensure your alerts have a structure like:
    // <div class="alert" role="alert"> ... <button class="alert-close-button">&times;</button> </div>
    const alertCloseButtons = document.querySelectorAll('.alert-close-button');
    alertCloseButtons.forEach(button => {
        button.addEventListener('click', function() {
            const alertBox = this.closest('[role="alert"], [role="status"]'); // Find the parent alert by role
            if (alertBox) {
                // Use animation and remove from DOM for better accessibility (screen readers)
                alertBox.style.opacity = '0';
                alertBox.addEventListener('transitionend', function() {
                    alertBox.remove();
                });
            }
        });
         // Add aria-label to close buttons
         if (!button.hasAttribute('aria-label')) {
             button.setAttribute('aria-label', 'Chiudi messaggio');
         }
    });

    // Client-side dynamic validation visual cues (using classes from styles.css)
    // This should be integrated with actual validation logic per form (e.g., in validators.js or page scripts)
    // Example: Add/remove 'is-invalid' class.
    // Note: The PHP pages already handle server-side validation messages on reload.
    // Client-side validation adds immediate feedback.
    // This is a hook; the actual validation functions are expected elsewhere.

    // Function to show validation errors visually
    // Assumes a structure like <div class="form-field-container"> <label> <input> <span class="error-text">
    window.showValidationErrors = function(inputElement, errors) {
        if (!inputElement) return; // Handle cases where element isn't found

        // Ensure errors is an array
        if (!Array.isArray(errors)) {
             errors = [errors];
        }

        // Find or create the error message container linked by aria-describedby
        // This requires input fields to have aria-describedby="[inputId]-error"
        const errorId = inputElement.id ? `${inputElement.id}-error` : null;
        let errorSpan = null;
        if (errorId) {
            errorSpan = document.getElementById(errorId);
        }

        // If no linked span found, look for a generic one or create
        if (!errorSpan) {
            // Check immediate sibling span with error-text class
             errorSpan = inputElement.nextElementSibling; // This might not be the span if there are other elements
             if (errorSpan && !errorSpan.classList.contains('error-text')) {
                 errorSpan = null; // Not the error span
             }
             // Fallback to querying within the parent container
             const parentContainer = inputElement.closest('.form-field-container');
             if (parentContainer) {
                 errorSpan = parentContainer.querySelector('.error-text') || parentContainer.appendChild(document.createElement('span'));
                 errorSpan.className = 'error-text text-xs text-red-600 mt-1'; // Apply base styles (Tailwind red-600 for new text)
                 if (errorId && !errorSpan.id) {
                     errorSpan.id = errorId; // Assign ID if needed and not present
                 }
             } else {
                  // If no container or specific span, just add after input
                  errorSpan = document.createElement('span');
                  errorSpan.className = 'error-text text-xs text-red-600 mt-1';
                  if (errorId) errorSpan.id = errorId;
                   inputElement.parentNode.insertBefore(errorSpan, inputElement.nextSibling);
             }
        }


        // Add error class to input
        inputElement.classList.add('is-invalid'); // Use a class defined in styles.css

        // Update ARIA attributes
        inputElement.setAttribute('aria-invalid', 'true');
        if (errorId) { // Ensure aria-describedby links to the span
             const currentDescribedBy = inputElement.getAttribute('aria-describedby') || '';
             if (!currentDescribedBy.split(' ').includes(errorId)) {
                  inputElement.setAttribute('aria-describedby', (currentDescribedBy + ' ' + errorId).trim());
             }
        }


        // Populate error message(s)
        errorSpan.innerHTML = ''; // Clear previous messages
        errors.forEach(msg => {
            const p = document.createElement('p');
            p.textContent = msg;
            errorSpan.appendChild(p);
        });
        // Use aria-live="polite" for less intrusive announcements of field-level errors.
        // role="alert" (implicitly assertive) is better for global/summary error messages.
        errorSpan.setAttribute('aria-live', 'polite'); 
        errorSpan.setAttribute('aria-atomic', 'true'); // Ensures the entire message is read out


    };

    // Function to clear validation errors visually
    window.clearValidationErrors = function(inputElement) {
        if (!inputElement) return;

        inputElement.classList.remove('is-invalid');
        inputElement.removeAttribute('aria-invalid');

        const errorId = inputElement.id ? `${inputElement.id}-error` : null;
        let errorSpan = null;
         if (errorId) {
             errorSpan = document.getElementById(errorId);
         } else {
            // Fallback check if no ID/aria-describedby
            const parentContainer = inputElement.closest('.form-field-container');
            if (parentContainer) {
                 errorSpan = parentContainer.querySelector('.error-text');
            } else {
                 // Last resort, check immediate sibling
                 errorSpan = inputElement.nextElementSibling;
                 if (errorSpan && !errorSpan.classList.contains('error-text')) {
                     errorSpan = null;
                 }
            }
         }

        if (errorSpan) {
            errorSpan.innerHTML = ''; // Clear message text
            errorSpan.removeAttribute('aria-live'); // Remove polite live region attributes
            errorSpan.removeAttribute('aria-atomic');
        }
        
         // Clean up aria-describedby if only the error ID was linked
        if (errorId) {
             const currentDescribedBy = inputElement.getAttribute('aria-describedby') || '';
             const describedByParts = currentDescribedBy.split(' ').filter(id => id !== errorId).join(' ');
             if (describedByParts) {
                 inputElement.setAttribute('aria-describedby', describedByParts);
             } else {
                 inputElement.removeAttribute('aria-describedby');
             }
        }
    };

    // --- ADMIN PANEL SPECIFIC JS (can be in a separate admin.js) ---
    // Confirm delete (global function, also defined in admin_layout_footer.php for direct use)
    // Keeping here as this file might be loaded globally. Ensure no conflicts.
    if (!window.confirmAdminDelete) { // Check if not already defined (e.g. by layout footer)
        window.confirmAdminDelete = function(event, message = 'Sei sicuro di voler eliminare questo elemento? L\'azione non può essere annullata.') {
            if (!confirm(message)) {
                event.preventDefault(); // Prevent form submission / link click
                return false;
            }
            return true; // Allow submission / click
        }
    }


}); // End DOMContentLoaded


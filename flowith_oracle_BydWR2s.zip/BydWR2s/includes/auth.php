<?php
// includes/auth.php

require_once __DIR__ . '/../config/db.php'; // Now includes e() function
require_once __DIR__ . '/../models/User.php';

// Start session if it hasn't been started already
if (session_status() === PHP_SESSION_NONE) {
    // Use a more secure session name
    session_name('PRA_SESSION'); // Prodotto Recensioni Aggregate SESSION

    // Set session cookie parameters for security
    // HttpOnly: Mitigates XSS by preventing JS access to the session cookie.
    // Secure: Ensures cookie is only sent over HTTPS. Critical for production.
    // SameSite=Lax: Mitigates CSRF by controlling when the cookie is sent with cross-origin requests.
    // 'Lax' is a good balance; 'Strict' can break some legitimate cross-site navigations.
    $secureCookie = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on';
    session_set_cookie_params([
        'lifetime' => 0, // Session cookie, lives as long as browser is open, or set to a specific duration (e.g., 14400 for 4 hours)
        'path' => '/',   // Available for the entire domain
        'domain' => $_SERVER['HTTP_HOST'] ?? '', // Restrict to current domain, ensure HTTP_HOST is reliable or configure explicitly
        'secure' => $secureCookie,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    
    session_start();

    // Regenerate session ID periodically to mitigate session hijacking.
    // Example: Regenerate every 30 minutes of session activity.
    $sessionRegenerationInterval = 1800; // 30 minutes
    if (!isset($_SESSION['last_regeneration']) || (time() - $_SESSION['last_regeneration'] > $sessionRegenerationInterval)) {
        session_regenerate_id(true); // true to delete old session file
        $_SESSION['last_regeneration'] = time();
    }
}

/**
 * Attempts to log in a user.
 *
 * @param string $emailOrUsername User's email or username.
 * @param string $password User's plain text password.
 * @return bool True if login is successful, false otherwise.
 * @throws PDOException If a database error occurs during user lookup.
 */
function loginUser(string $emailOrUsername, string $password): bool {
    // Basic input trimming (email/username)
    $emailOrUsername = trim($emailOrUsername);
    // Password is not trimmed as whitespace might be part of it, though usually not recommended.

    if (empty($emailOrUsername) || empty($password)) {
        return false; // Cannot log in with empty fields
    }

    $user = null;
    try {
        // Try to find user by email first
        if (filter_var($emailOrUsername, FILTER_VALIDATE_EMAIL)) {
            $user = User::getByEmail($emailOrUsername);
        }

        // If not found by email, try by username
        if (!$user) {
            $user = User::getByUsername($emailOrUsername);
        }

        // If user is found and password verifies
        if ($user && $user->verifyPassword($password)) {
            // Authentication successful

            // Prevent session fixation by regenerating session ID
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time(); // Update regeneration time

            // Store minimum necessary information in the session
            $_SESSION['user_id'] = $user->user_id;
            $_SESSION['username'] = $user->username; // For display purposes
            $_SESSION['role'] = $user->role;         // For authorization checks
            $_SESSION['logged_in'] = true;
            $_SESSION['login_time'] = time();        // For session duration tracking
            $_SESSION['last_activity'] = time();     // For inactivity timeout

            // Log successful login (optional, be mindful of logging sensitive info if expanded)
            error_log("Login successful for user ID: {$user->user_id}");

            return true; // Login successful
        } else {
            // Authentication failed
            // Be generic for security, do not hint if user existed or just password was wrong.
            error_log("Failed login attempt for email/username: '" . e($emailOrUsername) . "'"); // Log sanitized input
            return false; // Login failed
        }
    } catch (PDOException $e) {
        error_log("Database error during login attempt for '" . e($emailOrUsername) . "': " . $e->getMessage());
        throw $e; // Rethrow the exception for the caller to handle (e.g. show generic DB error message)
    }
}

/**
 * Logs out the current user by destroying the session.
 */
function logoutUser(): void {
    // Unset all session variables
    $_SESSION = [];

    // Delete the session cookie.
    // Note: This will delete the cookie on the client side.
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, // Expires in the past
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Destroy the session on the server
    session_destroy();
    
    // Optional: Clear session cache if using specific handlers like memcached, though usually not needed for file-based sessions.
    // session_write_close(); // Not strictly necessary here as session_destroy() handles this.

    // Log logout (optional)
    // User ID might not be available if session is already fully cleared.
    // error_log("User logged out.");
}

/**
 * Checks if a user is currently logged in and updates last activity.
 * Implements session inactivity timeout.
 */
function isLoggedIn(): bool {
    if (session_status() !== PHP_SESSION_ACTIVE || !isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
        return false;
    }

    // Session inactivity timeout
    $maxInactiveTime = 3600; // 1 hour (in seconds)
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $maxInactiveTime)) {
        error_log("User session expired due to inactivity. User ID: {$_SESSION['user_id']}");
        logoutUser(); // Log out the user
        return false;
    }
    $_SESSION['last_activity'] = time(); // Update last activity time on any authenticated action

    return true;
}

/**
 * Gets the currently logged-in user object.
 * Fetches fresh data from DB to ensure role/status is up-to-date.
 *
 * @return User|null The User object if logged in and found, null otherwise.
 * @throws PDOException On database error during user fetch.
 */
function getCurrentUser(): ?User {
    if (!isLoggedIn() || !isset($_SESSION['user_id'])) { // isLoggedIn() already checks session status and essential keys
        return null;
    }

    try {
        $user = User::getById((int)$_SESSION['user_id']);
        if ($user) {
             // Optional: Re-sync critical session data if it can change and is stored there
             // For instance, if username or role changes, session should reflect it.
             // However, typically role changes are infrequent. Relying on User object is often enough.
             $_SESSION['username'] = $user->username;
             $_SESSION['role'] = $user->role;
            return $user;
        } else {
            // User ID in session not found in DB (e.g., user deleted). Log out.
            error_log("Session user ID {$_SESSION['user_id']} not found in DB. Logging out.");
            logoutUser();
            return null;
        }
    } catch (PDOException $e) {
        error_log("Database error fetching current user ID {$_SESSION['user_id']}: " . $e->getMessage());
        // Depending on policy, critical error during user fetch might require logging out
        // or simply returning null and letting the caller handle.
        // Throwing means the calling page must handle a potential DB outage gracefully.
        throw $e;
    }
}

/**
 * Checks if the logged-in user has a specific role.
 *
 * @param string $roleToCheck The role name (e.g., 'admin').
 * @return bool True if logged in and has the role, false otherwise.
 *              Returns false also on database error during user fetch.
 */
function currentUserHasRole(string $roleToCheck): bool {
     try {
        $user = getCurrentUser(); // This can throw PDOException if DB is down
        if ($user) {
            return $user->hasRole($roleToCheck);
        }
     } catch (PDOException $e) {
         // Logged in getCurrentUser, so no need to log again here typically.
         // Fail safe: If DB error occurs while fetching user, assume no specific role.
         // This prevents accidental privilege escalation if DB check fails.
     }
    return false;
}

// --- CSRF Token Functions ---

/**
 * Generates and stores a CSRF token in the session if one doesn't exist or is forced to regenerate.
 * @param bool $forceRegenerate If true, a new token is generated even if one exists.
 * @return string The CSRF token.
 * @throws Exception If secure random bytes generation fails.
 */
function generateCsrfToken(bool $forceRegenerate = false): string {
    if ($forceRegenerate || empty($_SESSION['csrf_token'])) {
        try {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Generate cryptographically secure token
            // error_log("New CSRF token generated: " . ($_SESSION['csrf_token'] ?? 'N/A')); // Verbose logging, can be removed
        } catch (Exception $e) {
            error_log("Critical Error: Failed to generate CSRF token: " . $e->getMessage());
            // This is a critical failure. Application should not proceed without CSRF protection.
            throw new Exception("Impossibile generare un token di sicurezza. Riprova più tardi o contatta l'assistenza.");
        }
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verifies a given CSRF token against the one stored in the session.
 * Uses hash_equals() for timing-attack safe comparison.
 *
 * @param string $submittedToken The token from the form submission.
 * @param bool $regenerateAfterVerification If true, the token is invalidated/regenerated after successful verification.
 *                                          This is crucial for "token-per-request" or "token-per-form" patterns.
 *                                          Set to false for "token-per-session" (less secure against replay on multiple tabs, but might be simpler for some UX).
 * @return bool True if the token is valid, false otherwise.
 */
function verifyCsrfToken(string $submittedToken, bool $regenerateAfterVerification = true): bool {
    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token']) || !is_string($submittedToken) || empty($submittedToken)) {
        error_log("CSRF token verification failed: Session token not found or submitted token invalid/empty.");
        return false;
    }

    // Use hash_equals for timing attack resistance
    if (hash_equals($_SESSION['csrf_token'], $submittedToken)) {
        // Token matches
        if ($regenerateAfterVerification) {
             // Invalidate the token immediately after successful use to prevent reuse (token-per-request pattern)
             unset($_SESSION['csrf_token']);
             // Optionally, generate a new one immediately for the next request:
             // generateCsrfToken(true); // Though typically new one generated on next page load needing a token.
        }
        // error_log("CSRF token verified successfully."); // Verbose logging
        return true;
    } else {
         // Token mismatch - potential CSRF or expired form
         error_log("CSRF token mismatch. Submitted token: '" . e($submittedToken) . "' does not match session token.");
         // For enhanced security, consider invalidating the session token on mismatch too,
         // though this can affect UX with multiple tabs.
         // unset($_SESSION['csrf_token']); // Invalidate on mismatch
         return false;
    }
}


// --- Password Reset Token Functions ---
// These functions assume a `Password_Resets` table with:
// user_id (INT, FK), selector (VARCHAR, UNIQUE), hashed_verifier (VARCHAR), expires_at (DATETIME)

/**
 * Creates a password reset token (selector and verifier pair) for a user.
 * Stores the selector and hashed verifier in the database.
 * Returns the plain selector and verifier for sending to the user (e.g., in an email link).
 * The verifier MUST be sent to the user in plain text (e.g. in URL), it is hashed in the DB.
 *
 * @param int $userId The ID of the user requesting the reset.
 * @return array|false An array ['selector' => string, 'verifier_plain' => string] on success, false on failure.
 * @throws PDOException On database error.
 * @throws Exception On error generating random bytes.
 */
function createPasswordResetTokenForUser(int $userId) {
    if ($userId <= 0) return false;

    try {
        $selector = bin2hex(random_bytes(16));         // Public part, 32 hex chars
        $verifierPlain = bin2hex(random_bytes(32));    // Secret part (for user), 64 hex chars
        $hashedVerifier = password_hash($verifierPlain, PASSWORD_DEFAULT); // Hash the verifier for database storage
        $expiresAt = date('Y-m-d H:i:s', time() + 3600); // Token expires in 1 hour (adjust as needed)

        // Delete any existing tokens for this user to prevent multiple valid tokens for the same user
        $sqlDelete = "DELETE FROM Password_Resets WHERE user_id = :user_id";
        executeQuery($sqlDelete, [':user_id' => $userId], false);


        // Insert the new token
        $sqlInsert = "INSERT INTO Password_Resets (user_id, selector, hashed_verifier, expires_at)
                      VALUES (:user_id, :selector, :hashed_verifier, :expires_at)";
        $params = [
            ':user_id' => $userId,
            ':selector' => $selector,
            ':hashed_verifier' => $hashedVerifier,
            ':expires_at' => $expiresAt
        ];
        $rowCount = executeQuery($sqlInsert, $params, false);

        if ($rowCount > 0) {
            return ['selector' => $selector, 'verifier_plain' => $verifierPlain];
        }
        error_log("Failed to insert password reset token for user ID {$userId}.");
        return false;
    } catch (Exception $e) { // Catches Exception from random_bytes() and PDOException rethrown from executeQuery
        error_log("Error during password reset token creation for user ID {$userId}: " . $e->getMessage());
        throw $e; // Rethrow for caller to handle presentation
    }
}

/**
 * Validates a password reset token (selector and verifier pair).
 * Returns the user ID if the token is valid and not expired.
 * This function deletes the token upon successful validation (single-use tokens).
 *
 * @param string $selector The public part of the token.
 * @param string $verifierPlain The secret part of the token (plain text, from user link).
 * @return int|false The user ID on success, false on failure or if token is invalid/expired.
 * @throws PDOException On database error.
 */
function getUserIdFromValidPasswordResetToken(string $selector, string $verifierPlain): ?int {
    if (empty($selector) || empty($verifierPlain)) {
        return null;
    }

    $sql = "SELECT user_id, hashed_verifier, expires_at FROM Password_Resets WHERE selector = :selector";
    $params = [':selector' => $selector];

    try {
        $tokenData = executeQuery($sql, $params, false); // Fetch single row

        if ($tokenData) {
            // Check if token is not expired
            if (strtotime($tokenData['expires_at']) > time()) {
                // Verify the plain text verifier against the hashed one from DB
                if (password_verify($verifierPlain, $tokenData['hashed_verifier'])) {
                    // Token is valid and not expired
                    // Delete the token after use (important for security - single use)
                    deletePasswordResetTokenBySelector($selector);
                    return (int)$tokenData['user_id']; // Return the user ID
                } else {
                    // Verifier mismatch - log for suspicion, but be generic to user
                    error_log("Password reset verifier mismatch for selector: {$selector}");
                    // Optionally, delete token on failed verification too to prevent brute-force on verifier
                    // deletePasswordResetTokenBySelector($selector); // Or mark as attempted
                }
            } else {
                // Token expired - delete expired token to clean up DB
                error_log("Expired password reset token used for selector: {$selector}. Deleting.");
                deletePasswordResetTokenBySelector($selector);
            }
        } else {
            // Selector not found - log for suspicion
             error_log("Password reset selector not found: {$selector}");
        }
        return null; // Token invalid, expired, or not found
    } catch (PDOException $e) {
        error_log("Database error validating password reset token for selector {$selector}: " . $e->getMessage());
        throw $e; // Rethrow database errors
    }
}

/**
 * Deletes a password reset token from the database using its selector.
 *
 * @param string $selector The selector of the token to delete.
 * @return bool True on successful deletion or if token didn't exist, false on error.
 * @throws PDOException On database error.
 */
function deletePasswordResetTokenBySelector(string $selector): bool {
    if (empty($selector)) return false;
    $sql = "DELETE FROM Password_Resets WHERE selector = :selector";
    $params = [':selector' => $selector];
    try {
        executeQuery($sql, $params, false); // Returns rowCount, can be 0 if not found, which is fine.
        return true; // Operation completed without DB error
    } catch (PDOException $e) {
        error_log("Database error deleting password reset token for selector {$selector}: " . $e->getMessage());
        throw $e;
    }
}

/**
 * Deletes all password reset tokens for a given user ID.
 *
 * @param int $userId
 * @return bool True if operation completed without DB error.
 * @throws PDOException On database error.
 */
function deleteAllPasswordResetTokensForUser(int $userId): bool {
    if ($userId <= 0) return false;
    $sql = "DELETE FROM Password_Resets WHERE user_id = :user_id";
    try {
        executeQuery($sql, [':user_id' => $userId], false);
        return true; // Operation completed without DB error
    } catch (PDOException $e) {
        error_log("Database error deleting all password reset tokens for user ID {$userId}: " . $e->getMessage());
        throw $e;
    }
}

?>

<?php
// This is a placeholder file for including a common footer across pages
// Variables like $homeLink, $productsLink, $profileLink etc., are expected to be defined by header.php
// $isLoggedIn is also available from header.php context.
?>
    </main>

    <footer class="bg-gray-800 text-white py-10 px-4 md:px-8 mt-16">
        <div class="container mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                <div>
                    <h3 class="text-xl font-bold mb-4">Prodotto Recensioni Aggregate</h3>
                    <p class="text-gray-300 text-sm">
                        La tua piattaforma affidabile per recensioni di prodotti autentiche e dettagliate. Ti aiutiamo a fare scelte più consapevoli.
                    </p>
                </div>
                <div>
                    <h3 class="text-lg font-semibold mb-4">Collegamenti Rapidi</h3>
                    <ul class="space-y-2 text-sm">
                        <li><a href="<?php echo htmlspecialchars($homeLink ?? '#'); ?>" class="text-gray-300 hover:text-white hover:underline transition">Home</a></li>
                        <li><a href="<?php echo htmlspecialchars($productsLink ?? '#'); ?>" class="text-gray-300 hover:text-white hover:underline transition">Prodotti</a></li>
                        <?php if (isset($isLoggedIn) && $isLoggedIn): ?>
                            <li><a href="<?php echo htmlspecialchars($profileLink ?? '#'); ?>" class="text-gray-300 hover:text-white hover:underline transition">Il Mio Profilo</a></li>
                            <li><a href="<?php echo htmlspecialchars($logoutLink ?? '#'); ?>" class="text-gray-300 hover:text-white hover:underline transition">Esci</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo htmlspecialchars($registerLink ?? '#'); ?>" class="text-gray-300 hover:text-white hover:underline transition">Registrati</a></li>
                            <li><a href="<?php echo htmlspecialchars($loginLink ?? '#'); ?>" class="text-gray-300 hover:text-white hover:underline transition">Accedi</a></li>
                        <?php endif; ?>
                         <li><a href="#" class="text-gray-300 hover:text-white hover:underline transition">Chi Siamo (Esempio)</a></li>
                         <li><a href="#" class="text-gray-300 hover:text-white hover:underline transition">Contattaci (Esempio)</a></li>
                         <li><a href="<?php echo htmlspecialchars($passwordRecoveryLink ?? '#'); ?>" class="text-gray-300 hover:text-white hover:underline transition">Recupera Password</a></li>

                    </ul>
                </div>
                <div>
                    <h3 class="text-lg font-semibold mb-4">Contattaci</h3>
                    <p class="text-gray-300 mb-2 text-sm">Email: <a href="mailto:info@prodottorecensioni.it" class="hover:text-white hover:underline">info@prodottorecensioni.it</a></p>
                    <p class="text-gray-300 text-sm">Telefono: +39 012 3456789 (Esempio)</p>
                    <!-- Add social media links if applicable -->
                </div>
            </div>
            <div class="border-t border-gray-700 pt-8 text-center text-gray-400 text-xs">
                <p>&copy; <?php echo date('Y'); ?> Prodotto Recensioni Aggregate. Tutti i diritti riservati.</p>
                <p>Realizzato con passione per acquisti migliori e accessibili.</p>
            </div>
        </div>
    </footer>

    <script src="<?php echo htmlspecialchars($jsPath); ?>"></script> <?php // Main JS ?>
    <?php if (isset($validatorsJsPath) && !empty($validatorsJsPath)): // Conditionally load validators if path is set by page script ?>
        <script src="<?php echo htmlspecialchars($validatorsJsPath); ?>"></script>
    <?php endif; ?>
    <?php if (isset($additionalScripts) && !empty($additionalScripts)) echo $additionalScripts; // Page-specific scripts ?>
</body>
</html>






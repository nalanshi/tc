<?php
// Include data models required for navigation/header elements if any (e.g., categories)
require_once __DIR__ . '/../config/db.php'; // Ensure db connection and e() helper are available
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/auth.php'; // Include auth/session logic (starts session)

// Generate a nonce for Content Security Policy for inline scripts/styles if any
// Store in global to be accessible by footer or other included parts.
global $cspNonce;
$cspNonce = bin2hex(random_bytes(16));


// Determine the base path for assets and links.
// This calculation needs to be robust. A common approach is to define a BASE_URL constant.
// For this exercise, using a simplified relative path calculation.
// The $assetBase calculation logic from the original code seems to handle different depths.
$scriptName = $_SERVER['SCRIPT_NAME'];
$pathParts = explode('/', $scriptName);
array_pop($pathParts); // Remove script filename
$currentDir = implode('/', $pathParts);

// Simplification: if script is in /pages/admin, base is ../../
// if script is in /pages, base is ../
// if script is at root, base is ./
if (strpos($scriptName, '/pages/admin/') !== false) {
    $assetBase = '../../';
} elseif (strpos($scriptName, '/pages/') !== false) {
    $assetBase = '../';
} else {
    $assetBase = './';
}
// This $projectWebRoot variable from original code was less reliable. $assetBase is relative.
// For absolute paths, a globally defined BASE_URL (e.g., http://localhost/myapp) is better.
// Let's keep $assetBase for relative links and define $projectRootUrl for full URLs if needed.
// For links, it's often better to make them root-relative (e.g. /index.php, /pages/products.php)
// If the app is in a subfolder (e.g. /myreviewsapp/), then $projectWebRoot needs to be that subfolder path.
// The original code attempts to calculate $projectWebRoot. For simplicity, let's assume for now:
$projectWebRoot = rtrim(str_repeat('../', substr_count(rtrim($_SERVER['PHP_SELF'], '/'), '/') - (substr_count(rtrim(dirname($_SERVER['SCRIPT_NAME']),'/'),'/') > 0 ? 1:0)),'/');
// This is still tricky. A simpler $projectWebRoot assuming the project root is the web server root:
// $projectWebRoot = ''; // If project is at domain root
// If project is in a subdir, e.g. /my_project_subdir/
// $projectWebRoot = '/my_project_subdir'; // This should be configured, not calculated complexly.
// Let's rely on $assetBase for relative paths from current file, and construct root-relative paths for major links.
// A common pattern for $projectWebRoot:
$calculatedProjectWebRoot = '';
if (isset($_SERVER['CONTEXT_PREFIX']) && !empty($_SERVER['CONTEXT_PREFIX'])) {
    $calculatedProjectWebRoot = $_SERVER['CONTEXT_PREFIX']; // Common for Tomcat/Java setups, adapt if relevant
} else {
    // Heuristic for typical PHP shared hosting / local dev
    // Assumes index.php is at the project root relative to web server root
    $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], '/');
    $scriptFilePath = realpath(dirname(__FILE__) . '/../index.php'); // Path to project's index.php
    if (strpos($scriptFilePath, $docRoot) === 0) {
        $calculatedProjectWebRoot = substr(dirname($scriptFilePath), strlen($docRoot));
    }
    $calculatedProjectWebRoot = str_replace('\\', '/', $calculatedProjectWebRoot); // Normalize slashes
}
$projectWebRoot = rtrim($calculatedProjectWebRoot, '/');


$cssPath = $assetBase . 'css/styles.css';
$jsPath = $assetBase . 'js/main.js';
$validatorsJsPath = $assetBase . 'js/validators.js';

// Major navigation links should ideally be root-relative for consistency
$homeLink = $projectWebRoot . '/index.php';
$productsLink = $projectWebRoot . '/pages/elenco-prodotti.php';
$registerLink = $projectWebRoot . '/pages/registrazione.php';
$loginLink = $projectWebRoot . '/pages/accesso.php';
$profileLink = $projectWebRoot . '/pages/profilo-utente.php';
$logoutLink = $projectWebRoot . '/pages/logout.php';
$passwordRecoveryLink = $projectWebRoot . '/pages/recupero-password.php';
$logoLink = $projectWebRoot . '/index.php'; // Logo links to homepage
$searchActionLink = $productsLink; // Search submits to product list

$categories = [];
try {
    $categories = Category::getAll('name', 'ASC');
} catch (PDOException $e) {
    error_log("Error fetching categories for header: " . $e->getMessage());
}

$pageTitle = $pageTitle ?? 'Prodotto Recensioni Aggregate';
$pageDescription = $pageDescription ?? 'Piattaforma per esplorare, cercare e recensire prodotti di diverse categorie.';
$currentPage = $currentPage ?? '';

$isLoggedIn = isLoggedIn();
$user = null;
$adminLink = null;
if ($isLoggedIn) {
    try {
        $user = getCurrentUser();
        if ($user && $user->hasRole('admin')) {
             $adminLink = $projectWebRoot . '/pages/admin/pannello_amministrazione.php';
        }
    } catch (PDOException $e) {
        error_log("Failed to get current user for header: " . $e->getMessage());
        $_SESSION['flash_message_db'] = 'Si è verificato un problema nel caricare i tuoi dati utente.';
    }
}

// --- Security Headers ---
// Content Security Policy (CSP)
$cspHeader = "Content-Security-Policy: default-src 'self'; ";
// Scripts: self, Tailwind CDN, and nonce for any inline scripts.
$cspHeader .= "script-src 'self' https://cdn.tailwindcss.com https://cdnjs.cloudflare.com 'nonce-{$cspNonce}'; ";
// Styles: self, Tailwind CDN, and 'unsafe-inline' if Tailwind CDN requires it (often does for dynamic classes or its JS parts).
// If Tailwind is used purely with utility classes in HTML and no JS interaction changing styles, 'unsafe-inline' might be avoidable.
// For fonts from CDNs (like Google Fonts, if used), add their origins.
$cspHeader .= "style-src 'self' https://cdn.tailwindcss.com 'unsafe-inline'; "; // 'unsafe-inline' for styles is often needed with Tailwind CDN or for small inline style attributes.
$cspHeader .= "img-src 'self' data: https:; "; // Allow images from self, data URIs, and any HTTPS source. Restrict 'https:' if specific CDNs are known.
$cspHeader .= "font-src 'self' https: data:; "; // Allow fonts from self, HTTPS sources (e.g. Google Fonts), and data URIs.
$cspHeader .= "form-action 'self'; "; // Forms can only submit to the same origin.
$cspHeader .= "frame-ancestors 'none'; "; // Prevent clickjacking by disallowing embedding in frames. 'self' if you need to frame your own pages.
$cspHeader .= "object-src 'none'; "; // Disallow plugins like Flash.
$cspHeader .= "base-uri 'self'; "; // Restricts the <base> tag.
// $cspHeader .= "report-uri /csp-violation-report-endpoint;"; // Optional: For receiving CSP violation reports.

header($cspHeader);

// X-Frame-Options: DENY (Alternative/fallback for frame-ancestors, good for older browsers)
header('X-Frame-Options: DENY');

// X-Content-Type-Options: nosniff (Prevents MIME-sniffing attacks)
header('X-Content-Type-Options: nosniff');

// X-XSS-Protection: 0 (Modern browsers rely on CSP. Setting to 0 disables the browser's heuristic XSS filter, which can have its own vulnerabilities)
// Or: header('X-XSS-Protection: 1; mode=block'); (If you prefer to keep it enabled)
header('X-XSS-Protection: 0');


// Referrer-Policy: strict-origin-when-cross-origin (Good balance of privacy and utility)
// Or 'no-referrer-when-downgrade' (default in many cases) or 'same-origin'.
header('Referrer-Policy: strict-origin-when-cross-origin');

// HTTP Strict Transport Security (HSTS)
// IMPORTANT: Only uncomment and use HSTS if your site is FULLY and PERMANENTLY served over HTTPS.
// Misconfiguration can make your site inaccessible. Start with a short max-age for testing.
// header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload'); // 1 year
// A more cautious start:
// header('Strict-Transport-Security: max-age=600; includeSubDomains'); // 10 minutes for testing

// Permissions-Policy (formerly Feature-Policy) - Deny features not needed.
// Example: header("Permissions-Policy: geolocation=(), microphone=(), camera=()");
// Be specific about what your site actually uses. A restrictive default:
header("Permissions-Policy: accelerometer=(), ambient-light-sensor=(), autoplay=(), battery=(), camera=(), cross-origin-isolated=(), display-capture=(), document-domain=(), encrypted-media=(), execution-while-not-rendered=(), execution-while-out-of-viewport=(), fullscreen=(), geolocation=(), gyroscope=(), keyboard-map=(), magnetometer=(), microphone=(), midi=(), navigation-override=(), payment=(), picture-in-picture=(), publickey-credentials-get=(), screen-wake-lock=(), sync-xhr=(), usb=(), web-share=(), xr-spatial-tracking=()");


?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($pageTitle); ?></title>
    <meta name="description" content="<?php echo e($pageDescription); ?>">
    <script src="https://cdn.tailwindcss.com"></script>
    <?php // CDN for js-yaml and marked - include if Markdown processing is added and not already present ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/js-yaml/4.1.0/js-yaml.min.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/marked/15.0.7/marked.min.js" defer></script>
    <link rel="stylesheet" href="<?php echo e($cssPath); ?>">
    <?php if (isset($additionalHeadContent)) echo $additionalHeadContent; // For page-specific head elements ?>
</head>
<body class="min-h-screen flex flex-col bg-gray-50 text-gray-800">
    <a href="#content" class="skip-to-content">Vai al contenuto principale</a>

    <header class="bg-white shadow-sm sticky top-0 z-50">
        <div class="container mx-auto py-4 px-4 md:px-8 flex flex-col md:flex-row justify-between items-center">
            <div class="flex items-center mb-4 md:mb-0">
                <h1 class="text-2xl font-bold text-gray-800">
                    <a href="<?php echo e($logoLink); ?>" class="hover:text-blue-600 transition">Prodotto Recensioni Aggregate</a>
                </h1>
            </div>

            <form action="<?php echo e($searchActionLink); ?>" method="GET" class="w-full md:w-auto md:flex-grow md:max-w-md md:ml-8 order-last md:order-none mt-4 md:mt-0">
                <div class="flex">
                    <label for="search-header" class="sr-only">Cerca prodotti</label>
                    <input
                        type="search"
                        id="search-header"
                        name="search"
                        placeholder="Cerca prodotti per nome o descrizione..."
                        class="w-full rounded-l-md border-gray-300 border py-2 px-3 text-sm focus:ring-blue-500 focus:border-blue-500"
                        value="<?php echo e($_GET['search'] ?? ''); ?>"
                    >
                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-r-md flex items-center justify-center" aria-label="Avvia ricerca">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                         <span class="sr-only">Cerca</span>
                    </button>
                </div>
            </form>

            <?php
                $mainNavPath = __DIR__ . '/navigation.php';
                if (file_exists($mainNavPath)) {
                    include $mainNavPath;
                } else {
                    error_log("Navigation file not found at expected path: " . $mainNavPath);
                }
            ?>

            <!-- User/Auth links -->
             <div class="flex items-center space-x-2 sm:space-x-4 ml-0 sm:ml-4 mt-4 md:mt-0">
                 <?php if ($isLoggedIn && $user): ?>
                     <span class="text-gray-700 text-sm hidden sm:inline">Ciao, <?php echo e($user->username); ?>!</span>
                     <a href="<?php echo e($profileLink); ?>" class="text-sm px-3 py-2 rounded hover:bg-gray-100 transition text-gray-700 <?php echo ($currentPage === 'profile') ? 'aria-current="page" bg-blue-50 text-blue-700 font-semibold' : ''; ?>">Profilo</a>
                     <?php if ($adminLink): ?>
                          <a href="<?php echo e($adminLink); ?>" class="text-sm px-3 py-2 rounded hover:bg-gray-100 transition text-gray-700 <?php echo (strpos($currentPage, 'admin') === 0) ? 'aria-current="page" bg-blue-50 text-blue-700 font-semibold' : ''; ?>">Admin</a>
                     <?php endif; ?>
                     <a href="<?php echo e($logoutLink); ?>" class="text-sm px-3 py-2 rounded bg-gray-200 text-gray-700 hover:bg-gray-300 transition">Esci</a>
                 <?php else: ?>
                     <a href="<?php echo e($registerLink); ?>" class="text-sm px-3 py-2 rounded hover:bg-gray-100 transition text-gray-700 <?php echo ($currentPage === 'register') ? 'aria-current="page" bg-blue-50 text-blue-700 font-semibold' : ''; ?>">Registrati</a>
                     <a href="<?php echo e($loginLink); ?>" class="text-sm px-3 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 transition <?php echo ($currentPage === 'login') ? 'aria-current="page" font-semibold' : ''; ?>">Accedi</a>
                 <?php endif; ?>
            </div>
        </div>
         <!-- Category Navigation Bar -->
        <?php if (!empty($categories) && ($currentPage === 'products' || $currentPage === 'product-detail' || $currentPage === 'home' /* Show on home too? */ )): ?>
            <div class="bg-gray-100 border-t border-b border-gray-200">
                 <div class="container mx-auto py-3 px-4 md:px-8">
                    <nav aria-label="Navigazione per categoria">
                        <ul class="flex flex-wrap gap-x-3 gap-y-2 items-center">
                            <li class="mr-2 font-semibold text-gray-700 text-sm">Categorie:</li>
                             <li><a href="<?php echo e($productsLink); ?>" class="text-sm hover:text-blue-800 hover:underline <?php echo (!isset($_GET['category_id']) || empty($_GET['category_id'])) ? 'font-bold text-blue-700' : 'text-gray-700'; ?>">Tutte</a></li>
                            <?php foreach ($categories as $category): ?>
                                <li>
                                    <a href="<?php echo e($productsLink . '?category_id=' . $category->category_id); ?>"
                                       class="text-sm hover:text-blue-800 hover:underline <?php echo (isset($_GET['category_id']) && $_GET['category_id'] == $category->category_id) ? 'font-bold text-blue-700' : 'text-gray-700'; ?>"
                                       aria-label="Esplora la categoria <?php echo e($category->name); ?>">
                                        <?php echo e($category->name); ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        <?php endif; ?>
    </header>

    <main id="content" class="flex-grow container mx-auto py-8 px-4 md:px-8 page-transition">
        <!-- Flash/Session messages area -->
        <?php if (isset($_SESSION['flash_message'])): ?>
            <div class="mb-6 p-4 rounded-md <?php echo $_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 border-green-500 text-green-700' : 'bg-red-100 border-red-500 text-red-700'; ?>" 
                 role="<?php echo $_SESSION['flash_message']['type'] === 'success' ? 'status' : 'alert'; ?>"
                 aria-live="polite" aria-atomic="true">
                <p class="font-bold"><?php echo $_SESSION['flash_message']['type'] === 'success' ? 'Successo!' : 'Errore!'; ?></p>
                <p><?php echo e($_SESSION['flash_message']['message']); ?></p>
            </div>
            <?php unset($_SESSION['flash_message']); ?>
        <?php endif; ?>
        <?php if (isset($_SESSION['flash_message_db'])): ?>
            <div class="mb-6 p-4 rounded-md bg-red-100 border-red-500 text-red-700" role="alert" aria-live="assertive" aria-atomic="true">
                 <p class="font-bold">Errore Database</p>
                <p><?php echo e($_SESSION['flash_message_db']); ?></p>
            </div>
            <?php unset($_SESSION['flash_message_db']); ?>
        <?php endif; ?>
        <!-- Content from individual pages goes here -->

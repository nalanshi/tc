<?php
/**
 * Navigation component for the site
 * Provides a reusable navigation bar with dynamic active state
 * 
 * @param string $currentPage The current page identifier to highlight the active link
 */

// Define navigation items
$navItems = [
    'home' => [
        'url' => 'index.php',
        'text' => 'Home'
    ],
    'products' => [
        'url' => 'elenco-prodotti.php',
        'text' => 'Prodotti'
    ],
    'register' => [
        'url' => 'registrazione.php',
        'text' => 'Registrati'
    ],
    'login' => [
        'url' => 'accesso.php',
        'text' => 'Accedi',
        'highlight' => true
    ]
];

// Base URL - adjust as needed based on project structure
$baseUrl = '';

// Check if a page parameter was passed, otherwise default to none
$currentPage = $currentPage ?? '';
?>

<nav class="flex items-center space-x-1 md:space-x-4">
    <?php foreach ($navItems as $id => $item): ?>
        <?php 
            $isActive = ($currentPage === $id);
            $classes = $isActive 
                ? 'aria-current="page" ' . ($item['highlight'] ?? false ? 'px-4 py-2 rounded bg-blue-600 text-white' : 'px-3 py-2 rounded bg-blue-50 text-blue-700') 
                : ($item['highlight'] ?? false ? 'px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 transition' : 'px-3 py-2 rounded hover:bg-gray-100 transition text-gray-700');
        ?>
        <a href="<?php echo $baseUrl . $item['url']; ?>" <?php echo $isActive ? 'aria-current="page"' : ''; ?> class="<?php echo $classes; ?>">
            <?php echo htmlspecialchars($item['text']); ?>
        </a>
    <?php endforeach; ?>
</nav>









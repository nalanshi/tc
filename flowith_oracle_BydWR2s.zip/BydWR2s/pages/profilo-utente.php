<?php
// pages/profilo-utente.php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Review.php'; 
require_once __DIR__ . '/../models/Product.php';


if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header("Location: accesso.php");
    exit;
}

$currentUser = null;
$userLoadError = '';
try {
    $currentUser = getCurrentUser();
    if (!$currentUser) {
         error_log("Profilo utente: Utente loggato ma non trovato nel DB. Session ID: " . session_id() . ", User ID in session: " . ($_SESSION['user_id'] ?? 'N/A'));
         logoutUser(); 
         header("Location: accesso.php?error=session_invalid");
         exit;
    }
} catch (PDOException $e) {
    error_log("Errore database nel caricare il profilo utente ID {$_SESSION['user_id']}: " . $e->getMessage());
    $userLoadError = "Impossibile caricare i dati del profilo. Riprova più tardi.";
}

$pageTitle = $currentUser ? "Profilo di " . htmlspecialchars($currentUser->username) : "Profilo Utente";
$currentPage = 'profile';

$userReviews = [];
$reviewsLoadError = '';
$totalUserReviews = 0;
$totalReviewPages = 0;
$reviewPage = 1;

if ($currentUser) {
   try {
       $reviewsPerPage = 5;
       $reviewPage = isset($_GET['review_page']) ? (int)$_GET['review_page'] : 1;
       if ($reviewPage < 1) $reviewPage = 1;
       $reviewOffset = ($reviewPage - 1) * $reviewsPerPage;

       $userReviews = Review::getByUserId($currentUser->user_id, 'created_at', 'DESC', $reviewsPerPage, $reviewOffset);
       $totalUserReviews = Review::countByUserId($currentUser->user_id);
       $totalReviewPages = ceil($totalUserReviews / $reviewsPerPage);
       if ($reviewPage > $totalReviewPages && $totalUserReviews > 0) { // Redirect if page out of bounds
            header("Location: " . $_SERVER['PHP_SELF'] . "?review_page=" . $totalReviewPages);
            exit;
       }

   } catch (PDOException $e) {
       error_log("Errore DB nel caricare recensioni per utente {$currentUser->user_id}: " . $e->getMessage());
       $reviewsLoadError = "Impossibile caricare le tue recensioni al momento.";
   }
}

include __DIR__ . '/../includes/header.php';
?>

<div class="w-full max-w-3xl mx-auto">
    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="p-4 mb-6 rounded-md <?php echo $_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 border-green-500 text-green-700' : 'bg-red-100 border-red-500 text-red-700'; ?>" role="alert">
            <p class="font-bold"><?php echo $_SESSION['flash_message']['type'] === 'success' ? 'Successo!' : 'Errore!'; ?></p>
            <p><?php echo htmlspecialchars($_SESSION['flash_message']['message']); ?></p>
        </div>
        <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <?php if (!empty($userLoadError)): ?>
         <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
             <p class="font-bold">Errore Caricamento Profilo</p>
             <p><?php echo htmlspecialchars($userLoadError); ?></p>
         </div>
    <?php elseif ($currentUser): ?>
        <header class="mb-8 text-center">
            <h1 class="text-3xl md:text-4xl font-bold text-gray-900">Benvenuto nel Tuo Profilo</h1>
            <p class="text-xl text-gray-700 mt-2"><?php echo htmlspecialchars($currentUser->username); ?></p>
        </header>

        <div class="bg-white rounded-lg shadow-md p-6 md:p-8 mb-8">
            <h2 class="text-2xl font-semibold text-gray-800 mb-6 border-b pb-3">Informazioni Account</h2>
            <dl class="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
                <div>
                    <dt class="text-sm font-medium text-gray-600">Nome Utente:</dt>
                    <dd class="text-lg text-gray-900"><?php echo htmlspecialchars($currentUser->username); ?></dd>
                </div>
                <div>
                    <dt class="text-sm font-medium text-gray-600">Email:</dt>
                    <dd class="text-lg text-gray-900"><?php echo htmlspecialchars($currentUser->email); ?></dd>
                </div>
                <div>
                    <dt class="text-sm font-medium text-gray-600">Ruolo:</dt>
                    <dd class="text-lg text-gray-900 capitalize"><?php echo htmlspecialchars($currentUser->role); ?></dd>
                </div>
                <div>
                    <dt class="text-sm font-medium text-gray-600">Membro Dal:</dt>
                    <dd class="text-lg text-gray-900"><?php echo date("d F Y", strtotime($currentUser->created_at)); ?></dd>
                </div>
            </dl>
            <div class="mt-8 border-t pt-6 flex flex-wrap gap-3">
                <button class="px-5 py-2.5 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 transition shadow-sm opacity-50 cursor-not-allowed" aria-disabled="true" title="Funzionalità futura">
                    Modifica Profilo
                </button>
                <button class="px-5 py-2.5 bg-gray-200 text-gray-800 text-sm rounded-md hover:bg-gray-300 transition shadow-sm opacity-50 cursor-not-allowed" aria-disabled="true" title="Funzionalità futura">
                    Cambia Password
                </button>
                 <?php if ($currentUser->hasRole('admin') && isset($adminLink)): ?>
                    <a href="<?php echo htmlspecialchars($adminLink); ?>" class="px-5 py-2.5 bg-indigo-600 text-white text-sm rounded-md hover:bg-indigo-700 transition shadow-sm">
                        Pannello Admin
                    </a>
                 <?php endif; ?>
            </div>
        </div>

        <div id="le-tue-recensioni" class="bg-white rounded-lg shadow-md p-6 md:p-8">
            <h2 class="text-2xl font-semibold text-gray-800 mb-6 border-b pb-3">Le Tue Recensioni (<?php echo $totalUserReviews; ?>)</h2>
            <?php if (!empty($reviewsLoadError)): ?>
                <p class="text-red-600"><?php echo htmlspecialchars($reviewsLoadError); ?></p>
            <?php elseif (empty($userReviews)): ?>
                <div class="text-center py-8">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
                    </svg>
                    <p class="mt-3 text-lg font-medium text-gray-800">Non hai ancora scritto recensioni.</p>
                    <p class="mt-1 text-sm text-gray-600">Esplora i prodotti e condividi la tua preziosa opinione!</p>
                    <a href="<?php echo htmlspecialchars($productsLink); ?>" class="mt-6 inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition">
                        Esplora Prodotti
                    </a>
                </div>
            <?php else: ?>
                <ul class="space-y-6">
                    <?php foreach ($userReviews as $review): ?>
                        <li class="border p-4 rounded-md shadow-sm bg-gray-50 hover:shadow-md transition-shadow">
                             <h3 class="font-semibold text-lg text-gray-800">
                                 Recensione per:
                                 <?php if ($review->getProduct() && !empty($review->getProduct()->name)): ?>
                                     <a href="dettaglio-prodotto.php?id_prodotto=<?php echo $review->product_id; ?>#recensioni" class="text-blue-600 hover:underline">
                                         <?php echo htmlspecialchars($review->getProduct()->name); ?>
                                     </a>
                                 <?php else: ?>
                                     <span class="text-gray-500 italic">Prodotto non più disponibile o nome non trovato</span>
                                 <?php endif; ?>
                            </h3>
                            <div class="flex items-center my-1.5">
                                <div class="rating-stars flex text-yellow-400" aria-label="Valutazione: <?php echo $review->rating; ?> su 5 stelle">
                                    <?php for ($s = 1; $s <= 5; $s++): ?>
                                        <svg class="w-4 h-4 <?php echo ($s <= $review->rating) ? 'fill-current' : 'text-gray-300 fill-current'; ?>" viewBox="0 0 20 20"><path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/></svg>
                                    <?php endfor; ?>
                                </div>
                                <span class="ml-2 text-sm text-gray-600">(<?php echo $review->rating; ?>/5 stelle)</span>
                            </div>
                            <div class="prose prose-sm max-w-none text-gray-700 mt-2">
                                <?php echo nl2br(htmlspecialchars($review->comment_text)); ?>
                            </div>

                             <?php if (!empty($review->pros)): ?>
                             <div class="mt-3">
                                <strong class="font-medium text-gray-800 text-sm">Pro:</strong>
                                 <div class="prose prose-sm max-w-none text-green-700 ml-1">
                                    <?php echo nl2br(htmlspecialchars($review->pros)); ?>
                                 </div>
                             </div>
                             <?php endif; ?>
                             <?php if (!empty($review->cons)): ?>
                             <div class="mt-3">
                                 <strong class="font-medium text-gray-800 text-sm">Contro:</strong>
                                 <div class="prose prose-sm max-w-none text-red-700 ml-1">
                                    <?php echo nl2br(htmlspecialchars($review->cons)); ?>
                                 </div>
                             </div>
                             <?php endif; ?>

                            <p class="text-xs text-gray-500 mt-3">
                                Scritta il: <?php echo date("d/m/Y H:i", strtotime($review->created_at)); ?> &mdash;
                                Stato: <?php echo $review->is_approved ? '<span class="font-medium text-green-600">Approvata</span>' : '<span class="font-medium text-yellow-600">In attesa di approvazione</span>'; ?>
                            </p>
                             <div class="mt-3 text-right space-x-3">
                                <button class="text-blue-600 hover:underline text-sm opacity-50 cursor-not-allowed" disabled title="Modifica (Funzionalità futura)">Modifica</button>
                                <button class="text-red-600 hover:underline text-sm opacity-50 cursor-not-allowed" disabled title="Elimina (Funzionalità futura)">Elimina</button>
                             </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
                 <?php if ($totalReviewPages > 1): ?>
                      <nav aria-label="Navigazione pagine recensioni" class="mt-8 flex justify-center">
                          <ul class="inline-flex items-center -space-x-px rounded-md shadow-sm">
                              <?php
                                  $baseReviewUrl = $_SERVER['PHP_SELF'] . '?'; // Basic, add other params if any
                              ?>
                              <?php if ($reviewPage > 1): ?>
                              <li>
                                  <a href="<?php echo htmlspecialchars($baseReviewUrl . 'review_page=' . ($reviewPage - 1)); ?>#le-tue-recensioni"
                                     class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700"
                                     aria-label="Pagina precedente recensioni">
                                      <span class="sr-only">Precedente</span>&laquo;
                                  </a>
                              </li>
                              <?php endif; ?>

                              <?php for ($p = 1; $p <= $totalReviewPages; $p++): ?>
                                  <li>
                                      <a href="<?php echo htmlspecialchars($baseReviewUrl . 'review_page=' . $p); ?>#le-tue-recensioni"
                                         class="py-2 px-3 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 <?php echo ($p === $reviewPage) ? 'z-10 !bg-blue-50 !border-blue-500 !text-blue-600' : ''; ?>"
                                         <?php echo ($p === $reviewPage) ? 'aria-current="page"' : ''; ?>
                                         aria-label="Pagina <?php echo $p; ?> delle tue recensioni">
                                          <?php echo $p; ?>
                                      </a>
                                  </li>
                              <?php endfor; ?>

                              <?php if ($reviewPage < $totalReviewPages): ?>
                              <li>
                                  <a href="<?php echo htmlspecialchars($baseReviewUrl . 'review_page=' . ($reviewPage + 1)); ?>#le-tue-recensioni"
                                     class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700"
                                     aria-label="Pagina successiva recensioni">
                                      <span class="sr-only">Successiva</span>&raquo;
                                  </a>
                              </li>
                              <?php endif; ?>
                          </ul>
                      </nav>
                 <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <p class="text-center text-lg text-gray-700">Impossibile caricare i dati del profilo utente.</p>
    <?php endif; ?>
</div>

<?php
$validatorsJsPath = $projectWebRoot . '/js/validators.js'; 
$additionalScripts = ''; // No page-specific JS needed for now beyond global/validators
include __DIR__ . '/../includes/footer.php';
?>





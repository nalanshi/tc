<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';

$pageTitle = "Elenco Prodotti";
$currentPage = 'products'; // For header active state and category nav visibility

// Pagination settings
$productsPerPage = 9;
$pageNumber = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($pageNumber < 1) $pageNumber = 1;
$offset = ($pageNumber - 1) * $productsPerPage;

// Get filter parameters
$categoryId = isset($_GET['category_id']) ? (int)$_GET['category_id'] : null;
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : null;

$products = [];
$totalProducts = 0;
$currentCategoryName = null;

try {
    if ($searchTerm) {
        $pageTitle = "Risultati Ricerca per: \"" . htmlspecialchars($searchTerm) . "\"";
        $products = Product::searchProducts($searchTerm, $productsPerPage, $offset);
        $totalProducts = Product::countAll(null, $searchTerm);
    } elseif ($categoryId) {
        $category = Category::getById($categoryId);
        if ($category) {
            $currentCategoryName = $category->name;
            $pageTitle = "Prodotti in: " . htmlspecialchars($currentCategoryName);
            $products = Product::getProductsByCategory($categoryId, $productsPerPage, $offset);
            $totalProducts = Product::countAll($categoryId);
        } else {
            // Category not found, show all products or an error
            $pageTitle = "Categoria non trovata";
            $products = Product::getAllProducts($productsPerPage, $offset); // Fallback to all products
            $totalProducts = Product::countAll();
        }
    } else {
        $products = Product::getAllProducts($productsPerPage, $offset);
        $totalProducts = Product::countAll();
    }
} catch (PDOException $e) {
    error_log("Errore nel caricamento dei prodotti: " . $e->getMessage());
    // Handle error display, maybe set a message for the user
    $userErrorMessage = "Si è verificato un errore nel caricamento dei prodotti. Riprova più tardi.";
}

$totalPages = ceil($totalProducts / $productsPerPage);

// This path is relative from /pages directory for assets
$placeholderImageWebPath = '../assets/placeholder.svg';

include __DIR__ . '/../includes/header.php';
?>

<section class="elenco-prodotti">
    <header class="mb-8">
        <h1 class="text-3xl font-bold text-gray-900">
            <?php echo htmlspecialchars($pageTitle); ?>
        </h1>
        <?php if ($totalProducts > 0): ?>
        <p class="text-sm text-gray-600 mt-1">
            Trovati <?php echo $totalProducts; ?> prodotti. Pagina <?php echo $pageNumber; ?> di <?php echo $totalPages; ?>.
        </p>
        <?php endif; ?>
    </header>

    <?php if (isset($userErrorMessage)): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
            <strong class="font-bold">Errore!</strong>
            <span class="block sm:inline"><?php echo htmlspecialchars($userErrorMessage); ?></span>
        </div>
    <?php endif; ?>

    <?php if (empty($products) && !isset($userErrorMessage)): ?>
        <div class="text-center py-12">
            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                <path vector-effect="non-scaling-stroke" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
            </svg>
            <h2 class="mt-2 text-lg font-medium text-gray-900">Nessun prodotto trovato</h2>
            <p class="mt-1 text-sm text-gray-500">
                <?php if ($searchTerm): ?>
                    La tua ricerca per "<?php echo htmlspecialchars($searchTerm); ?>" non ha prodotto risultati. Prova con termini diversi.
                <?php elseif ($categoryId && $currentCategoryName): ?>
                    Non ci sono prodotti in questa categoria "<?php echo htmlspecialchars($currentCategoryName); ?>".
                <?php else: ?>
                    Al momento non ci sono prodotti da visualizzare. Torna a trovarci più tardi!
                <?php endif; ?>
            </p>
            <div class="mt-6">
                <a href="<?php echo htmlspecialchars($productsLink); ?>" class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Torna a tutti i prodotti
                </a>
            </div>
        </div>
    <?php elseif (!empty($products)): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($products as $product): ?>
                <article class="bg-white rounded-lg shadow-md overflow-hidden flex flex-col transition-shadow duration-300 hover:shadow-xl">
                    <a href="dettaglio-prodotto.php?id_prodotto=<?php echo $product->product_id; ?>" class="block aspect-w-16 aspect-h-9">
                        <img 
                            src="<?php echo !empty($product->image_url) ? htmlspecialchars($product->image_url) : $placeholderImageWebPath; ?>" 
                            alt="Immagine di <?php echo htmlspecialchars($product->name); ?>" 
                            class="w-full h-48 object-cover"
                            loading="lazy">
                    </a>
                    <div class="p-5 flex flex-col flex-grow">
                        <h2 class="text-lg font-semibold text-gray-800 mb-2">
                            <a href="dettaglio-prodotto.php?id_prodotto=<?php echo $product->product_id; ?>" class="hover:text-blue-600 transition">
                                <?php echo htmlspecialchars($product->name); ?>
                            </a>
                        </h2>
                        
                        <?php if ($product->average_rating !== null): ?>
                        <div class="my-1 flex items-center">
                            <span class="rating-value sr-only"><?php echo number_format($product->average_rating, 1); ?></span>
                            <!-- JS will populate stars here -->
                             <div class="rating-stars flex text-yellow-400">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <svg class="w-4 h-4 <?php echo ($i <= round($product->average_rating)) ? 'fill-current' : 'text-gray-300 fill-current'; ?>" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/></svg>
                                <?php endfor; ?>
                            </div>
                            <span class="ml-2 text-xs text-gray-500">(<?php echo number_format($product->average_rating, 1, ',', ''); ?>/5)</span>
                        </div>
                        <?php else: ?>
                        <p class="text-xs text-gray-500 my-1">Nessuna valutazione</p>
                        <?php endif; ?>

                        <p class="text-sm text-gray-600 mt-2 mb-3 flex-grow">
                            <?php 
                                $description = $product->description ?? 'Nessuna descrizione disponibile.';
                                if (strlen($description) > 100) {
                                    echo htmlspecialchars(substr($description, 0, 100)) . '...';
                                } else {
                                    echo htmlspecialchars($description);
                                }
                            ?>
                        </p>
                        <a href="dettaglio-prodotto.php?id_prodotto=<?php echo $product->product_id; ?>" class="mt-auto self-start inline-block bg-blue-500 text-white text-sm px-4 py-2 rounded-md hover:bg-blue-600 transition">
                            Vedi Dettagli
                        </a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <nav aria-label="Navigazione pagine" class="mt-12 flex justify-center">
            <ul class="inline-flex items-center -space-x-px">
                <?php if ($pageNumber > 1): ?>
                <li>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $pageNumber - 1])); ?>"
                       class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700">
                        <span class="sr-only">Precedente</span>
                        &laquo;
                    </a>
                </li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <?php if ($i == $pageNumber): ?>
                    <li>
                        <span aria-current="page" class="py-2 px-3 leading-tight text-blue-600 bg-blue-50 border border-blue-300 hover:bg-blue-100 hover:text-blue-700">
                            <?php echo $i; ?>
                        </span>
                    </li>
                    <?php else: ?>
                    <li>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>"
                           class="py-2 px-3 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700">
                            <?php echo $i; ?>
                        </a>
                    </li>
                    <?php endif; ?>
                <?php endfor; ?>

                <?php if ($pageNumber < $totalPages): ?>
                <li>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $pageNumber + 1])); ?>"
                       class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700">
                        <span class="sr-only">Successiva</span>
                        &raquo;
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php endif; ?>

    <?php endif; ?>
</section>

<?php
// Add script for rating stars if not already global
$additionalScripts = '<script>
document.addEventListener("DOMContentLoaded", function() {
    if (typeof initRatingStars === "function") {
        // Re-initialize if it was partial load or if elements are added dynamically
        // For this page, direct star rendering is done via PHP, 
        // but if JS method `initRatingStars` is preferred, ensure it runs.
        // The PHP above now renders stars directly to avoid FOUC.
        // initRatingStars(); 
    }
});
</script>';
include __DIR__ . '/../includes/footer.php';
?>







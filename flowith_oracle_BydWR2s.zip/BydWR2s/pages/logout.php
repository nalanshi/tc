<?php
// pages/logout.php

require_once __DIR__ . '/../includes/auth.php'; // auth.php starts session

logoutUser();

// Redirect to the homepage
// Using relative path calculation to ensure correct redirect from /pages/
$pathParts = explode('/', $_SERVER['SCRIPT_NAME']);
$projectWebRoot = implode('/', array_slice($pathParts, 0, array_search('pages', $pathParts)));
$projectWebRoot = rtrim($projectWebRoot, '/');
$homeUrl = $projectWebRoot . '/index.php';

header("Location: " . $homeUrl . "?logout_success=1");
exit;
?>






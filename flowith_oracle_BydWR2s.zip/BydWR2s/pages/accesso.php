<?php
// pages/accesso.php - Gestione Login Utente

require_once __DIR__ . '/../config/db.php'; // Includes e()
require_once __DIR__ . '/../includes/auth.php'; // Handles session_start() and isLoggedIn()
require_once __DIR__ . '/../models/User.php'; 

// Redirect if already logged in
if (isLoggedIn()) {
    $redirectUrl = $_SESSION['redirect_after_login'] ?? 'profilo-utente.php';
    unset($_SESSION['redirect_after_login']);

    // Basic validation to prevent open redirect. Ensure it's a local path.
    // A more robust solution would involve a whitelist of allowed redirect paths.
    if (strpos($redirectUrl, '://') !== false || strpos($redirectUrl, '//') === 0) { // Disallow external URLs
        error_log("Open redirect attempt after login blocked. Original URL: " . e($redirectUrl));
        $redirectUrl = 'profilo-utente.php'; // Fallback to a safe default
    }
    // Prepend current directory if it's just a filename (relative to 'pages/' directory)
    if (strpos($redirectUrl, '/') === false) {
        $redirectUrl = $projectWebRoot . '/pages/' . $redirectUrl; // Assuming $projectWebRoot is set by header
    } else { // If it's an absolute path like /pages/some.php or /index.php
         // Ensure it starts with $projectWebRoot if $projectWebRoot is defined and not empty
         if (!empty($projectWebRoot) && strpos($redirectUrl, $projectWebRoot) !== 0) {
             if (strpos($redirectUrl, 'pages/') === 0 || $redirectUrl === 'index.php') { // Check if it's a known root-relative structure
                 $redirectUrl = $projectWebRoot . '/' . ltrim($redirectUrl, '/');
             } else {
                error_log("Potentially unsafe redirect after login: " . e($redirectUrl) . ". Falling back to profile.");
                $redirectUrl = $projectWebRoot . '/pages/profilo-utente.php';
             }
         }
    }
    
    header("Location: " . $redirectUrl); // Path should be relative to web root
    exit;
}

$pageTitle = "Accedi al Tuo Account";
$currentPage = 'login';

$errorMessages = [];
$formData = ['email_username' => ''];

$csrfToken = generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], true)) {
        $errorMessages['csrf'] = "Richiesta non valida o sessione scaduta. Riprova.";
        error_log("CSRF token mismatch or invalid on login form.");
        $csrfToken = generateCsrfToken(true); // Regenerate token for the redisplayed form
    } else {
        $emailOrUsername = trim(filter_input(INPUT_POST, 'email_username', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '');
        $password = $_POST['password'] ?? '';

        $formData['email_username'] = $emailOrUsername;

        if (empty($emailOrUsername)) {
            $errorMessages['email_username'] = "Il campo Email o Nome Utente è obbligatorio.";
        }
        if (empty($password)) {
            $errorMessages['password'] = "Il campo Password è obbligatorio.";
        }

        if (empty($errorMessages)) {
            try {
                if (loginUser($emailOrUsername, $password)) {
                    $redirectUrl = $_SESSION['redirect_after_login'] ?? 'profilo-utente.php';
                    unset($_SESSION['redirect_after_login']);

                    if (strpos($redirectUrl, '://') !== false || strpos($redirectUrl, '//') === 0) {
                        error_log("Open redirect attempt after successful login blocked. Original URL: " . e($redirectUrl));
                        $redirectUrl = 'profilo-utente.php';
                    }
                     if (strpos($redirectUrl, '/') === false) {
                        $redirectUrl = $projectWebRoot . '/pages/' . $redirectUrl;
                    } else {
                         if (!empty($projectWebRoot) && strpos($redirectUrl, $projectWebRoot) !== 0) {
                             if (strpos($redirectUrl, 'pages/') === 0 || $redirectUrl === 'index.php') {
                                 $redirectUrl = $projectWebRoot . '/' . ltrim($redirectUrl, '/');
                             } else {
                                error_log("Potentially unsafe redirect after successful login: " . e($redirectUrl) . ". Falling back to profile.");
                                $redirectUrl = $projectWebRoot . '/pages/profilo-utente.php';
                             }
                         }
                    }


                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Accesso effettuato con successo. Benvenuto!'];
                    header("Location: " . $redirectUrl);
                    exit;
                } else {
                    $errorMessages['credentials'] = "Credenziali non valide. Email/Nome Utente o Password errati.";
                }
            } catch (PDOException $e) {
                $errorMessages['db_error'] = "Si è verificato un errore del database. Riprova più tardi.";
            }
        }
        // If login failed for any reason (validation, auth, db), regenerate CSRF for the form
        if(!empty($errorMessages)) {
            $csrfToken = generateCsrfToken(true);
        }
    }
}

include __DIR__ . '/../includes/header.php'; // Defines $projectWebRoot, $registerLink, $passwordRecoveryLink
?>

<div class="w-full max-w-md mx-auto">
    <h1 class="text-3xl font-bold text-center text-gray-900 mb-8">Accedi al Tuo Account</h1>

    <?php if (!empty($errorMessages)): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert" aria-atomic="true">
            <p class="font-bold">Errore di Accesso</p>
            <ul class="mt-2 list-disc list-inside text-sm">
                <?php foreach ($errorMessages as $field => $errorMessage): ?>
                    <li><?php echo e($errorMessage); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow-md p-6 md:p-8">
        <form action="<?php echo e(ltrim($_SERVER['PHP_SELF'], $projectWebRoot == '' ? '' : ($projectWebRoot . '/'))); ?>" method="POST" class="space-y-6" novalidate>
             <input type="hidden" name="csrf_token" value="<?php echo e($csrfToken); ?>">

            <div class="form-field-container">
                <label for="email_username" class="block text-sm font-medium text-gray-700 mb-1">Email o Nome Utente*</label>
                <input type="text" id="email_username" name="email_username"
                       class="w-full px-3 py-2 border <?php echo isset($errorMessages['email_username']) || isset($errorMessages['credentials']) ? 'border-red-500 is-invalid' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                       required value="<?php echo e($formData['email_username']); ?>"
                       aria-describedby="email_username-error" autocomplete="username"
                       aria-invalid="<?php echo (isset($errorMessages['email_username']) || isset($errorMessages['credentials'])) ? 'true' : 'false'; ?>">
                <span id="email_username-error" class="error-text text-xs text-red-600 mt-1" aria-live="polite"></span>
            </div>

            <div class="form-field-container">
                <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Password*</label>
                <input type="password" id="password" name="password"
                       class="w-full px-3 py-2 border <?php echo isset($errorMessages['password']) || isset($errorMessages['credentials']) ? 'border-red-500 is-invalid' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                       required aria-describedby="password-error" autocomplete="current-password"
                       aria-invalid="<?php echo (isset($errorMessages['password']) || isset($errorMessages['credentials'])) ? 'true' : 'false'; ?>">
                <span id="password-error" class="error-text text-xs text-red-600 mt-1" aria-live="polite"></span>
            </div>

            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <input id="remember-me" name="remember-me" type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    <label for="remember-me" class="ml-2 block text-sm text-gray-700">Ricordami</label>
                </div>
                <div class="text-sm">
                    <a href="<?php echo e($passwordRecoveryLink); ?>" class="text-blue-600 hover:underline font-medium">Password dimenticata?</a>
                </div>
            </div>

            <div>
                <button type="submit" class="w-full bg-blue-600 text-white py-3 px-4 rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition">
                    Accedi
                </button>
            </div>
        </form>

        <div class="mt-6 text-center text-sm text-gray-600">
            Non hai un account? <a href="<?php echo e($registerLink); ?>" class="text-blue-600 hover:underline font-medium">Registrati qui</a>
        </div>
    </div>

     <?php if (!isLoggedIn() && isset($adminLink)):?>
         <div class="mt-8 bg-blue-50 rounded-lg p-4">
             <h3 class="font-semibold text-blue-700 mb-2">Accesso amministratore</h3>
             <p class="text-sm text-gray-700 mb-3">
                 Se sei un amministratore, accedi per gestire contenuti e utenti.
             </p>
             <a href="<?php echo e($adminLink); ?>" class="text-blue-600 hover:underline text-sm font-medium">
                 Vai al pannello di amministrazione &rarr;
             </a>
         </div>
     <?php endif; ?>

</div>

<?php
$additionalScripts = '
<script nonce="' . e($cspNonce) . '">
    document.addEventListener("DOMContentLoaded", function() {
        const form = document.querySelector("form");
        if (!form) return;

        const emailUsernameInput = document.getElementById("email_username");
        const passwordInput = document.getElementById("password");

        // Functions showValidationErrors and clearValidationErrors are expected from main.js
        // Ensure main.js is loaded, or define them here if this page is standalone.

        form.addEventListener("submit", function(event) {
            let isValid = true;
            clearValidationErrors(emailUsernameInput);
            clearValidationErrors(passwordInput);

            if (!emailUsernameInput.value.trim()) {
                isValid = false;
                showValidationErrors(emailUsernameInput, ["Il campo Email o Nome Utente è obbligatorio."]);
            }
            if (!passwordInput.value.trim()) {
                isValid = false;
                showValidationErrors(passwordInput, ["Il campo Password è obbligatorio."]);
            }

            if (!isValid) {
                event.preventDefault();
                const firstInvalidField = form.querySelector(".is-invalid");
                if (firstInvalidField) {
                    firstInvalidField.focus();
                }
            }
        });
        
        // Simplified real-time feedback examples
        emailUsernameInput.addEventListener("input", function() { clearValidationErrors(this); });
        passwordInput.addEventListener("input", function() { clearValidationErrors(this); });

        // Link server-side errors to ARIA attributes on page load
        form.querySelectorAll(".is-invalid").forEach(invalidInput => {
            const errorId = invalidInput.id + "-error";
            const errorSpan = document.getElementById(errorId);
            if (errorSpan && errorSpan.textContent.trim() !== "") { // If PHP rendered an error
                 invalidInput.setAttribute("aria-describedby", errorId);
                 invalidInput.setAttribute("aria-invalid", "true");
                 errorSpan.setAttribute("aria-live", "polite");
                 errorSpan.setAttribute("aria-atomic", "true");
            } else if (errorSpan) { // Clear ARIA if no error text from server
                 invalidInput.removeAttribute("aria-describedby");
                 invalidInput.removeAttribute("aria-invalid");
                 errorSpan.removeAttribute("aria-live");
                 errorSpan.removeAttribute("aria-atomic");
            }
        });
    });
</script>
';
include __DIR__ . '/../includes/footer.php';
?>

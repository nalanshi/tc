<?php
// pages/recupero-password.php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php'; 
require_once __DIR__ . '/../models/User.php';

if (isLoggedIn()) {
     header("Location: profilo-utente.php"); 
     exit;
}

$pageTitle = "Recupera Password";
$currentPage = 'password-recovery'; 

$errorMessages = [];
$successMessage = '';
$step = 'request_email'; // 'request_email', 'enter_token_password'
$csrfToken = generateCsrfToken();
$emailForReset = ''; // To repopulate email field if needed

// Check if a token and selector are present in URL (from "email link")
if (isset($_GET['selector']) && isset($_GET['verifier'])) {
    $_SESSION['reset_selector'] = $_GET['selector'];
    $_SESSION['reset_verifier'] = $_GET['verifier']; // Store verifier temporarily for form submission
    $step = 'enter_token_password';
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errorMessages[] = "Richiesta non valida o sessione scaduta. Riprova.";
    } else {
        if (isset($_POST['action']) && $_POST['action'] === 'request_reset') {
            $email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));
            $emailForReset = $email; // For repopulation

            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errorMessages['email'] = "Inserisci un indirizzo email valido.";
            } else {
                try {
                    $user = User::getByEmail($email);
                    if ($user) {
                        // User exists, create and "send" token
                        $tokenParts = createPasswordResetTokenForUser($user->user_id);
                        if ($tokenParts) {
                            $resetLink = htmlspecialchars($_SERVER['PHP_SELF']) . "?selector=" . urlencode($tokenParts['selector']) . "&verifier=" . urlencode($tokenParts['verifier']);
                            $successMessage = "Se l'indirizzo email è associato a un account, riceverai un'email con le istruzioni per reimpostare la password (simulazione).";
                            // For testing/simulation, display the link:
                            $successMessage .= "<br><br><strong>Link di test (solo per simulazione):</strong> <a href='{$resetLink}' class='text-blue-600 underline'>{$resetLink}</a>";
                            error_log("Password reset token generated for email {$email}. Selector: {$tokenParts['selector']}");
                        } else {
                            $errorMessages['token_creation'] = "Impossibile generare il token di reset. Riprova più tardi.";
                        }
                    } else {
                        // Email not found - show generic message for security
                        $successMessage = "Se l'indirizzo email è associato a un account, riceverai un'email con le istruzioni per reimpostare la password (simulazione).";
                        error_log("Password reset request for non-existent email: {$email}");
                    }
                } catch (PDOException $e) {
                    error_log("Database error during password reset request for '{$email}': " . $e->getMessage());
                    if (strpos(strtolower($e->getMessage()), "table") !== false && strpos(strtolower($e->getMessage()), "password_resets") !== false && strpos(strtolower($e->getMessage()), "doesn't exist") !== false) {
                        $errorMessages['db_setup'] = "Errore di configurazione: la tabella per i reset password non esiste. Contattare l'amministratore.";
                    } else {
                        $errorMessages['db_error'] = "Si è verificato un errore del database. Riprova più tardi.";
                    }
                }
            }
        } elseif (isset($_POST['action']) && $_POST['action'] === 'reset_password') {
            $step = 'enter_token_password'; // Stay on this step if errors
            $selector = $_SESSION['reset_selector'] ?? '';
            $verifier = $_POST['verifier_from_session_or_hidden'] ?? ($_SESSION['reset_verifier'] ?? ''); // Prioritize POST if used as hidden, else session
            
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';

            if (empty($selector) || empty($verifier)) {
                 $errorMessages['token_missing'] = "Token di reset non valido o mancante. Riprova dalla richiesta email.";
                 $step = 'request_email'; // Force back to start
                 unset($_SESSION['reset_selector'], $_SESSION['reset_verifier']);
            } else {
                $userId = getUserIdFromValidPasswordResetToken($selector, $verifier);

                if ($userId) {
                    // Token is valid, validate password
                    if (empty($newPassword)) {
                        $errorMessages['new_password'] = "La nuova password è obbligatoria.";
                    } else {
                        $passwordValidation = validatePassword($newPassword); // from validators.js (conceptual, PHP equiv.)
                        if (strlen($newPassword) < 8 || !preg_match('/[A-Z]/', $newPassword) || !preg_match('/[a-z]/', $newPassword) || !preg_match('/\d/', $newPassword)) {
                             $errorMessages['password_strength'] = "La password deve avere almeno 8 caratteri, una maiuscola, una minuscola e un numero.";
                        }
                    }

                    if (empty($confirmPassword)) {
                        $errorMessages['confirm_password'] = "La conferma password è obbligatoria.";
                    } elseif ($newPassword !== $confirmPassword) {
                        $errorMessages['password_match'] = "Le password non corrispondono.";
                    }

                    if (empty($errorMessages)) {
                        $userToUpdate = User::getById($userId);
                        if ($userToUpdate && $userToUpdate->setPassword($newPassword) && $userToUpdate->save()) {
                            deletePasswordResetTokenBySelector($selector); // Clean up token
                            unset($_SESSION['reset_selector'], $_SESSION['reset_verifier']);
                            $_SESSION['password_reset_success'] = "La tua password è stata reimpostata con successo! Ora puoi accedere.";
                            header("Location: accesso.php");
                            exit;
                        } else {
                            $errorMessages['update_failed'] = "Errore durante l'aggiornamento della password. Riprova.";
                            error_log("Failed to update password for user ID {$userId} after reset token validation.");
                        }
                    }
                } else {
                    $errorMessages['token_invalid'] = "Token di reset non valido, scaduto o già utilizzato. Richiedine uno nuovo.";
                    $step = 'request_email'; // Force back to start
                    unset($_SESSION['reset_selector'], $_SESSION['reset_verifier']);
                }
            }
        }
    }
    $csrfToken = generateCsrfToken(); // Regenerate
}

// Include header
include __DIR__ . '/../includes/header.php';
?>

<div class="w-full max-w-md mx-auto">
    <h1 class="text-3xl font-bold text-center text-gray-900 mb-8">Recupera la Tua Password</h1>

    <?php if (!empty($successMessage) && empty($errorMessages)): // Show success only if no errors ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="status">
            <p class="font-bold">Operazione Avviata</p>
            <div><?php echo $successMessage; // Allows HTML in message for the link ?></div>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($errorMessages)): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert" aria-atomic="true">
            <p class="font-bold">Errore</p>
            <ul class="mt-2 list-disc list-inside text-sm">
                <?php foreach ($errorMessages as $field => $errorMessage): ?>
                    <li><?php echo htmlspecialchars($errorMessage); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow-md p-6 md:p-8">
        <?php if ($step === 'request_email' && empty($successMessage)): ?>
            <p class="text-gray-700 mb-6 text-sm">Inserisci l'indirizzo email associato al tuo account. Ti invieremo (simulazione) un link per reimpostare la password.</p>
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" class="space-y-6" novalidate>
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                <input type="hidden" name="action" value="request_reset">
                <div class="form-field-container">
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email*</label>
                    <input type="email" id="email" name="email"
                           class="w-full px-3 py-2 border <?php echo isset($errorMessages['email']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                           required value="<?php echo htmlspecialchars($emailForReset); ?>" autocomplete="email">
                    <span id="email-error" class="error-text text-xs text-red-600 mt-1" aria-live="polite"></span>
                </div>
                <div>
                    <button type="submit" class="w-full bg-blue-600 text-white py-3 px-4 rounded-md shadow-sm hover:bg-blue-700 transition">
                        Invia Link di Reset
                    </button>
                </div>
            </form>
        <?php elseif ($step === 'enter_token_password'): ?>
            <p class="text-gray-700 mb-6 text-sm">Token ricevuto. Inserisci la tua nuova password.</p>
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" class="space-y-6" novalidate>
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                <input type="hidden" name="action" value="reset_password">
                <?php // Pass verifier via hidden field if not relying solely on session, selector is implicitly from session/URL handling ?>
                <input type="hidden" name="verifier_from_session_or_hidden" value="<?php echo htmlspecialchars($_SESSION['reset_verifier'] ?? ''); ?>">


                <div class="form-field-container">
                    <label for="new_password" class="block text-sm font-medium text-gray-700 mb-1">Nuova Password*</label>
                    <input type="password" id="new_password" name="new_password"
                           class="w-full px-3 py-2 border <?php echo isset($errorMessages['new_password']) || isset($errorMessages['password_strength']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                           required aria-describedby="password-requirements-desc new_password-error" autocomplete="new-password">
                    <p id="password-requirements-desc" class="mt-1 text-xs text-gray-500 input-description">Min. 8 caratteri, 1 maiuscola, 1 minuscola, 1 numero.</p>
                    <span id="new_password-error" class="error-text text-xs text-red-600 mt-1" aria-live="polite"></span>
                </div>
                <div class="form-field-container">
                    <label for="confirm_password" class="block text-sm font-medium text-gray-700 mb-1">Conferma Nuova Password*</label>
                    <input type="password" id="confirm_password" name="confirm_password"
                           class="w-full px-3 py-2 border <?php echo isset($errorMessages['confirm_password']) || isset($errorMessages['password_match']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                           required aria-describedby="confirm_password-error" autocomplete="new-password">
                    <span id="confirm_password-error" class="error-text text-xs text-red-600 mt-1" aria-live="polite"></span>
                </div>
                <div>
                    <button type="submit" class="w-full bg-blue-600 text-white py-3 px-4 rounded-md shadow-sm hover:bg-blue-700 transition">
                        Reimposta Password
                    </button>
                </div>
            </form>
        <?php endif; ?>
        <div class="mt-6 text-center text-sm text-gray-600">
            Ricordi la password? <a href="<?php echo htmlspecialchars($loginLink); ?>" class="text-blue-600 hover:underline font-medium">Accedi qui</a>
        </div>
    </div>
</div>

<?php
// $validatorsJsPath is defined in header.php
$additionalScripts = '
<script>
document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("form");
    if (!form) return;

    form.addEventListener("submit", function(event) {
        let isValid = true;
        const action = form.querySelector("input[name=\'action\']").value;

        if (action === "request_reset") {
            const emailInput = document.getElementById("email");
            clearValidationErrors(emailInput);
            if (!emailInput.value.trim()) {
                isValid = false;
                showValidationErrors(emailInput, ["L\'indirizzo email è obbligatorio."]);
            } else if (!validateEmail(emailInput.value)) {
                isValid = false;
                showValidationErrors(emailInput, ["Inserisci un indirizzo email valido."]);
            }
        } else if (action === "reset_password") {
            const newPasswordInput = document.getElementById("new_password");
            const confirmPasswordInput = document.getElementById("confirm_password");
            clearValidationErrors(newPasswordInput);
            clearValidationErrors(confirmPasswordInput);

            const passwordValidation = validatePassword(newPasswordInput.value);
            if (!passwordValidation.isValid) {
                isValid = false;
                showValidationErrors(newPasswordInput, passwordValidation.errors);
            }
            if (!confirmPasswordInput.value.trim()) {
                isValid = false;
                showValidationErrors(confirmPasswordInput, ["La conferma password è obbligatoria."]);
            } else if (!passwordsMatch(newPasswordInput.value, confirmPasswordInput.value)) {
                isValid = false;
                showValidationErrors(confirmPasswordInput, ["Le password non corrispondono."]);
            }
        }

        if (!isValid) {
            event.preventDefault();
            const firstInvalidField = form.querySelector(".border-red-500, input[aria-invalid=\'true\']");
            if (firstInvalidField) {
                firstInvalidField.focus();
            }
        }
    });
});
</script>
';
include __DIR__ . '/../includes/footer.php';
?>






<?php
// pages/admin/prodotti.php
require_once __DIR__ . '/includes/admin_auth_check.php';
require_once __DIR__ . '/../../models/Product.php';
require_once __DIR__ . '/../../models/Category.php';

$pageTitleAdmin = "Gestione Prodotti";

// Delete action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_product') {
    if (!isset($_POST['product_id']) || !is_numeric($_POST['product_id'])) {
        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'ID prodotto non valido per l\'eliminazione.'];
    } elseif (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Richiesta di eliminazione non valida (CSRF token error).'];
    } else {
        $productIdToDelete = (int)$_POST['product_id'];
        try {
            $product = Product::getById($productIdToDelete);
            if ($product) {
                if ($product->delete()) {
                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Prodotto "' . htmlspecialchars($product->name) . '" eliminato con successo.'];
                } else {
                    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Impossibile eliminare il prodotto. Potrebbe essere già stato eliminato o si è verificato un errore.'];
                }
            } else {
                $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Prodotto non trovato per l\'eliminazione.'];
            }
        } catch (PDOException $e) {
            error_log("Errore eliminazione prodotto ID {$productIdToDelete}: " . $e->getMessage());
            $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore database durante l\'eliminazione del prodotto.'];
        }
    }
    // Regenerate CSRF token to prevent reuse on reload if an error occurred before redirect
    $csrfToken = generateCsrfToken(); 
    // Redirect to self to prevent form resubmission on refresh and to show flash message
    header("Location: prodotti.php" . (isset($_GET['page']) ? "?page=" . $_GET['page'] : ""));
    exit;
}


// Pagination
$productsPerPage = 10;
$pageNumber = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($pageNumber < 1) $pageNumber = 1;
$offset = ($pageNumber - 1) * $productsPerPage;

$products = [];
$totalProducts = 0;
try {
    // For admin, order by created_at DESC or name ASC might be useful. Let's use name ASC.
    $products = Product::getAll(null, $productsPerPage, $offset, 'name', 'ASC');
    $totalProducts = Product::countAll();
} catch (PDOException $e) {
    error_log("Admin Prodotti: Errore caricamento prodotti: " . $e->getMessage());
    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore nel caricamento dell\'elenco prodotti.'];
}
$totalPages = ceil($totalProducts / $productsPerPage);
if ($pageNumber > $totalPages && $totalProducts > 0) {
    header("Location: prodotti.php?page=" . $totalPages);
    exit;
}

// Generate a new CSRF token for delete forms
$csrfToken = generateCsrfToken();

include __DIR__ . '/includes/admin_layout_header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-900">Elenco Prodotti</h1>
        <a href="prodotto_gestisci.php" class="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded shadow-md transition duration-150">
            <span class="mr-1">➕</span> Aggiungi Prodotto
        </a>
    </div>

    <?php if (isset($_SESSION['flash_message'])): ?>
    <div class="mb-6 p-4 rounded-md <?php echo $_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 border-green-500 text-green-700' : 'bg-red-100 border-red-500 text-red-700'; ?>" role="alert">
        <p><?php echo htmlspecialchars($_SESSION['flash_message']['message']); ?></p>
    </div>
    <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <?php if (empty($products) && $totalProducts === 0 && !isset($_SESSION['flash_message'])): ?>
        <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4" role="alert">
            <p class="font-bold">Nessun Prodotto</p>
            <p>Non ci sono ancora prodotti nel database. <a href="prodotto_gestisci.php" class="font-medium underline hover:text-yellow-800">Aggiungine uno ora!</a></p>
        </div>
    <?php elseif (!empty($products)): ?>
    <div class="bg-white shadow-md rounded-lg overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Immagine</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nome Prodotto</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Categoria</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data Creazione</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Azioni</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php foreach ($products as $product): 
                    $categoryName = 'N/A';
                    if ($product->category_id) {
                        $category = $product->getCategory(); // Uses cached or fetches
                        if ($category) $categoryName = $category->name;
                    }
                ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <img src="<?php echo !empty($product->image_url) ? htmlspecialchars($product->image_url) : '../../../assets/placeholder.svg'; ?>" 
                             alt="Immagine <?php echo htmlspecialchars($product->name); ?>" class="h-12 w-12 object-cover rounded-md">
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($product->name); ?></div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <?php echo htmlspecialchars($categoryName); ?>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <?php echo date("d/m/Y H:i", strtotime($product->created_at)); ?>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                        <a href="prodotto_gestisci.php?id_prodotto=<?php echo $product->product_id; ?>" class="text-indigo-600 hover:text-indigo-900">Modifica</a>
                        <form action="prodotti.php<?php echo (isset($_GET['page']) ? "?page=" . $_GET['page'] : ""); ?>" method="POST" class="inline-block" onsubmit="return confirmAdminDelete(event, 'Sei sicuro di voler eliminare il prodotto \'<?php echo htmlspecialchars(addslashes($product->name)); ?>\'? L\'azione non può essere annullata.');">
                            <input type="hidden" name="action" value="delete_product">
                            <input type="hidden" name="product_id" value="<?php echo $product->product_id; ?>">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                            <button type="submit" class="text-red-600 hover:text-red-900">Elimina</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

        <?php if ($totalPages > 1): ?>
        <nav aria-label="Navigazione pagine prodotti" class="mt-6 flex justify-center">
            <ul class="inline-flex items-center -space-x-px rounded-md shadow-sm">
                <?php if ($pageNumber > 1): ?>
                <li>
                    <a href="?page=<?php echo $pageNumber - 1; ?>"
                       class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700">
                        <span class="sr-only">Precedente</span>&laquo;
                    </a>
                </li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li>
                    <a href="?page=<?php echo $i; ?>"
                       class="py-2 px-3 leading-tight <?php echo ($i == $pageNumber) ? 'text-blue-600 bg-blue-50 border-blue-500 z-10' : 'text-gray-500 bg-white border-gray-300 hover:bg-gray-100 hover:text-gray-700'; ?>">
                        <?php echo $i; ?>
                    </a>
                </li>
                <?php endfor; ?>

                <?php if ($pageNumber < $totalPages): ?>
                <li>
                    <a href="?page=<?php echo $pageNumber + 1; ?>"
                       class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700">
                        <span class="sr-only">Successiva</span>&raquo;
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php
include __DIR__ . '/includes/admin_layout_footer.php';
?>




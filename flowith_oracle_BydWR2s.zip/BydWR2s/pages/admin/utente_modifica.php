<?php
// pages/admin/utente_modifica.php
require_once __DIR__ . '/includes/admin_auth_check.php';
require_once __DIR__ . '/../../models/User.php';

$pageTitleAdmin = "Modifica Ruolo Utente";
$currentLoggedInAdminId = getCurrentUser()->user_id;

$userIdToEdit = null;
$user = null;
$errorMessages = [];
$successMessage = '';

if (isset($_GET['user_id'])) {
    $userIdToEdit = (int)$_GET['user_id'];
    try {
        $user = User::getById($userIdToEdit);
        if (!$user) {
            $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Utente non trovato.'];
            header("Location: utenti.php");
            exit;
        }
    } catch (PDOException $e) {
        error_log("Admin Modifica Utente - Errore caricamento utente: " . $e->getMessage());
        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore database durante il caricamento dell\'utente.'];
        header("Location: utenti.php");
        exit;
    }
} else {
    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'ID Utente non specificato.'];
    header("Location: utenti.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_role') {
    if (isset($_POST['user_id'], $_POST['role'], $_POST['csrf_token']) && verifyCsrfToken($_POST['csrf_token'])) {
        $postedUserId = (int)$_POST['user_id'];
        $newRole = $_POST['role'];

        if ($postedUserId !== $userIdToEdit) {
            $errorMessages[] = "ID utente non corrisponde.";
        } elseif (!in_array($newRole, ['user', 'admin'])) {
            $errorMessages[] = "Ruolo non valido selezionato.";
        } elseif ($user->user_id === $currentLoggedInAdminId && $user->role === 'admin' && $newRole === 'user') {
            // Prevent admin from demoting themselves if they are the only admin or just self-demoting
             $allAdmins = User::getAllPaginated(null, 0, 'role', 'ASC'); 
             $adminCount = 0;
             foreach ($allAdmins as $u) {
                 if ($u->hasRole('admin')) $adminCount++;
             }
             if ($adminCount <= 1) {
                  $errorMessages[] = 'Non puoi rimuovere il ruolo di amministratore da te stesso se sei l\'unico amministratore.';
             } else {
                 // Allow self-demotion if other admins exist.
                 try {
                     if ($user->updateRole($newRole)) {
                         $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Ruolo utente aggiornato con successo. Sei stato declassato a Utente.'];
                         // If admin demotes self, redirect to non-admin page perhaps, or show message and they get booted on next auth check.
                         // For now, redirect to user list.
                         header("Location: utenti.php" . (isset($_GET['source_page']) ? "?page=" . $_GET['source_page'] : ""));
                         exit;
                     } else {
                         $errorMessages[] = 'Nessuna modifica apportata o errore durante l\'aggiornamento del ruolo.';
                     }
                 } catch (PDOException $e) {
                     error_log("Admin Modifica Utente - Errore aggiornamento ruolo: " . $e->getMessage());
                     $errorMessages[] = 'Errore database durante l\'aggiornamento del ruolo.';
                 }
             }
        } else { // Not self-demoting the last admin
            try {
                if ($user->updateRole($newRole)) {
                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Ruolo utente aggiornato con successo.'];
                    header("Location: utenti.php" . (isset($_GET['source_page']) ? "?page=" . $_GET['source_page'] : ""));
                    exit;
                } else {
                    $errorMessages[] = 'Nessuna modifica apportata o errore durante l\'aggiornamento del ruolo.';
                }
            } catch (PDOException $e) {
                error_log("Admin Modifica Utente - Errore aggiornamento ruolo: " . $e->getMessage());
                $errorMessages[] = 'Errore database durante l\'aggiornamento del ruolo.';
            }
        }
    } else {
        $errorMessages[] = 'Richiesta non valida o token CSRF mancante/errato.';
    }
    // Regenerate CSRF for the form if errors occurred
    $csrfToken = generateCsrfToken();
} else {
    $csrfToken = generateCsrfToken(); // Initial token for the form
}

$sourcePageParam = isset($_GET['source_page']) ? "&source_page=" . htmlspecialchars($_GET['source_page']) : "";

include __DIR__ . '/includes/admin_layout_header.php';
?>

<div class="container mx-auto px-4 py-8">
    <header class="mb-6">
        <h1 class="text-3xl font-bold text-gray-900"><?php echo htmlspecialchars($pageTitleAdmin); ?>: <?php echo htmlspecialchars($user->username); ?></h1>
        <a href="utenti.php<?php echo isset($_GET['source_page']) ? "?page=" . $_GET['source_page'] : ""; ?>" class="text-blue-600 hover:underline text-sm">&laquo; Torna all'elenco utenti</a>
    </header>

    <?php if (!empty($errorMessages)): ?>
    <div class="mb-6 bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md" role="alert">
        <p class="font-bold">Attenzione!</p>
        <ul class="list-disc list-inside ml-4">
            <?php foreach ($errorMessages as $error): ?>
            <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if ($successMessage): ?>
    <div class="mb-6 bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded-md" role="alert">
        <p><?php echo htmlspecialchars($successMessage); ?></p>
    </div>
    <?php endif; ?>


    <div class="bg-white p-6 md:p-8 rounded-lg shadow-md max-w-lg mx-auto">
        <form action="utente_modifica.php?user_id=<?php echo $user->user_id; ?><?php echo $sourcePageParam; ?>" method="POST" class="space-y-6">
            <input type="hidden" name="action" value="update_role">
            <input type="hidden" name="user_id" value="<?php echo $user->user_id; ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

            <div>
                <p class="text-sm text-gray-600"><strong>ID Utente:</strong> <?php echo $user->user_id; ?></p>
                <p class="text-sm text-gray-600"><strong>Username:</strong> <?php echo htmlspecialchars($user->username); ?></p>
                <p class="text-sm text-gray-600"><strong>Email:</strong> <?php echo htmlspecialchars($user->email); ?></p>
            </div>

            <div>
                <label for="role" class="block text-sm font-medium text-gray-700 mb-1">Ruolo Attuale: <?php echo htmlspecialchars(ucfirst($user->role)); ?></label>
                <select id="role" name="role" required
                        class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                    <option value="user" <?php echo ($user->role === 'user') ? 'selected' : ''; ?>>User</option>
                    <option value="admin" <?php echo ($user->role === 'admin') ? 'selected' : ''; ?>>Admin</option>
                </select>
            </div>
            
            <?php if ($user->user_id === $currentLoggedInAdminId && $user->role === 'admin'): ?>
                <p class="text-sm text-yellow-700 bg-yellow-100 p-3 rounded-md">
                    Attenzione: Stai modificando il tuo ruolo. Se ti declassi da amministratore e non ci sono altri amministratori, potresti perdere l'accesso al pannello.
                </p>
            <?php endif; ?>


            <div class="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200">
                <a href="utenti.php<?php echo isset($_GET['source_page']) ? "?page=" . $_GET['source_page'] : ""; ?>" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-md shadow-sm transition">Annulla</a>
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md shadow-sm transition">
                    Salva Modifiche Ruolo
                </button>
            </div>
        </form>
    </div>
</div>

<?php
include __DIR__ . '/includes/admin_layout_footer.php';
?>



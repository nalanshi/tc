<?php
// pages/admin/prodotto_gestisci.php
require_once __DIR__ . '/includes/admin_auth_check.php';
require_once __DIR__ . '/../../models/Product.php';
require_once __DIR__ . '/../../models/Category.php';

$productId = isset($_GET['id_prodotto']) ? (int)$_GET['id_prodotto'] : 0;
$isEditing = $productId > 0;
$pageTitleAdmin = $isEditing ? "Modifica Prodotto" : "Aggiungi Nuovo Prodotto";

$productData = [
    'name' => '',
    'description' => '',
    'category_id' => null,
    'image_url' => ''
];
$categories = [];
$errorMessages = []; // For form validation

try {
    $categories = Category::getAll('name', 'ASC');
} catch (PDOException $e) {
    error_log("Errore caricamento categorie per form prodotto: " . $e->getMessage());
    $errorMessages['categories_load'] = "Impossibile caricare le categorie. Riprova più tardi.";
}

if ($isEditing) {
    try {
        $product = Product::getById($productId);
        if ($product) {
            $productData['name'] = $product->name;
            $productData['description'] = $product->description;
            $productData['category_id'] = $product->category_id;
            $productData['image_url'] = $product->image_url;
        } else {
            $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Prodotto non trovato per la modifica.'];
            header("Location: prodotti.php");
            exit;
        }
    } catch (PDOException $e) {
        error_log("Errore caricamento prodotto ID {$productId} per modifica: " . $e->getMessage());
        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore database nel caricare il prodotto per la modifica.'];
        header("Location: prodotti.php");
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $errorMessages['csrf'] = 'Richiesta non valida o sessione scaduta. Riprova.';
    } else {
        $productData['name'] = trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
        $productData['description'] = trim(filter_input(INPUT_POST, 'description', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
        $productData['category_id'] = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);
        $productData['image_url'] = trim(filter_input(INPUT_POST, 'image_url', FILTER_SANITIZE_URL));

        // Basic Validation
        if (empty($productData['name'])) {
            $errorMessages['name'] = 'Il nome del prodotto è obbligatorio.';
        }
        if ($productData['category_id'] === false || $productData['category_id'] < 0) { // Allow 0 or null for "no category"
             $productData['category_id'] = null; // Treat invalid as no category
        } elseif ($productData['category_id'] !== null && $productData['category_id'] > 0) {
            // Check if category exists
            $categoryExists = false;
            foreach ($categories as $cat) {
                if ($cat->category_id == $productData['category_id']) {
                    $categoryExists = true;
                    break;
                }
            }
            if (!$categoryExists) {
                $errorMessages['category_id'] = 'La categoria selezionata non è valida.';
                $productData['category_id'] = null; // Reset if invalid
            }
        }


        if (!empty($productData['image_url']) && !filter_var($productData['image_url'], FILTER_VALIDATE_URL)) {
            $errorMessages['image_url'] = 'L\'URL dell\'immagine non è valido.';
        }

        if (empty($errorMessages)) {
            try {
                $productToSave = $isEditing ? Product::getById($productId) : new Product([]);
                if (!$productToSave && $isEditing) { // Should not happen if initial load was ok
                     $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Prodotto non trovato durante il salvataggio.'];
                     header("Location: prodotti.php");
                     exit;
                } elseif (!$productToSave) { // New Product instance
                     $productToSave = new Product([]);
                }

                $productToSave->name = $productData['name'];
                $productToSave->description = $productData['description'];
                // Handle category_id potentially being 0 or empty string from form, convert to null
                $productToSave->category_id = ($productData['category_id'] > 0) ? $productData['category_id'] : null;
                $productToSave->image_url = !empty($productData['image_url']) ? $productData['image_url'] : null;

                if ($productToSave->save()) {
                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Prodotto "' . htmlspecialchars($productToSave->name) . '" ' . ($isEditing ? 'modificato' : 'aggiunto') . ' con successo.'];
                    header("Location: prodotti.php");
                    exit;
                } else {
                    $errorMessages['save'] = 'Errore durante il salvataggio del prodotto. Nessuna modifica apportata o errore imprevisto.';
                }
            } catch (PDOException $e) {
                error_log("Errore salvataggio prodotto: " . $e->getMessage());
                $errorMessages['db'] = 'Errore database durante il salvataggio del prodotto.';
                 if ($e->getCode() == '23000') { // Unique constraint
                     $errorMessages['db'] = 'Errore: Esiste già un prodotto con dettagli simili (es. nome).';
                 }
            }
        }
    }
    // Regenerate CSRF token after POST (important if form is redisplayed with errors)
    $csrfToken = generateCsrfToken();
} else {
    // Generate token for initial form load
    $csrfToken = generateCsrfToken();
}


include __DIR__ . '/includes/admin_layout_header.php';
?>

<div class="container mx-auto px-4 py-8">
    <header class="mb-6">
        <h1 class="text-3xl font-bold text-gray-900"><?php echo htmlspecialchars($pageTitleAdmin); ?></h1>
        <a href="prodotti.php" class="text-blue-600 hover:underline text-sm">&laquo; Torna all'elenco prodotti</a>
    </header>

    <?php if (!empty($errorMessages)): ?>
    <div class="mb-6 bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md" role="alert">
        <p class="font-bold">Attenzione!</p>
        <ul class="list-disc list-inside ml-4">
            <?php foreach ($errorMessages as $error): ?>
            <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="bg-white p-6 md:p-8 rounded-lg shadow-md">
        <form action="prodotto_gestisci.php<?php echo $isEditing ? '?id_prodotto=' . $productId : ''; ?>" method="POST" class="space-y-6">
            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

            <div>
                <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Nome Prodotto*</label>
                <input type="text" id="name" name="name" required
                       class="w-full px-3 py-2 border <?php echo isset($errorMessages['name']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                       value="<?php echo htmlspecialchars($productData['name']); ?>">
                <?php if(isset($errorMessages['name'])): ?><p class="text-xs text-red-600 mt-1"><?php echo $errorMessages['name']; ?></p><?php endif; ?>
            </div>

            <div>
                <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Descrizione</label>
                <textarea id="description" name="description" rows="4"
                          class="w-full px-3 py-2 border <?php echo isset($errorMessages['description']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"><?php echo htmlspecialchars($productData['description']); ?></textarea>
                <?php if(isset($errorMessages['description'])): ?><p class="text-xs text-red-600 mt-1"><?php echo $errorMessages['description']; ?></p><?php endif; ?>
            </div>

            <div>
                <label for="category_id" class="block text-sm font-medium text-gray-700 mb-1">Categoria</label>
                <select id="category_id" name="category_id"
                        class="w-full px-3 py-2 border <?php echo isset($errorMessages['category_id']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                    <option value="">-- Seleziona Categoria --</option>
                    <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category->category_id; ?>" <?php echo ($productData['category_id'] == $category->category_id) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($category->name); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <?php if(isset($errorMessages['category_id'])): ?><p class="text-xs text-red-600 mt-1"><?php echo $errorMessages['category_id']; ?></p><?php endif; ?>
                 <?php if(isset($errorMessages['categories_load'])): ?><p class="text-xs text-red-600 mt-1"><?php echo $errorMessages['categories_load']; ?></p><?php endif; ?>
            </div>

            <div>
                <label for="image_url" class="block text-sm font-medium text-gray-700 mb-1">URL Immagine</label>
                <input type="url" id="image_url" name="image_url"
                       class="w-full px-3 py-2 border <?php echo isset($errorMessages['image_url']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                       value="<?php echo htmlspecialchars($productData['image_url']); ?>" placeholder="https://esempio.com/immagine.jpg">
                <?php if(isset($errorMessages['image_url'])): ?><p class="text-xs text-red-600 mt-1"><?php echo $errorMessages['image_url']; ?></p><?php endif; ?>
            </div>

            <div class="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200">
                <a href="prodotti.php" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-md shadow-sm transition">Annulla</a>
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md shadow-sm transition">
                    <?php echo $isEditing ? 'Salva Modifiche' : 'Aggiungi Prodotto'; ?>
                </button>
            </div>
        </form>
    </div>
</div>

<?php
include __DIR__ . '/includes/admin_layout_footer.php';
?>




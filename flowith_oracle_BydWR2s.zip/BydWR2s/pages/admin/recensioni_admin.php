<?php
// pages/admin/recensioni_admin.php
require_once __DIR__ . '/includes/admin_auth_check.php';
require_once __DIR__ . '/../../models/Review.php';
require_once __DIR__ . '/../../models/User.php'; // For user display
require_once __DIR__ . '/../../models/Product.php'; // For product display

$pageTitleAdmin = "Moderazione Recensioni";

// Handle Actions (Approve, Reject, Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['review_id'], $_POST['csrf_token'])) {
    if (verifyCsrfToken($_POST['csrf_token'])) {
        $reviewId = (int)$_POST['review_id'];
        $action = $_POST['action'];
        $review = Review::getById($reviewId);

        if ($review) {
            try {
                $success = false;
                if ($action === 'approve_review') {
                    $success = $review->approve();
                    if ($success) $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Recensione approvata.'];
                } elseif ($action === 'reject_review') { // Reject means set to not approved
                    $success = $review->reject();
                    if ($success) $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Recensione marcata come non approvata.'];
                } elseif ($action === 'delete_review') {
                    $success = $review->delete();
                    if ($success) $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Recensione eliminata.'];
                }
                if (!$success && !isset($_SESSION['flash_message'])) {
                     $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Azione sulla recensione fallita o nessuna modifica apportata.'];
                }
            } catch (PDOException $e) {
                error_log("Admin Recensioni - Errore azione: " . $e->getMessage());
                $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore database durante l\'azione sulla recensione.'];
            }
        } else {
            $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Recensione non trovata.'];
        }
    } else {
        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Richiesta non valida o token CSRF errato.'];
    }
    // Regenerate CSRF token after POST & redirect
    $csrfToken = generateCsrfToken();
    $redirectParams = (isset($_GET['page']) ? "page=" . $_GET['page'] : "") . (isset($_GET['status_filter']) ? "&status_filter=" . $_GET['status_filter'] : "");
    header("Location: recensioni_admin.php?" . $redirectParams);
    exit;
}


// Filtering
$statusFilter = $_GET['status_filter'] ?? 'all'; // 'all', 'pending', 'approved'
$validFilters = ['all', 'pending', 'approved'];
if (!in_array($statusFilter, $validFilters)) {
    $statusFilter = 'all';
}

// Pagination
$reviewsPerPage = 10;
$pageNumber = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($pageNumber < 1) $pageNumber = 1;
$offset = ($pageNumber - 1) * $reviewsPerPage;

$reviews = [];
$totalReviews = 0;

$modelStatusFilter = null;
if ($statusFilter === 'pending') $modelStatusFilter = 'pending';
if ($statusFilter === 'approved') $modelStatusFilter = 'approved';

try {
    // Order pending reviews by oldest first, approved by newest first
    $orderBy = ($statusFilter === 'pending') ? 'created_at' : 'updated_at';
    $orderDir = ($statusFilter === 'pending') ? 'ASC' : 'DESC';

    $reviews = Review::getAll($modelStatusFilter, $reviewsPerPage, $offset, $orderBy, $orderDir);
    $totalReviews = Review::countAll($modelStatusFilter);
} catch (PDOException $e) {
    error_log("Admin Recensioni: Errore caricamento recensioni: " . $e->getMessage());
    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore nel caricamento dell\'elenco recensioni.'];
}
$totalPages = ceil($totalReviews / $reviewsPerPage);
if ($pageNumber > $totalPages && $totalReviews > 0) {
    header("Location: recensioni_admin.php?page=" . $totalPages . ($statusFilter !== 'all' ? "&status_filter=".$statusFilter : ""));
    exit;
}

$csrfToken = generateCsrfToken();

include __DIR__ . '/includes/admin_layout_header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <h1 class="text-3xl font-bold text-gray-900">Moderazione Recensioni</h1>
        <div class="flex space-x-2">
            <a href="?status_filter=all<?php echo isset($_GET['page']) ? '&page='.$_GET['page'] : ''; ?>" class="px-4 py-2 text-sm rounded-md <?php echo $statusFilter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'; ?>">Tutte</a>
            <a href="?status_filter=pending<?php echo isset($_GET['page']) ? '&page='.$_GET['page'] : ''; ?>" class="px-4 py-2 text-sm rounded-md <?php echo $statusFilter === 'pending' ? 'bg-yellow-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'; ?>">In Attesa</a>
            <a href="?status_filter=approved<?php echo isset($_GET['page']) ? '&page='.$_GET['page'] : ''; ?>" class="px-4 py-2 text-sm rounded-md <?php echo $statusFilter === 'approved' ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'; ?>">Approvate</a>
        </div>
    </div>

    <?php if (isset($_SESSION['flash_message'])): ?>
    <div class="mb-6 p-4 rounded-md <?php echo $_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 border-green-500 text-green-700' : 'bg-red-100 border-red-500 text-red-700'; ?>" role="alert">
        <p><?php echo htmlspecialchars($_SESSION['flash_message']['message']); ?></p>
    </div>
    <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <?php if (empty($reviews) && $totalReviews === 0 && !isset($_SESSION['flash_message'])): ?>
        <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4" role="alert">
            <p class="font-bold">Nessuna Recensione</p>
            <p>Non ci sono recensioni che corrispondono ai filtri selezionati.</p>
        </div>
    <?php elseif (!empty($reviews)): ?>
    <div class="bg-white shadow-md rounded-lg overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prodotto</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Utente</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Valutazione</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Commento</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stato</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Azioni</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php foreach ($reviews as $review): 
                    $product = $review->getProduct();
                    $user = $review->getUser();
                ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($product ? $product->name : 'N/D'); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($user ? $user->username : 'N/D'); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-yellow-500">
                        <?php echo str_repeat('★', $review->rating) . str_repeat('☆', 5 - $review->rating); ?>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-500 max-w-xs truncate" title="<?php echo htmlspecialchars($review->comment_text); ?>"><?php echo htmlspecialchars(mb_substr($review->comment_text, 0, 50)) . (mb_strlen($review->comment_text) > 50 ? '...' : ''); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $review->is_approved ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'; ?>">
                            <?php echo $review->is_approved ? 'Approvata' : 'In Attesa'; ?>
                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <?php echo date("d/m/Y H:i", strtotime($review->created_at)); ?>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-1">
                        <?php if (!$review->is_approved): ?>
                        <form action="recensioni_admin.php?page=<?php echo $pageNumber; ?>&status_filter=<?php echo $statusFilter; ?>" method="POST" class="inline">
                            <input type="hidden" name="action" value="approve_review">
                            <input type="hidden" name="review_id" value="<?php echo $review->review_id; ?>">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                            <button type="submit" class="text-green-600 hover:text-green-900">Approva</button>
                        </form>
                        <?php else: ?>
                        <form action="recensioni_admin.php?page=<?php echo $pageNumber; ?>&status_filter=<?php echo $statusFilter; ?>" method="POST" class="inline">
                            <input type="hidden" name="action" value="reject_review"> <!-- "Reject" here means un-approve -->
                            <input type="hidden" name="review_id" value="<?php echo $review->review_id; ?>">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                            <button type="submit" class="text-yellow-600 hover:text-yellow-900">Rifiuta</button>
                        </form>
                        <?php endif; ?>
                        <a href="recensione_modifica.php?review_id=<?php echo $review->review_id; ?>&page=<?php echo $pageNumber; ?>&status_filter=<?php echo $statusFilter; ?>" class="text-indigo-600 hover:text-indigo-900">Modifica Testo</a>
                        <form action="recensioni_admin.php?page=<?php echo $pageNumber; ?>&status_filter=<?php echo $statusFilter; ?>" method="POST" class="inline" onsubmit="return confirmAdminDelete(event, 'Sei sicuro di voler eliminare questa recensione?');">
                            <input type="hidden" name="action" value="delete_review">
                            <input type="hidden" name="review_id" value="<?php echo $review->review_id; ?>">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                            <button type="submit" class="text-red-600 hover:text-red-900">Elimina</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php if ($totalPages > 1): ?>
    <nav aria-label="Navigazione pagine recensioni" class="mt-6 flex justify-center">
        <ul class="inline-flex items-center -space-x-px rounded-md shadow-sm">
            <?php if ($pageNumber > 1): ?>
            <li><a href="?page=<?php echo $pageNumber - 1; ?>&status_filter=<?php echo $statusFilter; ?>" class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700"><span class="sr-only">Precedente</span>&laquo;</a></li>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <li><a href="?page=<?php echo $i; ?>&status_filter=<?php echo $statusFilter; ?>" class="py-2 px-3 leading-tight <?php echo ($i == $pageNumber) ? 'text-blue-600 bg-blue-50 border-blue-500 z-10' : 'text-gray-500 bg-white border-gray-300 hover:bg-gray-100 hover:text-gray-700'; ?>" <?php echo ($i == $pageNumber) ? 'aria-current="page"' : ''; ?>><?php echo $i; ?></a></li>
            <?php endfor; ?>
            <?php if ($pageNumber < $totalPages): ?>
            <li><a href="?page=<?php echo $pageNumber + 1; ?>&status_filter=<?php echo $statusFilter; ?>" class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700"><span class="sr-only">Successiva</span>&raquo;</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <?php endif; ?>
    <?php endif; ?>
</div>
<?php
include __DIR__ . '/includes/admin_layout_footer.php';
?>



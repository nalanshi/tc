<?php
// pages/admin/recensione_modifica.php
require_once __DIR__ . '/includes/admin_auth_check.php';
require_once __DIR__ . '/../../models/Review.php';
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../models/Product.php';

$pageTitleAdmin = "Modifica Testo Recensione";

$reviewIdToEdit = null;
$review = null;
$errorMessages = [];
$successMessage = '';

// Get review ID from query string
if (isset($_GET['review_id'])) {
    $reviewIdToEdit = (int)$_GET['review_id'];
    try {
        $review = Review::getById($reviewIdToEdit);
        if (!$review) {
            $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Recensione non trovata.'];
            header("Location: recensioni_admin.php" . (isset($_GET['page']) ? "?page=" . $_GET['page'] : "") . (isset($_GET['status_filter']) ? "&status_filter=" . $_GET['status_filter'] : ""));
            exit;
        }
    } catch (PDOException $e) {
        error_log("Admin Modifica Recensione - Errore caricamento: " . $e->getMessage());
        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore database durante il caricamento della recensione.'];
        header("Location: recensioni_admin.php" . (isset($_GET['page']) ? "?page=" . $_GET['page'] : "") . (isset($_GET['status_filter']) ? "&status_filter=" . $_GET['status_filter'] : ""));
        exit;
    }
} else {
    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'ID Recensione non specificato.'];
    header("Location: recensioni_admin.php");
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_review_text') {
    if (isset($_POST['review_id'], $_POST['csrf_token'], $_POST['comment_text']) && verifyCsrfToken($_POST['csrf_token'])) {
        $postedReviewId = (int)$_POST['review_id'];

        if ($postedReviewId !== $reviewIdToEdit) {
            $errorMessages[] = "ID recensione non corrisponde.";
        } else {
            // Update only text fields and is_approved status. Rating is NOT changed by admin.
            $review->comment_text = trim($_POST['comment_text']);
            $review->pros = isset($_POST['pros']) ? trim($_POST['pros']) : null;
            $review->cons = isset($_POST['cons']) ? trim($_POST['cons']) : null;
            // Optionally, allow changing approval status from this form too
            if (isset($_POST['is_approved_checkbox'])) { // Checkbox for approval
                 $review->is_approved = true;
            } else {
                 $review->is_approved = false;
            }


            // Basic validation for comment text
            if (empty($review->comment_text)) {
                $errorMessages[] = "Il testo del commento non può essere vuoto.";
            } elseif (mb_strlen($review->comment_text) < 10) {
                 $errorMessages[] = "Il testo del commento deve essere di almeno 10 caratteri.";
            }

            if (empty($errorMessages)) {
                try {
                    if ($review->save()) { // The save method in Review model handles preserving rating.
                        $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Recensione aggiornata con successo.'];
                        header("Location: recensioni_admin.php" . (isset($_GET['page']) ? "?page=" . $_GET['page'] : "") . (isset($_GET['status_filter']) ? "&status_filter=" . $_GET['status_filter'] : ""));
                        exit;
                    } else {
                        $errorMessages[] = 'Nessuna modifica apportata o errore durante l\'aggiornamento della recensione.';
                    }
                } catch (PDOException $e) {
                    error_log("Admin Modifica Recensione - Errore salvataggio: " . $e->getMessage());
                    $errorMessages[] = 'Errore database durante l\'aggiornamento della recensione.';
                }
            }
        }
    } else {
        $errorMessages[] = 'Richiesta non valida o token CSRF mancante/errato.';
    }
    $csrfToken = generateCsrfToken(); // Regenerate token if error
} else {
    $csrfToken = generateCsrfToken(); // Initial token
}

$product = $review->getProduct();
$user = $review->getUser();
$returnToListParams = (isset($_GET['page']) ? "?page=" . htmlspecialchars($_GET['page']) : "") . (isset($_GET['status_filter']) ? (empty($_GET['page'])?"?":"&") . "status_filter=" . htmlspecialchars($_GET['status_filter']) : "");


include __DIR__ . '/includes/admin_layout_header.php';
?>

<div class="container mx-auto px-4 py-8">
    <header class="mb-6">
        <h1 class="text-3xl font-bold text-gray-900"><?php echo htmlspecialchars($pageTitleAdmin); ?></h1>
        <a href="recensioni_admin.php<?php echo $returnToListParams; ?>" class="text-blue-600 hover:underline text-sm">&laquo; Torna all'elenco recensioni</a>
    </header>

    <?php if (!empty($errorMessages)): ?>
    <div class="mb-6 bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md" role="alert">
        <p class="font-bold">Attenzione!</p>
        <ul class="list-disc list-inside ml-4">
            <?php foreach ($errorMessages as $error): ?>
            <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="bg-white p-6 md:p-8 rounded-lg shadow-md max-w-2xl mx-auto">
        <div class="mb-6 p-4 border border-gray-200 rounded-md bg-gray-50">
            <h2 class="text-xl font-semibold text-gray-800 mb-2">Dettagli Recensione</h2>
            <p><strong>Prodotto:</strong> <?php echo htmlspecialchars($product ? $product->name : 'N/D'); ?></p>
            <p><strong>Utente:</strong> <?php echo htmlspecialchars($user ? $user->username : 'N/D'); ?></p>
            <p><strong>Valutazione Originale:</strong> <span class="text-yellow-500"><?php echo str_repeat('★', $review->rating) . str_repeat('☆', 5 - $review->rating); ?></span> (Non modificabile dall'admin)</p>
            <p><strong>Data Creazione:</strong> <?php echo date("d/m/Y H:i", strtotime($review->created_at)); ?></p>
        </div>

        <form action="recensione_modifica.php?review_id=<?php echo $review->review_id; ?><?php echo str_replace('?','&',$returnToListParams);?>" method="POST" class="space-y-6">
            <input type="hidden" name="action" value="update_review_text">
            <input type="hidden" name="review_id" value="<?php echo $review->review_id; ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

            <div>
                <label for="comment_text" class="block text-sm font-medium text-gray-700 mb-1">Testo Commento*</label>
                <textarea id="comment_text" name="comment_text" rows="5" required
                          class="w-full px-3 py-2 border <?php echo (in_array("Il testo del commento non può essere vuoto.", $errorMessages) || in_array("Il testo del commento deve essere di almeno 10 caratteri.", $errorMessages)) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"><?php echo htmlspecialchars($review->comment_text); ?></textarea>
            </div>

            <div>
                <label for="pros" class="block text-sm font-medium text-gray-700 mb-1">Vantaggi (Pros)</label>
                <textarea id="pros" name="pros" rows="3"
                          class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"><?php echo htmlspecialchars($review->pros ?? ''); ?></textarea>
            </div>

            <div>
                <label for="cons" class="block text-sm font-medium text-gray-700 mb-1">Svantaggi (Cons)</label>
                <textarea id="cons" name="cons" rows="3"
                          class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"><?php echo htmlspecialchars($review->cons ?? ''); ?></textarea>
            </div>

            <div class="flex items-center">
                <input id="is_approved_checkbox" name="is_approved_checkbox" type="checkbox" 
                       value="1" <?php echo $review->is_approved ? 'checked' : ''; ?>
                       class="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                <label for="is_approved_checkbox" class="ml-2 block text-sm text-gray-900">
                    Approva questa recensione
                </label>
            </div>


            <div class="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200">
                <a href="recensioni_admin.php<?php echo $returnToListParams; ?>" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-md shadow-sm transition">Annulla</a>
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md shadow-sm transition">
                    Salva Modifiche Testo
                </button>
            </div>
        </form>
    </div>
</div>

<?php
include __DIR__ . '/includes/admin_layout_footer.php';
?>



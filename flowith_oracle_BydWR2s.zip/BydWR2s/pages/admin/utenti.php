<?php
// pages/admin/utenti.php
require_once __DIR__ . '/includes/admin_auth_check.php';
require_once __DIR__ . '/../../models/User.php';

$pageTitleAdmin = "Gestione Utenti";
$currentLoggedInAdminId = getCurrentUser()->user_id; // For preventing self-deletion/role change if needed

$errorMessages = [];
$successMessages = [];

// Handle Delete User Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_user') {
    if (isset($_POST['user_id'], $_POST['csrf_token']) && verifyCsrfToken($_POST['csrf_token'])) {
        $userIdToDelete = (int)$_POST['user_id'];
        if ($userIdToDelete === $currentLoggedInAdminId) {
            $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Non puoi eliminare il tuo account amministratore.'];
        } else {
            try {
                $user = User::getById($userIdToDelete);
                if ($user) {
                    // Prevent deletion of the last admin user - This is a simplistic check.
                    // A robust check would count total admins. For now, just a basic self-check.
                    if ($user->hasRole('admin')) {
                        $allAdmins = User::getAllPaginated(null, 0, 'role', 'ASC'); // Get all users
                        $adminCount = 0;
                        foreach ($allAdmins as $u) {
                            if ($u->hasRole('admin')) $adminCount++;
                        }
                        if ($adminCount <= 1) {
                             $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Impossibile eliminare l\'ultimo account amministratore.'];
                        } else if ($user->delete()) {
                            $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Utente eliminato con successo.'];
                        } else {
                            $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore durante l\'eliminazione dell\'utente.'];
                        }
                    } else { // Non-admin user
                        if ($user->delete()) {
                            $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Utente eliminato con successo.'];
                        } else {
                            $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore durante l\'eliminazione dell\'utente.'];
                        }
                    }
                } else {
                    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Utente non trovato.'];
                }
            } catch (PDOException $e) {
                error_log("Admin Utenti - Errore eliminazione utente: " . $e->getMessage());
                $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore database durante l\'eliminazione dell\'utente.'];
            }
        }
    } else {
        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Richiesta non valida o token CSRF mancante/errato.'];
    }
    // Regenerate CSRF token after POST
    $csrfToken = generateCsrfToken();
    header("Location: utenti.php" . (isset($_GET['page']) ? "?page=" . $_GET['page'] : "")); // Redirect to avoid resubmission
    exit;
}


// Pagination
$usersPerPage = 10;
$pageNumber = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($pageNumber < 1) $pageNumber = 1;
$offset = ($pageNumber - 1) * $usersPerPage;

$users = [];
$totalUsers = 0;
try {
    $users = User::getAllPaginated($usersPerPage, $offset, 'created_at', 'DESC');
    $totalUsers = User::countAll();
} catch (PDOException $e) {
    error_log("Admin Utenti: Errore caricamento utenti: " . $e->getMessage());
    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore nel caricamento dell\'elenco utenti.'];
}
$totalPages = ceil($totalUsers / $usersPerPage);
if ($pageNumber > $totalPages && $totalUsers > 0) {
    header("Location: utenti.php?page=" . $totalPages);
    exit;
}

$csrfToken = generateCsrfToken(); // Ensure CSRF token is available for forms

include __DIR__ . '/includes/admin_layout_header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-900">Elenco Utenti</h1>
        <!-- Add New User button if functionality is added later -->
        <!-- <a href="utente_gestisci.php" class="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded shadow-md transition duration-150">
            <span class="mr-1">➕</span> Aggiungi Utente
        </a> -->
    </div>

    <?php if (isset($_SESSION['flash_message'])): ?>
    <div class="mb-6 p-4 rounded-md <?php echo $_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 border-green-500 text-green-700' : 'bg-red-100 border-red-500 text-red-700'; ?>" role="alert">
        <p><?php echo htmlspecialchars($_SESSION['flash_message']['message']); ?></p>
    </div>
    <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <?php if (empty($users) && $totalUsers === 0 && !isset($_SESSION['flash_message'])): ?>
        <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4" role="alert">
            <p class="font-bold">Nessun Utente</p>
            <p>Non ci sono utenti registrati nel database.</p>
        </div>
    <?php elseif (!empty($users)): ?>
    <div class="bg-white shadow-md rounded-lg overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID Utente</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Username</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ruolo</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data Registrazione</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Azioni</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php foreach ($users as $user): ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo $user->user_id; ?></td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($user->username); ?></div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($user->email); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $user->hasRole('admin') ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'; ?>">
                            <?php echo htmlspecialchars(ucfirst($user->role)); ?>
                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <?php echo date("d/m/Y H:i", strtotime($user->created_at)); ?>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                        <a href="utente_modifica.php?user_id=<?php echo $user->user_id; ?><?php echo (isset($_GET['page']) ? "&source_page=" . $_GET['page'] : ""); ?>" class="text-indigo-600 hover:text-indigo-900">Modifica Ruolo</a>
                        <?php if ($user->user_id !== $currentLoggedInAdminId): // Prevent self-delete button ?>
                        <form action="utenti.php<?php echo (isset($_GET['page']) ? "?page=" . $_GET['page'] : ""); ?>" method="POST" class="inline-block" 
                              onsubmit="return confirmAdminDelete(event, 'Sei sicuro di voler eliminare l\'utente \'<?php echo htmlspecialchars(addslashes($user->username)); ?>\'? L\'azione non può essere annullata.');">
                            <input type="hidden" name="action" value="delete_user">
                            <input type="hidden" name="user_id" value="<?php echo $user->user_id; ?>">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                            <button type="submit" class="text-red-600 hover:text-red-900">Elimina</button>
                        </form>
                        <?php else: ?>
                            <span class="text-gray-400 italic text-xs">(Account Corrente)</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

        <?php if ($totalPages > 1): ?>
        <nav aria-label="Navigazione pagine utenti" class="mt-6 flex justify-center">
            <ul class="inline-flex items-center -space-x-px rounded-md shadow-sm">
                <?php if ($pageNumber > 1): ?>
                <li>
                    <a href="?page=<?php echo $pageNumber - 1; ?>"
                       class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700">
                        <span class="sr-only">Precedente</span>&laquo;
                    </a>
                </li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li>
                    <a href="?page=<?php echo $i; ?>"
                       class="py-2 px-3 leading-tight <?php echo ($i == $pageNumber) ? 'text-blue-600 bg-blue-50 border-blue-500 z-10' : 'text-gray-500 bg-white border-gray-300 hover:bg-gray-100 hover:text-gray-700'; ?>"
                       <?php echo ($i == $pageNumber) ? 'aria-current="page"' : ''; ?>>
                        <?php echo $i; ?>
                    </a>
                </li>
                <?php endfor; ?>

                <?php if ($pageNumber < $totalPages): ?>
                <li>
                    <a href="?page=<?php echo $pageNumber + 1; ?>"
                       class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700">
                        <span class="sr-only">Successiva</span>&raquo;
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php
include __DIR__ . '/includes/admin_layout_footer.php';
?>



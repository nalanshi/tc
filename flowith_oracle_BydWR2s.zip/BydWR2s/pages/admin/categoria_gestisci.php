<?php
// pages/admin/categoria_gestisci.php
require_once __DIR__ . '/includes/admin_auth_check.php'; // Ensures user is admin and auth.php/config/db.php (with e()) are included
require_once __DIR__ . '/../../models/Category.php';

$categoryId = filter_input(INPUT_GET, 'id_categoria', FILTER_VALIDATE_INT) ?: 0;
$isEditing = $categoryId > 0;
$pageTitleAdmin = $isEditing ? "Modifica Categoria" : "Aggiungi Nuova Categoria";

$categoryData = [
    'name' => '',
    'description' => ''
];
$errorMessages = [];

if ($isEditing) {
    try {
        $category = Category::getById($categoryId);
        if ($category) {
            $categoryData['name'] = $category->name;
            $categoryData['description'] = $category->description;
        } else {
            $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Categoria non trovata per la modifica.'];
            header("Location: categorie.php");
            exit;
        }
    } catch (PDOException $e) {
        error_log("Errore caricamento categoria ID {$categoryId} per modifica: " . $e->getMessage());
        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore database nel caricare la categoria.'];
        header("Location: categorie.php");
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], true)) {
        $errorMessages['csrf'] = 'Richiesta non valida o sessione scaduta. Riprova.';
        error_log("CSRF token mismatch on category form.");
        $csrfToken = generateCsrfToken(true); // Regenerate token for the redisplayed form
    } else {
        $categoryData['name'] = trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '');
        // For textarea, FILTER_SANITIZE_FULL_SPECIAL_CHARS might be too aggressive if some HTML-like content is allowed.
        // If plain text is expected, it's fine. If basic formatting like newlines is needed, consider other sanitization or nl2br on output.
        $categoryData['description'] = trim(filter_input(INPUT_POST, 'description', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '');

        if (empty($categoryData['name'])) {
            $errorMessages['name'] = 'Il nome della categoria è obbligatorio.';
        } elseif (mb_strlen($categoryData['name']) > 255) {
            $errorMessages['name'] = 'Il nome della categoria non può superare i 255 caratteri.';
        }
        // Description max length if applicable (e.g., TEXT type in MySQL is large, but UI might have practical limits)
        if (mb_strlen($categoryData['description']) > 65535) { // Example limit for TEXT
            $errorMessages['description'] = 'La descrizione è troppo lunga.';
        }


        if (empty($errorMessages)) {
            try {
                $categoryToSave = $isEditing ? Category::getById($categoryId) : new Category([]);
                if ($isEditing && !$categoryToSave) {
                      $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Categoria non trovata durante il salvataggio.'];
                      header("Location: categorie.php");
                      exit;
                }
                
                $categoryToSave->name = $categoryData['name'];
                $categoryToSave->description = !empty($categoryData['description']) ? $categoryData['description'] : null;

                if ($categoryToSave->save()) {
                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Categoria "' . e($categoryToSave->name) . '" ' . ($isEditing ? 'modificata' : 'aggiunta') . ' con successo.'];
                    header("Location: categorie.php");
                    exit;
                } else {
                    $errorMessages['save'] = 'Errore durante il salvataggio. Nessuna modifica o errore imprevisto.';
                }
            } catch (PDOException $e) {
                error_log("Errore DB salvataggio categoria (ID: {$categoryId}): " . $e->getMessage());
                if ($e->getCode() == '23000') {
                     $errorMessages['db'] = 'Errore: Esiste già una categoria con questo nome.';
                } else {
                    $errorMessages['db_generic'] = 'Errore database durante il salvataggio.';
                }
            } catch (InvalidArgumentException $e) {
                 $errorMessages['validation_model'] = $e->getMessage();
            } catch (Exception $e){
                 error_log("Unexpected error during category save: " . $e->getMessage());
                 $errorMessages['unexpected'] = 'Si è verificato un errore imprevisto: ' . e($e->getMessage());
            }
        }
        // If POST failed, regenerate CSRF token for the form redisplay
        if(!empty($errorMessages)) {
           $csrfToken = generateCsrfToken(true);
        }
    }
} else {
    $csrfToken = generateCsrfToken(); // For initial GET request
}

include __DIR__ . '/includes/admin_layout_header.php';
?>

<div class="container mx-auto px-4 py-8">
    <header class="mb-6">
        <h1 class="text-3xl font-bold text-gray-900"><?php echo e($pageTitleAdmin); ?></h1>
        <a href="categorie.php" class="text-blue-600 hover:underline text-sm">&laquo; Torna all'elenco categorie</a>
    </header>

    <?php if (!empty($errorMessages)): ?>
    <div class="mb-6 bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md" role="alert" aria-atomic="true">
        <p class="font-bold">Attenzione!</p>
        <ul class="mt-2 list-disc list-inside text-sm">
            <?php foreach ($errorMessages as $field => $errorMessage): ?>
            <li><?php echo e($errorMessage); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="bg-white p-6 md:p-8 rounded-lg shadow-md max-w-2xl mx-auto">
        <form action="categoria_gestisci.php<?php echo $isEditing ? '?id_categoria=' . $categoryId : ''; ?>" method="POST" class="space-y-6" novalidate>
            <input type="hidden" name="csrf_token" value="<?php echo e($csrfToken); ?>">

            <div class="form-field-container">
                <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Nome Categoria*</label>
                <input type="text" id="name" name="name" required
                       class="w-full px-3 py-2 border <?php echo isset($errorMessages['name']) || isset($errorMessages['db']) ? 'border-red-500 is-invalid' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                       value="<?php echo e($categoryData['name']); ?>"
                       aria-describedby="name-error"
                       aria-invalid="<?php echo (isset($errorMessages['name']) || isset($errorMessages['db'])) ? 'true' : 'false'; ?>"
                       maxlength="255">
                <span id="name-error" class="error-text text-xs text-red-600 mt-1" aria-live="polite"></span>
            </div>

            <div class="form-field-container">
                <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Descrizione</label>
                <textarea id="description" name="description" rows="4"
                          class="w-full px-3 py-2 border <?php echo isset($errorMessages['description']) ? 'border-red-500 is-invalid' : 'border-gray-300'; ?> rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                          aria-describedby="description-error"
                          aria-invalid="<?php echo isset($errorMessages['description']) ? 'true' : 'false'; ?>"
                ><?php echo e($categoryData['description'] ?? ''); ?></textarea>
                 <span id="description-error" class="error-text text-xs text-red-600 mt-1" aria-live="polite"></span>
            </div>
            
            <div class="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200">
                <a href="categorie.php" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-md shadow-sm transition">Annulla</a>
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md shadow-sm transition">
                    <?php echo $isEditing ? 'Salva Modifiche' : 'Aggiungi Categoria'; ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
$additionalAdminScripts = '
<script nonce="' . e($cspNonce) . '">
document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("form");
    if (!form) return;

    const nameInput = document.getElementById("name");
    const descriptionInput = document.getElementById("description");

    form.addEventListener("submit", function(event) {
        let isValid = true;
        clearValidationErrors(nameInput);
        clearValidationErrors(descriptionInput);

        if (!nameInput.value.trim()) {
            isValid = false;
            showValidationErrors(nameInput, ["Il nome della categoria è obbligatorio."]);
        } else if (nameInput.value.trim().length > 255) {
            isValid = false;
            showValidationErrors(nameInput, ["Il nome non può superare i 255 caratteri."]);
        }

        if (descriptionInput.value.trim().length > 65535) { // Example TEXT limit
             isValid = false;
             showValidationErrors(descriptionInput, ["La descrizione è troppo lunga."]);
        }

        if (!isValid) {
            event.preventDefault();
            const firstInvalidField = form.querySelector(".is-invalid");
            if (firstInvalidField) {
                firstInvalidField.focus();
            }
        }
    });

    nameInput.addEventListener("input", function() { clearValidationErrors(this); });
    descriptionInput.addEventListener("input", function() { clearValidationErrors(this); });

    // Link server-side errors to ARIA attributes
    form.querySelectorAll(".is-invalid").forEach(invalidInput => {
        const errorId = invalidInput.id + "-error";
        const errorSpan = document.getElementById(errorId);
        if (errorSpan && errorSpan.textContent.trim() !== "") {
            invalidInput.setAttribute("aria-describedby", errorId);
            // aria-invalid already set by PHP based on errorMessages
        }
    });
});
</script>
';
include __DIR__ . '/includes/admin_layout_footer.php';
?>

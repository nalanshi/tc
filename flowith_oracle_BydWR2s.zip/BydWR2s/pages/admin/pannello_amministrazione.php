<?php
// pages/admin/pannello_amministrazione.php
require_once __DIR__ . '/includes/admin_auth_check.php'; // Ensures user is admin
require_once __DIR__ . '/../../models/Product.php'; 
require_once __DIR__ . '/../../models/Category.php'; 
require_once __DIR__ . '/../../models/Review.php'; 
require_once __DIR__ . '/../../models/User.php'; 

$pageTitleAdmin = "Dashboard Amministrazione";
$currentUser = getCurrentUser(); 

try {
    $totalProducts = Product::countAll();
    $totalCategories = Category::countAll(); // Assuming Category model has countAll, or use count(Category::getAll())
    $totalPendingReviews = Review::countPendingReviews(); // Counts reviews where is_approved = false
    $totalUsers = User::countAll(); 
} catch (PDOException $e) {
    error_log("Admin Dashboard: Errore nel caricare le statistiche: " . $e->getMessage());
    $totalProducts = $totalCategories = $totalPendingReviews = $totalUsers = "N/A";
     $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Impossibile caricare alcune statistiche del pannello.'];
}


include __DIR__ . '/includes/admin_layout_header.php';
?>

<div class="container mx-auto px-4 py-8">
    <header class="mb-8">
        <h1 class="text-3xl font-bold text-gray-900">Pannello di Amministrazione</h1>
        <p class="text-lg text-gray-600">Benvenuto, <?php echo htmlspecialchars($currentUser->username); ?>!</p>
    </header>

    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="mb-6 p-4 rounded-md <?php echo $_SESSION['flash_message']['type'] === 'success' ? 'bg-green-100 border-green-500 text-green-700' : 'bg-red-100 border-red-500 text-red-700'; ?>" role="alert">
            <p><?php echo htmlspecialchars($_SESSION['flash_message']['message']); ?></p>
        </div>
        <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-xl font-semibold text-gray-700 mb-2">Utenti Registrati</h2>
            <p class="text-3xl font-bold text-purple-600"><?php echo htmlspecialchars($totalUsers); ?></p>
            <a href="utenti.php" class="text-sm text-purple-600 hover:underline mt-1 block">Gestisci utenti &rarr;</a>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-xl font-semibold text-gray-700 mb-2">Recensioni Pendenti</h2>
            <p class="text-3xl font-bold text-yellow-500"><?php echo htmlspecialchars($totalPendingReviews); ?></p>
            <a href="recensioni_admin.php?status_filter=pending" class="text-sm text-yellow-600 hover:underline mt-1 block">Modera recensioni &rarr;</a>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-xl font-semibold text-gray-700 mb-2">Prodotti Totali</h2>
            <p class="text-3xl font-bold text-blue-600"><?php echo htmlspecialchars($totalProducts); ?></p>
            <a href="prodotti.php" class="text-sm text-blue-600 hover:underline mt-1 block">Gestisci prodotti &rarr;</a>
        </div>
         <div class="bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-xl font-semibold text-gray-700 mb-2">Categorie Totali</h2>
            <p class="text-3xl font-bold text-green-600"><?php echo htmlspecialchars($totalCategories); ?></p>
            <a href="categorie.php" class="text-sm text-green-600 hover:underline mt-1 block">Gestisci categorie &rarr;</a>
        </div>
    </section>

    <section>
        <h2 class="text-2xl font-semibold text-gray-800 mb-6">Azioni Rapide</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
             <a href="utenti.php" class="block bg-purple-500 hover:bg-purple-600 text-white p-6 rounded-lg shadow-md transition duration-150 ease-in-out text-center">
                <div class="text-4xl mb-2" aria-hidden="true">👥</div>
                <h3 class="text-xl font-semibold">Gestisci Utenti</h3>
                <p class="text-sm opacity-90">Visualizza e gestisci gli account utente.</p>
            </a>
             <a href="recensioni_admin.php" class="block bg-yellow-500 hover:bg-yellow-600 text-white p-6 rounded-lg shadow-md transition duration-150 ease-in-out text-center">
                <div class="text-4xl mb-2" aria-hidden="true">💬</div>
                <h3 class="text-xl font-semibold">Modera Recensioni</h3>
                <p class="text-sm opacity-90">Approva o rifiuta le recensioni inviate.</p>
            </a>
            <a href="prodotti.php" class="block bg-blue-500 hover:bg-blue-600 text-white p-6 rounded-lg shadow-md transition duration-150 ease-in-out text-center">
                <div class="text-4xl mb-2" aria-hidden="true">📦</div>
                <h3 class="text-xl font-semibold">Gestisci Prodotti</h3>
                <p class="text-sm opacity-90">Visualizza, aggiungi, modifica o elimina prodotti.</p>
            </a>
            <a href="categorie.php" class="block bg-green-500 hover:bg-green-600 text-white p-6 rounded-lg shadow-md transition duration-150 ease-in-out text-center">
                <div class="text-4xl mb-2" aria-hidden="true">🏷️</div>
                <h3 class="text-xl font-semibold">Gestisci Categorie</h3>
                <p class="text-sm opacity-90">Crea e organizza le categorie dei prodotti.</p>
            </a>
        </div>
    </section>

</div>

<?php
include __DIR__ . '/includes/admin_layout_footer.php';
?>



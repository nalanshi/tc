<?php
// pages/admin/categorie.php
require_once __DIR__ . '/includes/admin_auth_check.php'; // Ensures user is admin and auth.php is included
require_once __DIR__ . '/../../models/Category.php'; 
require_once __DIR__ . '/../../models/Product.php'; // For product counts

$pageTitleAdmin = "Gestione Categorie";

// Handle POST action for deletion or cancel deletion confirmation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['csrf_token'])) {
    if (!verifyCsrfToken($_POST['csrf_token'], true)) {
        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Richiesta non valida (CSRF token error). Riprova.'];
        error_log("CSRF token mismatch or invalid on category action.");
    } else {
        $action = $_POST['action'];
        $categoryId = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);

        if ($action === 'delete_category') {
            if ($categoryId === false || $categoryId <= 0) {
                $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'ID categoria non valido per l\'eliminazione.'];
                error_log("Invalid category ID submitted for deletion: " . e($_POST['category_id'] ?? 'N/A'));
            } else {
                try {
                    $category = Category::getById($categoryId);
                    if ($category) {
                        $productCount = $category->getProductCount();
                        $isConfirmedByHiddenField = isset($_POST['confirm_delete_with_products']) && $_POST['confirm_delete_with_products'] === '1';

                        if ($productCount > 0 && !$isConfirmedByHiddenField) {
                            $_SESSION['confirm_delete_category'] = [
                                'id' => $category->category_id,
                                'name' => $category->name,
                                'product_count' => $productCount
                            ];
                        } else {
                            if ($category->delete()) {
                                $message = 'Categoria "' . e($category->name) . '" eliminata con successo.';
                                if ($productCount > 0) {
                                    $message .= " I prodotti precedentemente in questa categoria ora non hanno una categoria assegnata.";
                                }
                                $_SESSION['flash_message'] = ['type' => 'success', 'message' => $message];
                                if (isset($_SESSION['confirm_delete_category'])) {
                                    unset($_SESSION['confirm_delete_category']);
                                }
                            } else {
                                $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Impossibile eliminare la categoria. Potrebbe essere già stata eliminata o si è verificato un errore.'];
                            }
                        }
                    } else {
                        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Categoria non trovata per l\'eliminazione.'];
                    }
                } catch (PDOException $e) {
                    error_log("Errore database durante eliminazione categoria ID {$categoryId}: " . $e->getMessage());
                    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore database durante l\'eliminazione della categoria.'];
                    if (isset($_SESSION['confirm_delete_category'])) {
                        unset($_SESSION['confirm_delete_category']);
                    }
                } catch (Exception $e) {
                     error_log("Unexpected error during category deletion: " . $e->getMessage());
                     $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Si è verificato un errore imprevisto: ' . e($e->getMessage())];
                }
            }
        } elseif ($action === 'cancel_delete_category') {
            if (isset($_SESSION['confirm_delete_category'])) {
                unset($_SESSION['confirm_delete_category']);
                $_SESSION['flash_message'] = ['type' => 'info', 'message' => 'Eliminazione categoria annullata.'];
                error_log("Category deletion confirmation cancelled by user for ID: " . e($categoryId ?? 'N/A'));
            }
        }
    }
    // Regenerate CSRF token after POST (handled by generateCsrfToken() on next load if needed)
    // Redirect to the same page to clear POST data and show messages, preserving GET parameters
    $redirectParams = $_GET; // Keep existing GET params like 'page'
    unset($redirectParams['action'], $redirectParams['category_id'], $redirectParams['csrf_token'], $redirectParams['confirm_delete_with_products']); // Clean POST specific params if they were in GET by mistake
    header("Location: categorie.php" . (!empty($redirectParams) ? "?" . http_build_query($redirectParams) : ""));
    exit;
}


// --- Display Category List ---
$categoriesPerPage = 10;
$pageNumber = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($pageNumber < 1) $pageNumber = 1;
$offset = ($pageNumber - 1) * $categoriesPerPage;

$categories = [];
$totalCategories = 0;
$productCounts = []; // For N+1 optimization

try {
    $allCategories = Category::getAll('name', 'ASC');
    $totalCategories = count($allCategories);
    $categories = array_slice($allCategories, $offset, $categoriesPerPage);

    // N+1 Optimization: Get product counts for all displayed categories (or all categories if few)
    if (!empty($categories)) {
        $categoryIds = array_map(function($cat) { return $cat->category_id; }, $categories);
        $productCounts = Product::getProductCountsByCategories($categoryIds);
    }

} catch (PDOException $e) {
    error_log("Admin Categorie: Errore database nel caricamento categorie: " . $e->getMessage());
    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore nel caricamento dell\'elenco categorie dal database.'];
    $categories = [];
    $totalCategories = 0;
}

$totalPages = ceil($totalCategories / $categoriesPerPage);
if ($pageNumber > $totalPages && $totalCategories > 0) {
    $redirectParams = array_merge($_GET, ['page' => $totalPages]);
    header("Location: categorie.php?" . http_build_query($redirectParams));
    exit;
} elseif ($totalCategories === 0 && $pageNumber > 1) {
    header("Location: categorie.php");
    exit;
}

$csrfToken = generateCsrfToken(); // Fresh token for forms on this page

include __DIR__ . '/includes/admin_layout_header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-900">Elenco Categorie</h1>
        <a href="categoria_gestisci.php" class="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded shadow-md transition duration-150">
            <span class="mr-1" aria-hidden="true">➕</span> Aggiungi Categoria
        </a>
    </div>

    <?php if (isset($_SESSION['confirm_delete_category'])):
        $catConfirm = $_SESSION['confirm_delete_category'];
    ?>
     <div class="mb-6 p-4 rounded-md bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700" role="alertdialog" aria-labelledby="confirm-del-title" aria-describedby="confirm-del-desc">
         <h2 id="confirm-del-title" class="font-bold">Conferma Eliminazione Categoria</h2>
         <p id="confirm-del-desc" class="mt-2">La categoria "<strong><?php echo e($catConfirm['name']); ?></strong>" è associata a <strong><?php echo $catConfirm['product_count']; ?></strong> prodotti.
         Se elimini questa categoria, questi prodotti non avranno più una categoria assegnata.</p>
         <p class="mt-1">Sei sicuro di voler procedere con l'eliminazione?</p>
         
         <form action="categorie.php<?php echo (!empty($_GET) ? '?' . http_build_query($_GET) : ''); ?>" method="POST" class="mt-4 inline-block">
             <input type="hidden" name="action" value="delete_category">
             <input type="hidden" name="category_id" value="<?php echo $catConfirm['id']; ?>">
             <input type="hidden" name="csrf_token" value="<?php echo e($csrfToken); ?>">
             <input type="hidden" name="confirm_delete_with_products" value="1">
             <button type="submit" class="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded shadow-md transition duration-150">
                 Sì, Elimina Categoria
             </button>
         </form>
         <form action="categorie.php<?php echo (!empty($_GET) ? '?' . http_build_query($_GET) : ''); ?>" method="POST" class="inline-block">
            <input type="hidden" name="action" value="cancel_delete_category">
            <input type="hidden" name="category_id" value="<?php echo $catConfirm['id']; ?>">
            <input type="hidden" name="csrf_token" value="<?php echo e($csrfToken); ?>">
            <button type="submit" class="ml-2 bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold py-2 px-4 rounded shadow-md transition duration-150">
                 Annulla
            </button>
         </form>
     </div>
    <?php
        // Do NOT unset $_SESSION['confirm_delete_category'] here. It should be unset only after the action (delete or cancel) is processed.
        // The POST handler at the top of the file will unset it.
    ?>
    <?php endif; ?>


    <?php if (empty($categories) && $totalCategories === 0 && !isset($_SESSION['flash_message']) && !isset($_SESSION['confirm_delete_category'])): ?>
        <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4" role="alert">
            <p class="font-bold">Nessuna Categoria</p>
            <p>Non ci sono ancora categorie nel database. <a href="categoria_gestisci.php" class="font-medium underline hover:text-yellow-800">Aggiungine una ora!</a></p>
        </div>
    <?php elseif (!empty($categories)): ?>
    <div class="bg-white shadow-md rounded-lg overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nome Categoria</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Descrizione</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prodotti Associati</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Azioni</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php foreach ($categories as $category):
                    $productCountInCategory = $productCounts[$category->category_id] ?? 0;
                ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm font-medium text-gray-900"><?php echo e($category->name); ?></div>
                    </td>
                    <td class="px-6 py-4">
                        <div class="text-sm text-gray-500 truncate max-w-xs"><?php echo !empty($category->description) ? e($category->description) : '<em>Nessuna descrizione</em>'; ?></div>
                    </td>
                     <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <?php echo $productCountInCategory; ?>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                        <a href="categoria_gestisci.php?id_categoria=<?php echo $category->category_id; ?>" class="text-indigo-600 hover:text-indigo-900">Modifica</a>
                        <form action="categorie.php<?php echo (!empty($_GET) ? '?' . http_build_query($_GET) : ''); ?>" method="POST" class="inline-block"
                              onsubmit="return confirmAdminDelete(event, 'Sei sicuro di voler eliminare la categoria \'<?php echo e(addslashes($category->name)); ?>\'? <?php if($productCountInCategory > 0) echo 'Ci sono '.$productCountInCategory.' prodotti associati che verranno scollegati.'; ?> L\'azione non può essere annullata.', <?php echo $productCountInCategory > 0 ? 'true' : 'false'; ?> );">
                             <input type="hidden" name="action" value="delete_category">
                            <input type="hidden" name="category_id" value="<?php echo $category->category_id; ?>">
                            <input type="hidden" name="csrf_token" value="<?php echo e($csrfToken); ?>">
                            <?php // If productCount > 0, the JS will add confirm_delete_with_products=1 if user confirms. Server checks this flag. ?>
                            <button type="submit" class="text-red-600 hover:text-red-900">Elimina</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

        <?php if ($totalPages > 1): ?>
        <nav aria-label="Navigazione pagine categorie" class="mt-6 flex justify-center">
            <ul class="inline-flex items-center -space-x-px rounded-md shadow-sm">
                 <?php if ($pageNumber > 1): ?>
                <li>
                    <a href="?<?php echo e(http_build_query(array_merge($_GET, ['page' => $pageNumber - 1]))); ?>"
                       class="py-2 px-3 ml-0 leading-tight text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700">
                        <span class="sr-only">Precedente</span>&laquo;
                    </a>
                </li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li>
                    <a href="?<?php echo e(http_build_query(array_merge($_GET, ['page' => $i]))); ?>"
                       class="py-2 px-3 leading-tight <?php echo ($i == $pageNumber) ? 'text-blue-600 bg-blue-50 border-blue-500 z-10 font-semibold' : 'text-gray-500 bg-white border-gray-300 hover:bg-gray-100 hover:text-gray-700'; ?>"
                       <?php echo ($i == $pageNumber) ? 'aria-current="page"' : ''; ?>>
                        <?php echo $i; ?>
                    </a>
                </li>
                <?php endfor; ?>

                <?php if ($pageNumber < $totalPages): ?>
                <li>
                    <a href="?<?php echo e(http_build_query(array_merge($_GET, ['page' => $pageNumber + 1]))); ?>"
                       class="py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700">
                        <span class="sr-only">Successiva</span>&raquo;
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php
include __DIR__ . '/includes/admin_layout_footer.php';
?>

<?php
// pages/admin/includes/admin_layout_header.php

// Calculate base path for assets from /pages/admin/includes/
$adminAssetBasePath = '../../../'; // Goes up to project root

$pageTitleAdmin = $pageTitleAdmin ?? 'Pannello Amministrazione';
$currentUser = $currentUser ?? getCurrentUser(); // Assuming admin_auth_check already ran and $currentUser is available

?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitleAdmin); ?> - Prodotto Recensioni Aggregate</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="<?php echo htmlspecialchars($adminAssetBasePath . 'css/styles.css'); ?>">
    <style>
        /* Additional styles for admin if needed - or create admin.css */
        .admin-main-content { margin-left: 0; } /* Default for mobile */
        @media (min-width: 768px) { /* md breakpoint */
            .admin-main-content { margin-left: 16rem; } /* 64 * 0.25rem = 16rem (w-64 of sidebar) */
        }
        .skip-to-content-admin {
            position: absolute;
            left: -9999px;
            top: auto;
            width: 1px;
            height: 1px;
            overflow: hidden;
            z-index: -999;
        }
        .skip-to-content-admin:focus, .skip-to-content-admin:active {
            color: #fff;
            background-color: #000;
            left: auto;
            top: auto;
            width: auto;
            height: auto;
            overflow: auto;
            margin: 10px;
            padding: 10px;
            border-radius: 5px;
            z-index: 99999;
            text-decoration: none;
        }
    </style>
</head>
<body class="bg-gray-100 text-gray-800 flex flex-col min-h-screen">
    <a href="#admin-content" class="skip-to-content-admin">Vai al contenuto principale</a>

    <div class="flex flex-1">
        <?php include __DIR__ . '/admin_sidebar.php'; ?>

        <div class="flex-1 flex flex-col">
            <header class="bg-white shadow-md p-4 md:hidden sticky top-0 z-30">
                <div class="flex justify-between items-center">
                    <h1 class="text-xl font-semibold">Admin</h1>
                    <button id="admin-sidebar-toggle" class="text-gray-600 hover:text-gray-800 focus:outline-none">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
                         <span class="sr-only">Apri/Chiudi menu laterale</span>
                    </button>
                </div>
            </header>
            
            <main id="admin-content" class="flex-grow p-6 admin-main-content">
                <!-- Page specific content will be injected here -->




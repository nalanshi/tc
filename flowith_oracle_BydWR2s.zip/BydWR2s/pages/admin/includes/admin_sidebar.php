<?php
// pages/admin/includes/admin_sidebar.php

// This path is for generating root-relative links to admin pages.
// If this file is in /pages/admin/includes/, and project root is web root:
// ../../../ brings to web root.
// So, $adminPagesRootPath will be like '/pages/admin' if project is in a subdir,
// or just '/pages/admin' if project root is web root.
// This assumes that the 'pages' directory is at the top level of the site accessible via URL.

// A simpler way: Assume all admin pages are in the same directory 'pages/admin/'.
// Links can be relative from any page within 'pages/admin/'.
// Example: href="utenti.php", href="prodotti.php"

// The provided code seems to use a base URL calculation that implies a deeper structure or specific server setup.
// Let's stick to the pattern from the provided `admin_sidebar.php` as it was given.
// $adminBaseUrl = '../../../pages/admin'; // This was the original value in the prompt for this file.
// If `admin_sidebar.php` is at `project_root/pages/admin/includes/admin_sidebar.php`,
// then `../../../` refers to `project_root/`.
// So `$adminBaseUrl` refers to the directory `project_root/pages/admin/`.
// Links like `<a href="$adminBaseUrl/utenti.php">` become `<a href="/path/to/project_root/pages/admin/utenti.php">`
// This will work if `/path/to/project_root/` is the web root or path is adjusted by server.
// For simplicity and robustness for this exercise, making links relative to the admin directory is better.
// Let's assume $adminBaseUrl should result in simple relative links if pages are siblings.
// So, if current page is /pages/admin/dashboard.php, link to users is just "utenti.php".

// Re-evaluating based on structure:
// The file is pages/admin/includes/admin_sidebar.php
// It's included by files in pages/admin/ (e.g., pages/admin/dashboard.php)
// So, from dashboard.php, a link to utenti.php (also in pages/admin/) is just "utenti.php".
// $adminBaseUrl should effectively be empty or "./" for this simple case.
// The original provided sidebar uses:
// $adminBaseUrl = '../../../pages/admin';
// And links like: href="<?php echo htmlspecialchars($adminBaseUrl . '/pannello_amministrazione.php'); ?>"
// This forms a path like: `../../../pages/admin/pannello_amministrazione.php` which is relative from current URL.
// If current URL is `http://localhost/project/pages/admin/dashboard.php`, this becomes
// `http://localhost/project/pages/admin/pannello_amministrazione.php` (if server resolves `../../../pages/admin/` correctly from that context).
// This is a bit fragile. A safer way for root-relative URLs if the project root is known:
// Define $projectWebRoot in a config or calculate it once robustly (like in `includes/header.php`)
// Then links become: `href="<?php echo $projectWebRoot; ?>/pages/admin/utenti.php"`

// For this exercise, I will make the links directly relative assuming all main admin pages are in `pages/admin/`.
// This means `$adminBaseUrl` will be effectively empty.
$currentAdminPage = basename($_SERVER['PHP_SELF']);

// Determine base for links to public site and logout
// From /pages/admin/includes/ to / (project root for index.php) is ../../../
// From /pages/admin/includes/ to /pages/ (for logout.php) is ../../
$publicSitePath = '../../../index.php'; // Path to public site from /pages/admin/includes/
$logoutAdminPath = '../../logout.php';   // Path to logout script from /pages/admin/includes/

?>
<aside class="w-64 bg-gray-800 text-white p-6 space-y-4 fixed top-0 left-0 h-full shadow-lg z-40 transform -translate-x-full md:translate-x-0 transition-transform duration-300 ease-in-out" id="admin-sidebar">
    <div class="text-2xl font-semibold mb-6 border-b border-gray-700 pb-4">
        Admin Panel
    </div>
    <nav>
        <ul>
            <li>
                <a href="pannello_amministrazione.php"
                   class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 <?php echo ($currentAdminPage === 'pannello_amministrazione.php') ? 'bg-gray-700 font-semibold' : ''; ?>">
                    <span class="mr-2" aria-hidden="true">🏠</span> Dashboard
                </a>
            </li>
            <li>
                <a href="prodotti.php"
                   class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 <?php echo ($currentAdminPage === 'prodotti.php' || $currentAdminPage === 'prodotto_gestisci.php') ? 'bg-gray-700 font-semibold' : ''; ?>">
                    <span class="mr-2" aria-hidden="true">📦</span> Gestione Prodotti
                </a>
            </li>
            <li>
                <a href="categorie.php"
                   class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 <?php echo ($currentAdminPage === 'categorie.php' || $currentAdminPage === 'categoria_gestisci.php') ? 'bg-gray-700 font-semibold' : ''; ?>">
                    <span class="mr-2" aria-hidden="true">🏷️</span> Gestione Categorie
                </a>
            </li>
            <li>
                <a href="recensioni_admin.php" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 <?php echo ($currentAdminPage === 'recensioni_admin.php' || $currentAdminPage === 'recensione_modifica.php') ? 'bg-gray-700 font-semibold' : ''; ?>">
                    <span class="mr-2" aria-hidden="true">💬</span> Modera Recensioni
                </a>
            </li>
            <li>
                <a href="utenti.php" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 <?php echo ($currentAdminPage === 'utenti.php' || $currentAdminPage === 'utente_modifica.php') ? 'bg-gray-700 font-semibold' : ''; ?>">
                    <span class="mr-2" aria-hidden="true">👥</span> Gestione Utenti
                </a>
            </li>
             <li>
                <a href="#" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 opacity-50 cursor-not-allowed" title="Funzionalità futura (non implementata)">
                    <span class="mr-2" aria-hidden="true">⚙️</span> Impostazioni Sito
                </a>
            </li>
        </ul>
    </nav>
    <div class="mt-auto pt-6 border-t border-gray-700">
        <a href="<?php echo htmlspecialchars($publicSitePath); ?>"
           class="block py-2.5 px-4 text-sm rounded transition duration-200 hover:bg-gray-700 text-gray-300">
            <span class="mr-2" aria-hidden="true">🌍</span> Torna al Sito Pubblico
        </a>
        <a href="<?php echo htmlspecialchars($logoutAdminPath); ?>"
            class="block py-2.5 px-4 text-sm rounded transition duration-200 hover:bg-red-600 hover:text-white text-gray-300">
            <span class="mr-2" aria-hidden="true">🚪</span> Esci
        </a>
    </div>
</aside>



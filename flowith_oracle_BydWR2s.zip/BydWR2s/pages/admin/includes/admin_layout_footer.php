# Prodotto Recensioni Aggregate .htaccess

# --- URL Rewriting (Optional, if using clean URLs later) ---
# Example:
# RewriteEngine On
# RewriteCond %{REQUEST_FILENAME} !-f
# RewriteCond %{REQUEST_FILENAME} !-d
# RewriteRule ^(.*)$ index.php?url=$1 [L,QSA]


# --- Security Headers (can also be set in PHP, but .htaccess is good for static files) ---
<IfModule mod_headers.c>
    # X-Frame-Options (covered by PHP, but good for static assets if served directly)
    # Header set X-Frame-Options "DENY"
    # X-Content-Type-Options (covered by PHP)
    # Header set X-Content-Type-Options "nosniff"
    # Referrer-Policy (covered by PHP)
    # Header set Referrer-Policy "strict-origin-when-cross-origin"
    # Permissions-Policy (covered by PHP)
    # Header set Permissions-Policy "accelerometer=(), ambient-light-sensor=(), ..."

    # Content Security Policy (CSP) is best set in PHP for dynamic nonces.
    # Avoid setting a static CSP here if PHP handles it, to prevent conflicts.
</IfModule>


# --- HTTPS Redirection ---
# Force HTTPS, excluding common local development environments
# Ensure your server is correctly configured for HTTPS before enabling this.
<IfModule mod_rewrite.c>
    RewriteEngine On
    # Condition to check if not on localhost or 127.0.0.1
    # RewriteCond %{HTTP_HOST} !^localhost$ [NC]
    # RewriteCond %{HTTP_HOST} !^127\.0\.0\.1$
    # RewriteCond %{HTTPS} off
    # RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

    # More robust way to check for HTTPS (handles proxies)
    RewriteCond %{HTTPS} off
    RewriteCond %{HTTP:X-Forwarded-Proto} !https [NC]
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301,NE]
</IfModule>


# --- Server-Side Compression (Gzip/Deflate) ---
# Compresses common text-based file types to reduce transfer size.
<IfModule mod_deflate.c>
    # Compress HTML, CSS, JavaScript, Text, XML and JSON
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml
    AddOutputFilterByType DEFLATE application/rss+xml
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/x-javascript
    AddOutputFilterByType DEFLATE application/json

    # For older browsers (optional)
    BrowserMatch ^Mozilla/4 gzip-only-text/html
    BrowserMatch ^Mozilla/4\.0[678] no-gzip
    BrowserMatch \bMSIE !no-gzip !gzip-only-text/html
    Header append Vary User-Agent env=!dont-vary
</IfModule>


# --- Browser Caching (Leverage Browser Caching) ---
# Set expiry headers for static assets to encourage browser caching.
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
    ExpiresByType image/webp "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
    ExpiresByType application/x-javascript "access plus 1 month"
    ExpiresByType application/pdf "access plus 1 month"
    # Favicon can be cached for a long time
    ExpiresByType image/x-icon "access plus 1 year"
    # Web fonts
    ExpiresByType application/font-woff "access plus 1 year"
    ExpiresByType application/font-woff2 "access plus 1 year"
    ExpiresByType application/vnd.ms-fontobject "access plus 1 year"
    ExpiresByType application/x-font-ttf "access plus 1 year"
    ExpiresByType font/opentype "access plus 1 year"
</IfModule>

<IfModule mod_headers.c>
    # For assets with query strings (cache busting), ensure they are cached if content hasn't changed.
    # This might require more advanced server config or removing query strings for static assets.
    # For CSS and JS, use `Cache-Control` for more fine-grained control.
    <FilesMatch "\.(css|js)$">
        Header set Cache-Control "max-age=2592000, public"
    </FilesMatch>
    <FilesMatch "\.(jpg|jpeg|png|gif|svg|webp|ico|woff|woff2|eot|ttf|otf)$">
        Header set Cache-Control "max-age=31536000, public"
    </FilesMatch>
</IfModule>


# --- Protect sensitive files ---
# Deny access to .htaccess, .htpasswd, and other sensitive files/directories.
<Files ".ht*">
    Require all denied
</Files>
<FilesMatch "^\."> # Deny access to any dot files/folders
    Require all denied
</FilesMatch>
# Example: Deny access to includes or config directories if they are web-accessible (they shouldn't be)
# <DirectoryMatch "/(config|includes)/">
#    Require all denied
# </DirectoryMatch>

# --- PHP Settings (Example: disable error display for production) ---
# These are better set in php.ini, but can be overridden here if server allows.
# php_flag display_errors Off
# php_value error_reporting E_ALL
# php_flag log_errors On
# php_value error_log /path/to/your/php-error.log


# --- Default Index File ---
DirectoryIndex index.php index.html

# --- Prevent directory listing ---
Options -Indexes

# --- Set default charset ---
AddDefaultCharset UTF-8

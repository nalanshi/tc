<?php
// pages/admin/includes/admin_auth_check.php
// This file is included by all admin pages to enforce authentication and admin role.

// Ensure config (for e()) and auth (for session and functions) are loaded.
// The path assumes this file is in /pages/admin/includes/
require_once __DIR__ . '/../../../config/db.php'; // For e() if needed, and DB for User model
require_once __DIR__ . '/../../../includes/auth.php'; // Handles session_start() and auth functions


if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    
    // Calculate path to public login page. $projectWebRoot should be available if header.php was included before this.
    // However, auth_check is often one of the first includes. So, calculate relative or use a known structure.
    // Assuming $projectWebRoot is set in config/db.php or a general bootstrap file if header.php isn't guaranteed.
    // For simplicity, construct a root-relative path.
    global $projectWebRoot; // Ensure it's accessible if defined globally elsewhere (e.g. by header.php)
    $loginPage = ($projectWebRoot ?? '') . '/pages/accesso.php';
    
    header("Location: " . $loginPage);
    exit;
}

try {
    $currentUser = getCurrentUser();

    if (!$currentUser || !$currentUser->hasRole('admin')) {
        error_log("Access denied: User ID " . ($_SESSION['user_id'] ?? 'N/A') . " (Role: " . ($currentUser ? e($currentUser->role) : 'N/A') . ") attempted to access admin area: " . e($_SERVER['REQUEST_URI']));
        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Accesso negato. Non hai i permessi per visualizzare questa pagina.'];
        
        global $projectWebRoot;
        $profilePage = ($projectWebRoot ?? '') . '/pages/profilo-utente.php'; // Redirect to public profile

        header("Location: " . $profilePage);
        exit;
    }
    // $currentUser is available to the including admin page.

} catch (PDOException $e) {
    error_log("Database error during admin auth check (User ID: " . ($_SESSION['user_id'] ?? 'N/A') . " URI: " . e($_SERVER['REQUEST_URI']) . "): " . $e->getMessage());
    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Errore di sistema. Impossibile verificare i permessi. Riprova più tardi.'];
    
    global $projectWebRoot;
    $loginPage = ($projectWebRoot ?? '') . '/pages/accesso.php';
    
    // Log out the user to force re-authentication if DB is failing for user fetch
    logoutUser(); 
    header("Location: " . $loginPage);
    exit;
}

// Generate a CSRF token for use in admin forms on the page that includes this check.
// This token is then available as $csrfToken in the including script.
$csrfToken = generateCsrfToken();

?>

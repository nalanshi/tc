<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php'; // For displaying category name
require_once __DIR__ . '/../models/Review.php'; // Needed to fetch and save reviews
require_once __DIR__ . '/../models/User.php'; // Needed for review user info

$productId = isset($_GET['id_prodotto']) ? (int)$_GET['id_prodotto'] : 0;
$product = null;
$category = null;
$userErrorMessage = null; // For product loading errors
$reviews = [];
$reviewErrorMessages = []; // For review form submission errors
$reviewSuccessMessage = null; // For review form submission success
$reviewFormData = ['rating' => '', 'comment_text' => '', 'pros' => '', 'cons' => ''];
$userHasReviewed = false; // Flag to check if the logged-in user has already reviewed
$currentUser = getCurrentUser(); // Get logged in user, null if not logged in

// Review sorting parameters
$reviewsOrderBy = $_GET['ordina_recensioni'] ?? 'created_at';
$reviewsOrderDirection = $_GET['direzione_recensioni'] ?? 'DESC';
$allowedSortOrders = ['created_at_DESC', 'created_at_ASC', 'rating_DESC', 'rating_ASC'];
$currentSortValue = $reviewsOrderBy . '_' . $reviewsOrderDirection;
if (!in_array($currentSortValue, $allowedSortOrders)) {
    $reviewsOrderBy = 'created_at';
    $reviewsOrderDirection = 'DESC';
    $currentSortValue = 'created_at_DESC';
}


// Process new review submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_review') {
    if (!$currentUser) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] . '#scrivi-recensione';
        header("Location: accesso.php");
        exit;
    }

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '', true)) { // Regenerate token after verification
        $reviewErrorMessages['csrf'] = "Richiesta non valida o sessione scaduta. Riprova.";
        error_log("CSRF token mismatch on review submission for product ID {$productId}. User ID: {$currentUser->user_id}");
    } else {
        $rating = filter_input(INPUT_POST, 'rating', FILTER_VALIDATE_INT);
        $commentText = trim(filter_input(INPUT_POST, 'comment_text', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
        $pros = trim(filter_input(INPUT_POST, 'pros', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
        $cons = trim(filter_input(INPUT_POST, 'cons', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
        $submittedProductId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);

        $reviewFormData = ['rating' => $rating, 'comment_text' => $commentText, 'pros' => $pros, 'cons' => $cons];

        if ($submittedProductId !== $productId) {
            $reviewErrorMessages['product_id_mismatch'] = "Errore nel prodotto selezionato per la recensione.";
        }
        if ($rating === false || $rating < 1 || $rating > 5) {
            $reviewErrorMessages['rating'] = "La valutazione (stelle) è obbligatoria e deve essere tra 1 e 5.";
        }
        if (empty($commentText)) {
            $reviewErrorMessages['comment_text'] = "Il testo della recensione è obbligatorio.";
        } elseif (strlen($commentText) < 10) {
             $reviewErrorMessages['comment_text'] = "Il testo della recensione deve contenere almeno 10 caratteri.";
        }
        
        try {
            if (Review::userHasReviewedProduct($currentUser->user_id, $productId)) {
                 $reviewErrorMessages['already_reviewed'] = "Hai già inviato una recensione per questo prodotto.";
                 $userHasReviewed = true; // Update flag as well
            }
        } catch (PDOException $e) {
            error_log("DB error checking if user {$currentUser->user_id} reviewed product {$productId}: " . $e->getMessage());
            $reviewErrorMessages['check_reviewed_failed'] = "Errore nel verificare se hai già recensito. Riprova.";
        }


        if (empty($reviewErrorMessages)) {
             try {
                $newReview = new Review([
                    'product_id' => $productId,
                    'user_id' => $currentUser->user_id,
                    'rating' => $rating,
                    'comment_text' => $commentText,
                    'pros' => $pros !== '' ? $pros : null,
                    'cons' => $cons !== '' ? $cons : null,
                    'is_approved' => false // New reviews require admin approval
                ]);

                if ($newReview->save()) {
                    // Redirect to self with success message to clear POST data
                    header("Location: dettaglio-prodotto.php?id_prodotto={$productId}&review_submitted=1#recensioni");
                    exit;
                } else {
                    $reviewErrorMessages['save_failed'] = "Errore nel salvataggio della recensione. Riprova più tardi.";
                    error_log("Review save failed. ProductID: {$productId}, UserID: {$currentUser->user_id}");
                }
            } catch (PDOException $e) {
                 error_log("Database error during review save: " . $e->getMessage());
                 $reviewErrorMessages['db_error'] = "Si è verificato un errore del database. Riprova più tardi.";
             }
        }
    }
}
$csrfToken = generateCsrfToken(); // Ensure CSRF token is always available for the form

// Load product details
if ($productId <= 0) {
    $pageTitle = "Prodotto non valido";
    $userErrorMessage = "L'ID del prodotto specificato non è valido.";
} else {
    try {
        $product = Product::getProductById($productId);
        if ($product) {
            $pageTitle = htmlspecialchars($product->name);
            if ($product->category_id) {
                $category = $product->getCategory();
            }

            // Fetch approved reviews for this product
            $reviews = Review::getByProductId($productId, true, $reviewsOrderBy, $reviewsOrderDirection);
            $totalApprovedReviews = Review::countByProductId($productId, true); // Count only approved

            // Check if logged-in user has already submitted any review for this product
            if ($currentUser && !$userHasReviewed) { // only check if not already set by POST error
                try {
                    $userHasReviewed = Review::userHasReviewedProduct($currentUser->user_id, $productId);
                } catch (PDOException $e){
                     error_log("DB error checking userHasReviewedProduct on GET: " . $e->getMessage());
                     // Decide how to handle, maybe show form and let submission fail or show an error
                }
            }

        } else {
            $pageTitle = "Prodotto non trovato";
            $userErrorMessage = "Il prodotto che stai cercando non è stato trovato.";
             http_response_code(404);
        }
    } catch (PDOException $e) {
        error_log("Errore nel caricamento del dettaglio prodotto ID {$productId}: " . $e->getMessage());
        $pageTitle = "Errore Prodotto";
        $userErrorMessage = "Si è verificato un errore nel caricamento dei dettagli del prodotto. Riprova più tardi.";
        http_response_code(500);
    }
}

$currentPage = ($product && !$userErrorMessage) ? 'products' : 'error'; // 'products' to show category nav

$placeholderImageWebPath = '../assets/placeholder.svg';

// Handle success message from redirect
if (isset($_GET['review_submitted']) && $_GET['review_submitted'] == 1) {
    $reviewSuccessMessage = "Grazie! La tua recensione è stata inviata e sarà visibile dopo l'approvazione da parte di un amministratore.";
}

include __DIR__ . '/../includes/header.php';
?>

<section class="dettaglio-prodotto">
    <?php if ($userErrorMessage): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
            <strong class="font-bold">Errore!</strong>
            <span class="block sm:inline"><?php echo htmlspecialchars($userErrorMessage); ?></span>
            <p class="mt-2"><a href="<?php echo htmlspecialchars($productsLink); ?>" class="text-blue-700 hover:underline">Torna all'elenco prodotti</a></p>
        </div>
    <?php elseif ($product): ?>
        <article>
            <nav class="mb-6 text-sm" aria-label="Breadcrumb">
                <ol class="flex flex-wrap items-center space-x-1 md:space-x-2">
                    <li class="flex items-center">
                        <a href="<?php echo htmlspecialchars($homeLink); ?>" class="text-blue-600 hover:underline">Home</a>
                        <svg class="w-4 h-4 ml-1 md:ml-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                    </li>
                     <li class="flex items-center">
                        <a href="<?php echo htmlspecialchars($productsLink); ?>" class="text-blue-600 hover:underline">Prodotti</a>
                        <svg class="w-4 h-4 ml-1 md:ml-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                    </li>
                    <?php if ($category): ?>
                         <li class="flex items-center">
                           <a href="<?php echo htmlspecialchars($productsLink . '?category_id=' . urlencode($category->category_id)); ?>" class="text-blue-600 hover:underline"><?php echo htmlspecialchars($category->name); ?></a>
                           <svg class="w-4 h-4 ml-1 md:ml-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                         </li>
                    <?php endif; ?>
                    <li>
                        <span class="text-gray-700" aria-current="page"><?php echo htmlspecialchars($product->name); ?></span>
                    </li>
                </ol>
            </nav>

            <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 md:p-8">
                    <div>
                        <div class="bg-gray-100 rounded-lg overflow-hidden mb-4 h-80 flex items-center justify-center">
                            <img
                                src="<?php echo !empty($product->image_url) ? htmlspecialchars($product->image_url) : $placeholderImageWebPath; ?>"
                                alt="Immagine di <?php echo htmlspecialchars($product->name); ?>"
                                class="w-full h-auto max-h-[500px] object-contain rounded-md">
                        </div>
                    </div>
                    <div class="product-info">
                        <h1 class="text-3xl lg:text-4xl font-bold text-gray-900 mb-3"><?php echo htmlspecialchars($product->name); ?></h1>

                        <?php if ($category): ?>
                        <p class="text-sm text-gray-500 mb-3">
                            Categoria: <a href="<?php echo htmlspecialchars($productsLink . '?category_id=' . urlencode($category->category_id)); ?>" class="text-blue-600 hover:underline"><?php echo htmlspecialchars($category->name); ?></a>
                        </p>
                        <?php endif; ?>

                        <?php if ($product->average_rating !== null): ?>
                        <div class="my-3 flex items-center">
                            <div class="rating-stars flex text-yellow-400" aria-label="Valutazione media: <?php echo number_format($product->average_rating, 1, ',', ''); ?> su 5 stelle">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <svg class="w-5 h-5 <?php echo ($i <= round($product->average_rating)) ? 'fill-current' : 'text-gray-300 fill-current'; ?>" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/></svg>
                                <?php endfor; ?>
                            </div>
                            <span class="ml-2 text-sm text-gray-600">(<?php echo number_format($product->average_rating, 1, ',', ''); ?> su 5 stelle)</span>
                            <?php if ($totalApprovedReviews > 0): ?>
                                <span class="mx-2 text-gray-300">|</span>
                                <a href="#recensioni" class="text-sm text-blue-600 hover:underline">Leggi (<?php echo $totalApprovedReviews; ?>) recensioni</a>
                            <?php endif; ?>
                        </div>
                        <?php else: ?>
                        <p class="text-sm text-gray-500 my-3">Ancora nessuna valutazione. <a href="#scrivi-recensione" class="text-blue-600 hover:underline">Sii il primo a recensire!</a></p>
                        <?php endif; ?>

                        <div class="prose prose-sm max-w-none mt-6 text-gray-700">
                            <h2 class="text-xl font-semibold text-gray-800 mb-2">Descrizione del Prodotto</h2>
                            <?php echo !empty($product->description) ? nl2br(htmlspecialchars($product->description)) : '<p>Nessuna descrizione dettagliata disponibile per questo prodotto.</p>'; ?>
                        </div>
                        <div class="mt-8">
                            <button type="button" class="px-6 py-3 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700 transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed" aria-disabled="true" title="Funzionalità futura">
                                Aggiungi al Carrello (Esempio)
                            </button>
                        </div>
                    </div>
                </div>

                <div id="recensioni" class="mt-12 pt-8 border-t border-gray-200">
                    <div class="p-6 md:p-8">
                         <!-- Success Message after redirect or general success -->
                        <?php if (!empty($reviewSuccessMessage)): ?>
                             <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded-md" role="status">
                                <p class="font-bold">Operazione Completata!</p>
                                <p><?php echo htmlspecialchars($reviewSuccessMessage); ?></p>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Review Submission Form Section -->
                        <div id="scrivi-recensione" class="mb-10 p-6 bg-gray-50 rounded-lg shadow-inner">
                            <?php if ($currentUser): ?>
                                <?php if ($userHasReviewed): ?>
                                    <p class="text-gray-700 text-center font-semibold">Hai già scritto una recensione per questo prodotto. Grazie per il tuo contributo!</p>
                                    <div class="mt-4 text-center">
                                         <a href="<?php echo htmlspecialchars($profileLink . '#le-tue-recensioni'); ?>" class="text-blue-600 hover:underline">Vedi le tue recensioni</a>
                                    </div>
                                <?php else: ?>
                                    <h3 class="text-xl font-semibold text-gray-800 mb-4">Lascia la tua recensione</h3>
                                    <?php if (!empty($reviewErrorMessages)): ?>
                                        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md" role="alert" aria-atomic="true">
                                            <p class="font-bold">Errore nell'invio della recensione</p>
                                            <ul class="mt-2 list-disc list-inside text-sm">
                                                <?php foreach ($reviewErrorMessages as $field => $errorMessage): ?>
                                                    <li><?php echo htmlspecialchars($errorMessage); ?></li>
                                                <?php endforeach; ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>

                                    <form action="dettaglio-prodotto.php?id_prodotto=<?php echo $productId; ?>#scrivi-recensione" method="post" class="space-y-6 needs-validation" novalidate>
                                         <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                                         <input type="hidden" name="action" value="submit_review">
                                         <input type="hidden" name="product_id" value="<?php echo $productId; ?>">

                                        <div class="form-field-container">
                                            <label for="review-rating-hidden" class="block text-gray-700 font-medium mb-2">Valutazione*</label>
                                            <div class="rating-input flex text-2xl text-gray-400" data-current-rating="<?php echo htmlspecialchars($reviewFormData['rating']); ?>" aria-label="Campo valutazione stelle">
                                                 <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <button type="button" class="star focus:outline-none <?php echo ($i <= (int)$reviewFormData['rating']) ? 'filled' : ''; ?>" data-rating="<?php echo $i; ?>" aria-label="<?php echo $i; ?> stelle su 5">★</button>
                                                 <?php endfor; ?>
                                            </div>
                                            <input type="hidden" name="rating" id="review-rating-hidden" value="<?php echo htmlspecialchars($reviewFormData['rating']); ?>" required>
                                            <span id="review-rating-error" class="error-text text-xs text-red-600 mt-1" aria-live="polite"></span>
                                        </div>

                                        <div>
                                            <label for="review-comment-text" class="block text-gray-700 font-medium mb-2">Recensione*</label>
                                            <textarea id="review-comment-text" name="comment_text" rows="5"
                                                      class="w-full px-3 py-2 border <?php echo isset($reviewErrorMessages['comment_text']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-md focus:ring-blue-500 focus:border-blue-500"
                                                      required aria-describedby="review-comment-text-error review-comment-desc" minlength="10"><?php echo htmlspecialchars($reviewFormData['comment_text']); ?></textarea>
                                            <p id="review-comment-desc" class="text-sm text-gray-500 mt-1">Minimo 10 caratteri.</p>
                                            <span id="review-comment-text-error" class="error-text text-xs text-red-600 mt-1" aria-live="polite"></span>
                                        </div>
                                        <div>
                                            <label for="review-pros" class="block text-gray-700 font-medium mb-2">Pro (Opzionale)</label>
                                            <textarea id="review-pros" name="pros" rows="3" placeholder="Elenca i punti di forza del prodotto..."
                                                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"><?php echo htmlspecialchars($reviewFormData['pros']); ?></textarea>
                                        </div>
                                        <div>
                                            <label for="review-cons" class="block text-gray-700 font-medium mb-2">Contro (Opzionale)</label>
                                            <textarea id="review-cons" name="cons" rows="3" placeholder="Elenca i punti deboli del prodotto..."
                                                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"><?php echo htmlspecialchars($reviewFormData['cons']); ?></textarea>
                                        </div>
                                        <div>
                                            <button type="submit" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                                Invia Recensione
                                            </button>
                                        </div>
                                    </form>
                                <?php endif; // end if $userHasReviewed check ?>
                            <?php else: // User not logged in ?>
                                <div class="text-center py-4">
                                    <p class="text-gray-700 mb-3 text-lg">Vuoi lasciare una recensione?</p>
                                    <a href="<?php echo htmlspecialchars($loginLink . '?redirect_after_login=' . urlencode($_SERVER['REQUEST_URI'] . '#scrivi-recensione')); ?>" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition shadow-sm">
                                        Accedi per Scrivere una Recensione
                                    </a>
                                    <p class="mt-2 text-sm text-gray-600">Non hai un account? <a href="<?php echo htmlspecialchars($registerLink); ?>" class="text-blue-600 hover:underline">Registrati</a></p>
                                </div>
                            <?php endif; // end if $currentUser check ?>
                        </div>

                        <!-- Display Reviews Section -->
                        <h2 class="text-2xl font-bold text-gray-900 mb-6">Recensioni degli Utenti (<?php echo $totalApprovedReviews; ?>)</h2>
                        <div class="mb-6 flex flex-col sm:flex-row justify-between items-center flex-wrap gap-y-3">
                              <h4 class="font-semibold text-lg text-gray-800 sr-only">Elenco Recensioni Approvate</h4>
                              <div class="flex items-center w-full sm:w-auto">
                                     <label for="review-sort" class="text-sm text-gray-700 mr-2 whitespace-nowrap">Ordina per:</label>
                                     <select id="review-sort" name="sort_reviews" class="rounded border-gray-300 py-1.5 px-2 text-sm focus:ring-blue-500 focus:border-blue-500 w-full sm:w-auto">
                                         <option value="created_at_DESC" <?php echo ($currentSortValue === 'created_at_DESC') ? 'selected' : ''; ?>>Più recenti</option>
                                         <option value="created_at_ASC" <?php echo ($currentSortValue === 'created_at_ASC') ? 'selected' : ''; ?>>Meno recenti</option>
                                         <option value="rating_DESC" <?php echo ($currentSortValue === 'rating_DESC') ? 'selected' : ''; ?>>Valutazione (più alta)</option>
                                         <option value="rating_ASC" <?php echo ($currentSortValue === 'rating_ASC') ? 'selected' : ''; ?>>Valutazione (più bassa)</option>
                                     </select>
                                 </div>
                            </div>

                        <div class="space-y-8">
                            <?php if (empty($reviews)): ?>
                                <div class="bg-gray-100 p-6 text-center rounded-lg">
                                    <p class="text-gray-600">Non ci sono ancora recensioni approvate per questo prodotto.</p>
                                    <?php if ($currentUser && !$userHasReviewed): ?>
                                        <p class="mt-2 text-sm text-gray-700">Sii il primo a lasciare la tua opinione!</p>
                                    <?php elseif (!$currentUser): ?>
                                         <p class="mt-2 text-sm text-gray-700">Accedi o registrati per essere il primo a recensire!</p>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <?php foreach ($reviews as $review): ?>
                                    <article class="border-b border-gray-200 pb-8 last:border-b-0 last:pb-0">
                                        <div class="flex items-start sm:items-center mb-2 flex-col sm:flex-row">
                                            <div class="rating-stars flex text-yellow-400 mb-1 sm:mb-0" aria-label="Valutazione data: <?php echo $review->rating; ?> su 5 stelle">
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <svg class="w-5 h-5 <?php echo ($i <= $review->rating) ? 'fill-current' : 'text-gray-300 fill-current'; ?>" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/></svg>
                                                <?php endfor; ?>
                                            </div>
                                            <?php /* <h5 class="ml-0 sm:ml-2 text-gray-700 font-medium text-base">Titolo Recensione (se presente)</h5> */ ?>
                                        </div>
                                        <p class="text-sm text-gray-500 mb-3">
                                            Scritto da <span class="font-medium text-gray-700"><?php echo htmlspecialchars($review->getUser()->username ?? 'Utente Sconosciuto'); ?></span>
                                            il <time datetime="<?php echo date('Y-m-d', strtotime($review->created_at)); ?>"><?php echo date('d F Y', strtotime($review->created_at)); ?></time>
                                        </p>
                                        <div class="prose prose-sm max-w-none text-gray-700 mb-4">
                                            <?php echo nl2br(htmlspecialchars($review->comment_text)); ?>
                                        </div>
                                        <?php if (!empty($review->pros)): ?>
                                        <div class="mb-3">
                                            <strong class="font-semibold text-gray-800 text-sm">Pro:</strong>
                                            <div class="prose prose-sm max-w-none text-green-700 ml-1">
                                                <?php echo nl2br(htmlspecialchars($review->pros)); ?>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if (!empty($review->cons)): ?>
                                        <div class="mb-3">
                                            <strong class="font-semibold text-gray-800 text-sm">Contro:</strong>
                                            <div class="prose prose-sm max-w-none text-red-700 ml-1">
                                                <?php echo nl2br(htmlspecialchars($review->cons)); ?>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <div class="flex items-center text-sm text-gray-500 space-x-4 mt-4">
                                            <button class="flex items-center hover:text-blue-600 disabled:opacity-50 disabled:cursor-not-allowed" title="Vota come utile (funzionalità futura)" disabled>
                                                <svg class="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" /></svg>
                                                Utile (0)
                                            </button>
                                            <button class="flex items-center hover:text-red-600 disabled:opacity-50 disabled:cursor-not-allowed" title="Vota come non utile (funzionalità futura)" disabled>
                                                 <svg class="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14H5.236a2 2 0 01-1.789-2.894l3.5-7A2 2 0 018.736 3h4.018a2 2 0 01.485.06l3.76.94m-7 10v5a2 2 0 002 2h.096c.5 0 .905-.405.905-.904 0-.715.211-1.413.608-2.008L17 13V4m-7 10h2" /></svg>
                                                 Non Utile (0)
                                            </button>
                                        </div>
                                    </article>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <section class="mt-12">
                <h3 class="text-2xl font-bold text-gray-900 mb-6">Prodotti Correlati</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                     <div class="bg-white rounded-lg overflow-hidden shadow-sm p-6 text-center">
                         <p class="text-gray-600">I prodotti correlati appariranno qui (funzionalità futura).</p>
                     </div>
                 </div>
            </section>
        </article>
    <?php endif; ?>
</section>

<?php
$currentProductId = $product ? $product->product_id : 0;
$additionalScripts = '
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Review sorting
    const reviewSortSelect = document.getElementById("review-sort");
    if (reviewSortSelect) {
        reviewSortSelect.addEventListener("change", function() {
            const [orderBy, orderDirection] = this.value.split("_");
            const currentUrl = new URL(window.location.href);
            currentUrl.searchParams.set("ordina_recensioni", orderBy);
            currentUrl.searchParams.set("direzione_recensioni", orderDirection);
            if (' . $currentProductId . ' > 0) { // Ensure product ID is part of URL
                 currentUrl.searchParams.set("id_prodotto", ' . $currentProductId . ');
            }
            window.location.href = currentUrl.toString() + "#recensioni"; // Go to reviews section
        });
    }

    // Interactive Rating Stars for Review Form
    const ratingInputContainer = document.querySelector(".rating-input");
    if (ratingInputContainer) {
        const ratingHiddenInput = document.getElementById("review-rating-hidden");
        const ratingStars = ratingInputContainer.querySelectorAll(".star");
        const ratingErrorSpan = document.getElementById("review-rating-error");

        function updateStarsDisplay(rating) {
            ratingStars.forEach((star, index) => {
                star.classList.toggle("filled", index < rating);
                star.classList.remove("hover-fill");
            });
        }
        
        function setRating(rating) {
            ratingHiddenInput.value = rating;
            updateStarsDisplay(rating);
            if (ratingErrorSpan) ratingErrorSpan.textContent = ""; // Clear error
            ratingInputContainer.classList.remove("form-input-error-visual"); // Clear visual error indicator
        }

        ratingStars.forEach(star => {
            const ratingValue = parseInt(star.getAttribute("data-rating"));
            star.addEventListener("click", function() {
                setRating(ratingValue);
                ratingInputContainer.dataset.currentRating = ratingValue;
            });
            star.addEventListener("mouseover", function() {
                ratingStars.forEach((s, i) => s.classList.toggle("hover-fill", i < ratingValue));
            });
            star.addEventListener("focus", function() { // For keyboard accessibility
                ratingStars.forEach((s, i) => s.classList.toggle("hover-fill", i < ratingValue));
            });
            star.addEventListener("blur", function() { // For keyboard accessibility
                ratingStars.forEach(s => s.classList.remove("hover-fill"));
                updateStarsDisplay(parseInt(ratingInputContainer.dataset.currentRating) || 0);
            });
        });
        ratingInputContainer.addEventListener("mouseleave", function() {
            ratingStars.forEach(s => s.classList.remove("hover-fill"));
            updateStarsDisplay(parseInt(ratingInputContainer.dataset.currentRating) || 0);
        });
        // Initialize stars based on hidden input value (e.g., on error repopulation)
        const initialRating = parseInt(ratingHiddenInput.value);
        if (!isNaN(initialRating) && initialRating > 0) {
            setRating(initialRating);
            ratingInputContainer.dataset.currentRating = initialRating;
        }
    }

    // Review Form Validation
    const reviewForm = document.querySelector("#scrivi-recensione form.needs-validation");
    if (reviewForm) {
        const commentTextInput = document.getElementById("review-comment-text");
        const ratingHiddenInput = document.getElementById("review-rating-hidden");

        reviewForm.addEventListener("submit", function(event) {
            let formIsValid = true;
            // Clear previous JS errors
            clearValidationErrors(commentTextInput);
            const ratingErrorEl = document.getElementById("review-rating-error");
            if(ratingErrorEl) ratingErrorEl.textContent = "";
            if(ratingInputContainer) ratingInputContainer.classList.remove("form-input-error-visual");


            const currentRating = parseInt(ratingHiddenInput.value);
            if (isNaN(currentRating) || currentRating < 1 || currentRating > 5) {
                formIsValid = false;
                if(ratingErrorEl) ratingErrorEl.textContent = "Seleziona una valutazione in stelle.";
                if(ratingInputContainer) ratingInputContainer.classList.add("form-input-error-visual"); // Add a class for visual feedback
            }
            
            if (!validateReviewContent(commentTextInput.value)) { // Using global validator
                formIsValid = false;
                showValidationErrors(commentTextInput, ["La recensione deve contenere almeno 10 caratteri."]);
            }

            if (!formIsValid) {
                event.preventDefault();
                const firstErrorField = reviewForm.querySelector(".form-input-error, .form-input-error-visual, [aria-invalid=\'true\']");
                if (firstErrorField) {
                    if (firstErrorField.classList.contains("rating-input")) {
                        firstErrorField.querySelector(".star").focus();
                    } else {
                        firstErrorField.focus();
                    }
                }
            }
        });
        // Live validation for comment text
        commentTextInput.addEventListener("input", function() {
             if (validateReviewContent(this.value)) {
                 clearValidationErrors(this);
             } else {
                // Optionally show error as user types if below threshold
                // showValidationErrors(this, ["La recensione deve contenere almeno 10 caratteri."]);
             }
        });
    }
     // Re-apply PHP errors visually if they were present
    ' . (!empty($reviewErrorMessages['rating']) ? 'const rErr = document.getElementById("review-rating-error"); if(rErr) rErr.textContent = "'.htmlspecialchars($reviewErrorMessages['rating']).'"; if(document.querySelector(".rating-input")) document.querySelector(".rating-input").classList.add("form-input-error-visual");' : '') . '
    ' . (!empty($reviewErrorMessages['comment_text']) ? 'showValidationErrors(document.getElementById("review-comment-text"), ["'.htmlspecialchars($reviewErrorMessages['comment_text']).'"]);' : '') . '
});
</script>';

$validatorsJsPath = $projectWebRoot . '/js/validators.js';
include __DIR__ . '/../includes/footer.php';
?>





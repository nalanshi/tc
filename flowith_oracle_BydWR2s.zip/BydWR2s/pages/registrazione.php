Implementing e() and Preparing Admin

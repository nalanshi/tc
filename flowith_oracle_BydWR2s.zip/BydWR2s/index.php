<?php
// Main index file - will eventually load content dynamically

// Include database connection setup
require_once __DIR__ . '/config/db.php'; // Includes e() helper
// Include data models
require_once __DIR__ . '/models/Product.php';
require_once __DIR__ . '/models/Category.php';
require_once __DIR__ . '/models/User.php';
require_once __DIR__ . '/models/Review.php';
require_once __DIR__ . '/models/ReviewVote.php'; 

// Set page-specific variables for header and footer
$pageTitle = "Prodotto Recensioni Aggregate - Home";
$pageDescription = "La tua piattaforma affidabile per esplorare, valutare e condividere recensioni di prodotti.";
$currentPage = 'home'; // Identifier for navigation

// Include header
include __DIR__ . '/includes/header.php';

// --- Static HTML content below header (as provided in original) ---
?>

        <section class="mb-12 text-center">
            <div class="max-w-4xl mx-auto">
                <h2 class="text-3xl md:text-4xl font-bold mb-6 text-gray-900">Benvenuti a Prodotto Recensioni Aggregate</h2>
                <p class="text-lg md:text-xl text-gray-700 mb-8">
                    La tua piattaforma affidabile per esplorare, valutare e condividere recensioni di prodotti.
                    Aiutiamo i consumatori a prendere decisioni di acquisto più informate.
                </p>
                <div class="flex flex-col sm:flex-row justify-center gap-4">
                    <!-- Links updated to .php, using variables from header.php -->
                    <a href="<?php echo e($productsLink); ?>" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition shadow-sm">
                        Esplora Prodotti
                    </a>
                     <?php if (!isLoggedIn()): ?>
                        <a href="<?php echo e($registerLink); ?>" class="px-6 py-3 bg-white text-blue-600 border border-blue-600 rounded-lg hover:bg-blue-50 transition shadow-sm">
                            Unisciti Adesso
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <section class="mb-12 bg-white rounded-xl shadow-sm p-6 md:p-8">
            <h2 class="text-2xl font-bold mb-6 text-gray-800 text-center">Come Funziona</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="flex flex-col items-center text-center">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4" aria-hidden="true">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold mb-2 text-gray-800">Cerca</h3>
                    <p class="text-gray-600">Trova facilmente prodotti per categoria, nome o caratteristiche.</p>
                </div>
                <div class="flex flex-col items-center text-center">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4" aria-hidden="true">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold mb-2 text-gray-800">Confronta</h3>
                    <p class="text-gray-600">Leggi recensioni verificate e confronta le caratteristiche dei prodotti.</p>
                </div>
                <div class="flex flex-col items-center text-center">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4" aria-hidden="true">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold mb-2 text-gray-800">Recensisci</h3>
                    <p class="text-gray-600">Condividi la tua esperienza e aiuta altri consumatori nelle loro scelte.</p>
                </div>
            </div>
        </section>

        <section class="mb-12">
            <h2 class="text-2xl font-bold mb-6 text-gray-800 text-center">Categorie Popolari</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <?php
                $popularCategories = [];
                try {
                    $allCategories = Category::getAll('name', 'ASC');
                    $popularCategories = array_slice($allCategories, 0, 4); // Show first 4
                } catch (PDOException $e) {
                    error_log("Error fetching categories for homepage: " . $e->getMessage());
                }

                if (empty($popularCategories)): ?>
                    <p class="col-span-full text-center text-gray-500">Nessuna categoria da mostrare al momento.</p>
                <?php else:
                    foreach ($popularCategories as $category): ?>
                        <a href="<?php echo e($productsLink . '?category_id=' . $category->category_id); ?>" class="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition group">
                            <?php // Placeholder for category image - if $category->image_url exists, use it. Otherwise, an SVG.
                                  // For lazy loading, if it was an <img> tag: <img src="..." alt="..." loading="lazy">
                            ?>
                            <div class="h-32 bg-gray-200 flex items-center justify-center group-hover:bg-gray-300 transition" aria-hidden="true">
                                <!-- Generic category icon, could be replaced with category-specific images/icons if available -->
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-gray-400 group-hover:text-gray-500 transition" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                                </svg>
                            </div>
                            <div class="p-4">
                                <h3 class="font-medium text-gray-800 text-center"><?php echo e($category->name); ?></h3>
                            </div>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>

<?php
// Include footer
include __DIR__ . '/includes/footer.php';
?>

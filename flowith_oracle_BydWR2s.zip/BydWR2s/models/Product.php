<?php
// models/Product.php

require_once __DIR__ . '/../config/db.php'; // Includes e()
require_once __DIR__ . '/Category.php'; 

/**
 * Represents the Product data model and provides database interaction methods.
 */
class Product {
    public int $product_id;
    public string $name;
    public ?string $description;
    public ?int $category_id; 
    public ?string $image_url;
    public ?float $average_rating; 
    public string $created_at;
    public string $updated_at;

    private ?Category $category_object = null;

    public function __construct(array $data) {
        $this->product_id = isset($data['product_id']) ? (int)$data['product_id'] : 0;
        $this->name = $data['name'] ?? '';
        $this->description = $data['description'] ?? null;
        $this->category_id = (isset($data['category_id']) && $data['category_id'] !== '' && $data['category_id'] !== 0) ? (int)$data['category_id'] : null;
        $this->image_url = $data['image_url'] ?? null;
        $this->average_rating = (isset($data['average_rating']) && $data['average_rating'] !== null) ? (float)$data['average_rating'] : null;
        $this->created_at = $data['created_at'] ?? date('Y-m-d H:i:s');
        $this->updated_at = $data['updated_at'] ?? date('Y-m-d H:i:s');
    }

    public static function getProductById(int $id): ?Product {
        return self::getById($id);
    }

    public static function getById(int $id): ?Product {
        $sql = "SELECT * FROM Products WHERE product_id = :product_id";
        $params = [':product_id' => $id];
        try {
            $result = executeQuery($sql, $params, false);
            return $result ? new self($result) : null;
        } catch (PDOException $e) {
            error_log("Failed to get product by ID {$id}: " . $e->getMessage());
            throw $e;
        }
    }

    public static function getAllProducts(int $limit = 10, int $offset = 0, string $orderBy = 'created_at', string $orderDirection = 'DESC'): array {
        return self::getAll(null, null, $limit, $offset, $orderBy, $orderDirection);
    }

    public static function getProductsByCategory(int $categoryId, int $limit = 10, int $offset = 0, string $orderBy = 'created_at', string $orderDirection = 'DESC'): array {
        return self::getAll($categoryId, null, $limit, $offset, $orderBy, $orderDirection);
    }

    public static function searchProducts(string $searchTerm, int $limit = 10, int $offset = 0): array {
        return self::getAll(null, $searchTerm, $limit, $offset, 'name', 'ASC');
    }

    public static function getAll(?int $categoryId = null, ?string $searchTerm = null, ?int $limit = 10, int $offset = 0, string $orderBy = 'created_at', string $orderDirection = 'DESC'): array {
        $sql = "SELECT * FROM Products";
        $params = [];
        $whereClauses = [];

        if ($categoryId !== null && $categoryId > 0) {
            $whereClauses[] = "category_id = :category_id";
            $params[':category_id'] = $categoryId;
        }

        if ($searchTerm !== null && !empty(trim($searchTerm))) {
            $trimmedSearchTerm = '%' . trim($searchTerm) . '%';
            $whereClauses[] = "(name LIKE :search_term OR description LIKE :search_term)";
            $params[':search_term'] = $trimmedSearchTerm;
        }

        if (!empty($whereClauses)) {
            $sql .= " WHERE " . implode(" AND ", $whereClauses);
        }

        $allowedOrderBy = ['product_id', 'name', 'average_rating', 'created_at', 'updated_at'];
        $cleanedOrderBy = in_array(strtolower($orderBy), $allowedOrderBy) ? strtolower($orderBy) : 'created_at';
        $allowedOrderDirection = ['ASC', 'DESC'];
        $cleanedOrderDirection = in_array(strtoupper($orderDirection), $allowedOrderDirection) ? strtoupper($orderDirection) : 'DESC';
        
        if ($cleanedOrderBy === 'average_rating') {
             $sql .= " ORDER BY average_rating IS NULL ASC, average_rating {$cleanedOrderDirection}, product_id ASC"; // Handles NULLs last for DESC, first for ASC
        } else {
             $sql .= " ORDER BY {$cleanedOrderBy} {$cleanedOrderDirection}, product_id ASC";
        }

        if ($limit !== null && $limit > 0) {
             $sql .= " LIMIT :limit OFFSET :offset";
             $params[':limit'] = (int)$limit;
             $params[':offset'] = (int)$offset;
        }

        try {
            $results = executeQuery($sql, $params);
            $products = [];
            foreach ($results as $data) {
                $products[] = new self($data);
            }
            return $products;
        } catch (PDOException $e) {
            error_log("Failed to get products (Category ID: {$categoryId}, Search: '" . e($searchTerm ?? '') . "', SQL: {$sql}): " . $e->getMessage() . " Params: " . json_encode($params));
            throw $e;
        }
    }

    public static function countAll(?int $categoryId = null, ?string $searchTerm = null): int {
        $sql = "SELECT COUNT(*) FROM Products";
        $params = [];
        $whereClauses = [];

         if ($categoryId !== null && $categoryId > 0) {
            $whereClauses[] = "category_id = :category_id";
            $params[':category_id'] = $categoryId;
        }

        if ($searchTerm !== null && !empty(trim($searchTerm))) {
            $trimmedSearchTerm = '%' . trim($searchTerm) . '%';
            $whereClauses[] = "(name LIKE :search_term OR description LIKE :search_term)";
            $params[':search_term'] = $trimmedSearchTerm;
        }

        if (!empty($whereClauses)) {
            $sql .= " WHERE " . implode(" AND ", $whereClauses);
        }

        try {
            $result = executeQuery($sql, $params, false);
            return $result ? (int)$result['COUNT(*)'] : 0;
        } catch (PDOException $e) {
            error_log("Failed to count products (Category ID: {$categoryId}, Search: '" . e($searchTerm ?? '') . "'): " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Gets product counts for a list of category IDs.
     * Optimized to fetch all counts in one query.
     *
     * @param array $categoryIds An array of category IDs.
     * @return array An associative array where keys are category IDs and values are product counts.
     * @throws PDOException On database error.
     */
    public static function getProductCountsByCategories(array $categoryIds): array {
        if (empty($categoryIds)) {
            return [];
        }
        // Ensure all IDs are integers for security in IN clause
        $sanitizedCategoryIds = array_map('intval', $categoryIds);
        $placeholders = implode(',', array_fill(0, count($sanitizedCategoryIds), '?'));

        $sql = "SELECT category_id, COUNT(*) as product_count 
                FROM Products 
                WHERE category_id IN ({$placeholders})
                GROUP BY category_id";
        
        $counts = [];
        try {
            $results = executeQuery($sql, $sanitizedCategoryIds);
            foreach ($results as $row) {
                $counts[(int)$row['category_id']] = (int)$row['product_count'];
            }
        } catch (PDOException $e) {
            error_log("Failed to get product counts by categories: " . $e->getMessage());
            throw $e;
        }
        // Ensure all requested category IDs have an entry, even if count is 0
        foreach ($categoryIds as $id) {
            if (!isset($counts[$id])) {
                $counts[$id] = 0;
            }
        }
        return $counts;
    }


    public function save(): bool {
        $this->name = trim($this->name);
        if (empty($this->name)) {
            throw new InvalidArgumentException("Nome prodotto non può essere vuoto.");
        }
        
        if (!empty($this->image_url) && !filter_var($this->image_url, FILTER_VALIDATE_URL)) {
             throw new InvalidArgumentException("L'URL dell'immagine non è valido: " . e($this->image_url));
        }
        if ($this->category_id === 0) $this->category_id = null;

        if ($this->product_id > 0) {
            $sql = "UPDATE Products SET
                        name = :name,
                        description = :description,
                        category_id = :category_id,
                        image_url = :image_url,
                        average_rating = :average_rating,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE product_id = :product_id";
            $params = [
                ':name' => $this->name,
                ':description' => $this->description,
                ':category_id' => $this->category_id,
                ':image_url' => $this->image_url,
                ':average_rating' => $this->average_rating, 
                ':product_id' => $this->product_id
            ];
        } else {
            $sql = "INSERT INTO Products (name, description, category_id, image_url, average_rating, created_at, updated_at)
                    VALUES (:name, :description, :category_id, :image_url, :average_rating, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
            $params = [
                ':name' => $this->name,
                ':description' => $this->description,
                ':category_id' => $this->category_id,
                ':image_url' => $this->image_url,
                ':average_rating' => $this->average_rating
            ];
        }

        try {
            $rowCount = executeQuery($sql, $params, false);
            if ($this->product_id === 0 && $rowCount > 0) {
                 $pdo = connectDB();
                $this->product_id = (int)$pdo->lastInsertId();
            }
            return $rowCount > 0;
        } catch (PDOException $e) {
            error_log("Failed to save product (ID: {$this->product_id}, Name: " . e($this->name) . "): " . $e->getMessage());
             if ($e->getCode() == '23000') { // Integrity constraint violation
                 throw new PDOException("Errore: Esiste già un prodotto con dettagli simili (es. nome duplicato se UNIQUE).", (int)$e->getCode(), $e);
             }
            throw $e;
        }
    }

    public function delete(): bool {
        if ($this->product_id <= 0) {
            return false;
        }
        $sql = "DELETE FROM Products WHERE product_id = :product_id";
        $params = [':product_id' => $this->product_id];
        try {
            $rowCount = executeQuery($sql, $params, false);
            return $rowCount > 0;
        } catch (PDOException $e) {
            error_log("Failed to delete product ID {$this->product_id}: " . $e->getMessage());
            throw $e;
        }
    }

    public function getCategory(): ?Category {
        if ($this->category_id === null || $this->category_id <= 0) {
            return null;
        }
        if ($this->category_object !== null && $this->category_object->category_id === $this->category_id) {
            return $this->category_object;
        }
        try {
            $this->category_object = Category::getById($this->category_id);
        } catch (PDOException $e) {
            error_log("Error fetching category {$this->category_id} for product {$this->product_id}: " . $e->getMessage());
            $this->category_object = null;
        }
        return $this->category_object;
    }

    public function updateAverageRating(): bool {
        if ($this->product_id <= 0) {
            return false;
        }
        $sql = "SELECT AVG(rating) as avg_rating FROM Reviews WHERE product_id = :product_id AND is_approved = TRUE";
        $params = [':product_id' => $this->product_id];
        try {
            $result = executeQuery($sql, $params, false);
            $new_rating = ($result && $result['avg_rating'] !== null) ? round((float)$result['avg_rating'], 2) : null;
            $update_sql = "UPDATE Products SET average_rating = :average_rating, updated_at = CURRENT_TIMESTAMP WHERE product_id = :product_id";
            $update_params = [
                 ':average_rating' => $new_rating,
                 ':product_id' => $this->product_id
            ];
            $rowCount = executeQuery($update_sql, $update_params, false);
            $this->average_rating = $new_rating;
            return $rowCount > 0 || ($new_rating === null && $this->average_rating === null) || ($new_rating == $this->average_rating);
        } catch (PDOException $e) {
            error_log("Failed to update average rating for product ID " . $this->product_id . ": " . $e->getMessage());
            throw $e;
        }
    }
}

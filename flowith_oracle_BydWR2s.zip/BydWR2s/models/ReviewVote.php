<?php
// models/ReviewVote.php

require_once __DIR__ . '/../config/db.php';
// No direct need to include Review.php or User.php for ReviewVote model itself,
// but they are related concepts.

/**
 * Represents the Review_Votes data model and provides database interaction methods.
 */
class ReviewVote {
    public int $vote_id;
    public int $review_id;
    public int $user_id;
    public string $vote_type; // 'up' or 'down'
    public string $created_at;

     /**
     * Constructor
     * @param array $data An associative array of vote data, typically fetched from the database.
     */
    public function __construct(array $data) {
        $this->vote_id = isset($data['vote_id']) ? (int)$data['vote_id'] : 0;
        $this->review_id = isset($data['review_id']) ? (int)$data['review_id'] : 0;
        $this->user_id = isset($data['user_id']) ? (int)$data['user_id'] : 0;
        $this->vote_type = $data['vote_type'] ?? ''; // 'up' or 'down'
        $this->created_at = $data['created_at'] ?? ''; // Set by DB
    }

     /**
     * Gets a single vote by its ID.
     *
     * @param int $id The vote ID.
     * @return ReviewVote|null The ReviewVote object if found, null otherwise.
     * @throws PDOException On database error.
     */
    public static function getById(int $id): ?ReviewVote {
        $sql = "SELECT * FROM Review_Votes WHERE vote_id = :vote_id";
        $params = [':vote_id' => $id];

        try {
            $result = executeQuery($sql, $params, false);
            return $result ? new self($result) : null;
        } catch (PDOException $e) {
            error_log("Failed to get review vote by ID {$id}: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Gets a vote by review ID and user ID (due to unique constraint).
     *
     * @param int $reviewId
     * @param int $userId
     * @return ReviewVote|null
     * @throws PDOException On database error.
     */
    public static function getByReviewAndUser(int $reviewId, int $userId): ?ReviewVote {
        $sql = "SELECT * FROM Review_Votes WHERE review_id = :review_id AND user_id = :user_id";
        $params = [':review_id' => $reviewId, ':user_id' => $userId];

        try {
             $result = executeQuery($sql, $params, false);
             return $result ? new self($result) : null;
        } catch (PDOException $e) {
            error_log("Failed to get vote by review ID {$reviewId} and user ID {$userId}: " . $e->getMessage());
            throw $e;
        }
    }

     /**
     * Gets all votes for a specific review.
     *
     * @param int $reviewId The review ID.
     * @return array An array of ReviewVote objects.
     * @throws PDOException On database error.
     */
    public static function getByReviewId(int $reviewId): array {
        $sql = "SELECT * FROM Review_Votes WHERE review_id = :review_id ORDER BY created_at DESC";
        $params = [':review_id' => $reviewId];

        try {
            $results = executeQuery($sql, $params);
            $votes = [];
            foreach ($results as $data) {
                $votes[] = new self($data);
            }
            return $votes;
        } catch (PDOException $e) {
            error_log("Failed to get votes by review ID {$reviewId}: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Counts the number of 'up' and 'down' votes for a specific review.
     *
     * @param int $reviewId The review ID.
     * @return array An associative array with 'up' and 'down' keys and their respective counts.
     * @throws PDOException On database error.
     */
    public static function countVotes(int $reviewId): array {
        $sql = "SELECT vote_type, COUNT(*) as count FROM Review_Votes WHERE review_id = :review_id GROUP BY vote_type";
        $params = [':review_id' => $reviewId];
        $counts = ['up' => 0, 'down' => 0];

        try {
             $results = executeQuery($sql, $params);
             foreach ($results as $row) {
                 if (isset($counts[$row['vote_type']])) {
                     $counts[$row['vote_type']] = (int)$row['count'];
                 }
             }
        } catch (PDOException $e) {
            error_log("Failed to count votes for review ID {$reviewId}: " . $e->getMessage());
            // Potentially throw $e depending on how critical this is for the caller
            // For now, returns [0,0] on error if not re-thrown
        }
        return $counts;
    }


    /**
     * Saves (creates or updates) a vote.
     * If a user has already voted on a review, this method will:
     * - If the new vote_type is the same as the old one, do nothing (or effectively delete and re-insert).
     * - If the new vote_type is different, update the existing vote's type.
     * - If no vote exists, insert a new one.
     *
     * @return bool True on success, false on failure or if data is invalid.
     * @throws PDOException On database error.
     */
    public function save(): bool {
        if ($this->review_id <= 0 || $this->user_id <= 0 || !in_array($this->vote_type, ['up', 'down'])) {
            error_log("Attempted to save review vote with invalid data.");
            return false; // Invalid vote data
        }

        $pdo = connectDB();
        try {
            $pdo->beginTransaction();

            // Check for existing vote by this user on this review
            $existingVote = self::getByReviewAndUser($this->review_id, $this->user_id);

            if ($existingVote) {
                // User has already voted
                if ($existingVote->vote_type === $this->vote_type) {
                    // Vote is the same, do nothing (or one could argue to "refresh" the timestamp)
                    // To remove the vote if same type is clicked again (toggle):
                    // $this->deleteById($existingVote->vote_id); // Assuming deleteById static method
                    // For now, consider it "no change needed".
                    $pdo->commit();
                    return true; // Or false if you want to indicate no row was changed
                } else {
                    // Vote type is different, update existing vote
                    $sql = "UPDATE Review_Votes SET vote_type = :vote_type, created_at = CURRENT_TIMESTAMP WHERE vote_id = :vote_id";
                    $params = [
                        ':vote_type' => $this->vote_type,
                        ':vote_id' => $existingVote->vote_id
                    ];
                    $rowCount = executeQuery($sql, $params, false);
                    // Update current object's created_at if needed, though DB handles it
                }
            } else {
                // No existing vote, insert new vote
                $sql = "INSERT INTO Review_Votes (review_id, user_id, vote_type) VALUES (:review_id, :user_id, :vote_type)";
                $params = [
                    ':review_id' => $this->review_id,
                    ':user_id' => $this->user_id,
                    ':vote_type' => $this->vote_type
                ];
                $rowCount = executeQuery($sql, $params, false);
                if ($rowCount > 0) {
                    $this->vote_id = (int)$pdo->lastInsertId();
                    // created_at will be set by DB
                }
            }
            $pdo->commit();
            return $rowCount > 0;

        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("Failed to save review vote (Review ID: {$this->review_id}, User ID: {$this->user_id}): " . $e->getMessage());
            if ($e->getCode() == '23000') { // Unique constraint usually
                 throw new PDOException("Errore di vincolo durante il salvataggio del voto.", (int)$e->getCode(), $e);
            }
            throw $e;
        }
    }

    /**
     * Deletes a vote by its vote_id.
     *
     * @return bool True on success, false if vote_id is invalid or delete fails.
     * @throws PDOException On database error.
     */
    public function delete(): bool {
        if ($this->vote_id <= 0) {
            error_log("Attempted to delete vote with invalid ID: {$this->vote_id}");
            return false;
        }
        $sql = "DELETE FROM Review_Votes WHERE vote_id = :vote_id";
        $params = [':vote_id' => $this->vote_id];
        try {
            $rowCount = executeQuery($sql, $params, false);
            return $rowCount > 0;
        } catch (PDOException $e) {
            error_log("Failed to delete review vote ID {$this->vote_id}: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Static method to remove a user's vote for a specific review.
     * Useful for "un-voting".
     *
     * @param int $reviewId
     * @param int $userId
     * @return bool True if a vote was removed, false otherwise.
     * @throws PDOException
     */
    public static function removeVote(int $reviewId, int $userId): bool {
        $sql = "DELETE FROM Review_Votes WHERE review_id = :review_id AND user_id = :user_id";
        $params = [':review_id' => $reviewId, ':user_id' => $userId];
        try {
            $rowCount = executeQuery($sql, $params, false);
            return $rowCount > 0;
        } catch (PDOException $e) {
            error_log("Failed to remove vote for review ID {$reviewId} by user ID {$userId}: " . $e->getMessage());
            throw $e;
        }
    }
}








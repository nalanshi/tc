<?php
// models/Review.php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/Product.php';
require_once __DIR__ . '/User.php';

/**
 * Represents the Review data model and provides database interaction methods.
 */
class Review {
    public int $review_id;
    public int $product_id;
    public int $user_id;
    public int $rating; // 1-5
    public string $comment_text;
    public ?string $pros;
    public ?string $cons;
    public bool $is_approved; // true for approved, false for pending/rejected
    public string $created_at;
    public string $updated_at;

    private ?Product $product_object = null;
    private ?User $user_object = null;

    public function __construct(array $data) {
        $this->review_id = isset($data['review_id']) ? (int)$data['review_id'] : 0;
        $this->product_id = isset($data['product_id']) ? (int)$data['product_id'] : 0;
        $this->user_id = isset($data['user_id']) ? (int)$data['user_id'] : 0;
        $this->rating = isset($data['rating']) ? (int)$data['rating'] : 0;
        $this->comment_text = $data['comment_text'] ?? '';
        $this->pros = $data['pros'] ?? null;
        $this->cons = $data['cons'] ?? null;
        // Ensure is_approved is strictly boolean from DB (0 or 1)
        $this->is_approved = isset($data['is_approved']) ? filter_var($data['is_approved'], FILTER_VALIDATE_BOOLEAN) : false;
        $this->created_at = $data['created_at'] ?? '';
        $this->updated_at = $data['updated_at'] ?? '';
    }

    public static function getById(int $id): ?Review {
        $sql = "SELECT r.*, u.username, p.name as product_name 
                FROM Reviews r 
                JOIN Users u ON r.user_id = u.user_id
                JOIN Products p ON r.product_id = p.product_id
                WHERE r.review_id = :review_id";
        $params = [':review_id' => $id];
        try {
            $result = executeQuery($sql, $params, false);
            if ($result) {
                $review = new self($result);
                // Pre-populate user and product objects with available data
                $review->user_object = new User(['user_id' => $review->user_id, 'username' => $result['username'] ?? 'Utente Sconosciuto']);
                $review->product_object = new Product(['product_id' => $review->product_id, 'name' => $result['product_name'] ?? 'Prodotto Sconosciuto']);
                return $review;
            }
            return null;
        } catch (PDOException $e) {
            error_log("Failed to get review by ID {$id}: " . $e->getMessage());
            throw $e;
        }
    }

    public static function getByProductId(int $productId, ?bool $isApproved = true, string $orderBy = 'created_at', string $orderDirection = 'DESC', ?int $limit = null, int $offset = 0): array {
        $sql = "SELECT r.*, u.username FROM Reviews r JOIN Users u ON r.user_id = u.user_id WHERE r.product_id = :product_id";
        $params = [':product_id' => $productId];

        if ($isApproved !== null) {
            $sql .= " AND r.is_approved = :is_approved";
            $params[':is_approved'] = $isApproved ? 1 : 0;
        }

        $allowedOrderBy = ['created_at', 'rating']; 
        $allowedOrderDirection = ['ASC', 'DESC'];

        $orderByColumn = 'r.created_at'; 
        if (in_array(strtolower($orderBy), $allowedOrderBy)) {
             $orderByColumn = 'r.' . strtolower($orderBy);
        }

        $orderDirection = in_array(strtoupper($orderDirection), $allowedOrderDirection) ? strtoupper($orderDirection) : 'DESC';
        $sql .= " ORDER BY {$orderByColumn} {$orderDirection}, r.review_id {$orderDirection}"; 

        if ($limit !== null && $limit > 0) {
            $sql .= " LIMIT :limit OFFSET :offset";
            $params[':limit'] = (int)$limit;
            $params[':offset'] = (int)$offset;
        }

        try {
            $results = executeQuery($sql, $params);
            $reviews = [];
            foreach ($results as $data) {
                $review = new self($data);
                $review->user_object = new User(['user_id' => $review->user_id, 'username' => $data['username'] ?? 'Utente Sconosciuto']);
                $reviews[] = $review;
            }
            return $reviews;
        } catch (PDOException $e) {
            error_log("Failed to get reviews by product ID {$productId}: " . $e->getMessage() . " SQL: " . $sql);
            throw $e;
        }
    }

    public static function countByProductId(int $productId, ?bool $isApproved = true): int {
        $sql = "SELECT COUNT(*) FROM Reviews WHERE product_id = :product_id";
        $params = [':product_id' => $productId];
         if ($isApproved !== null) {
            $sql .= " AND is_approved = :is_approved";
            $params[':is_approved'] = $isApproved ? 1 : 0;
        }
        try {
            $result = executeQuery($sql, $params, false);
            return $result ? (int)$result['COUNT(*)'] : 0;
        } catch (PDOException $e) {
            error_log("Failed to count reviews for product ID {$productId}: " . $e->getMessage());
            throw $e;
        }
    }

    public static function getByUserId(int $userId, string $orderBy = 'created_at', string $orderDirection = 'DESC', ?int $limit = null, int $offset = 0): array {
        $sql = "SELECT r.*, p.name AS product_name FROM Reviews r JOIN Products p ON r.product_id = p.product_id WHERE r.user_id = :user_id";
        $params = [':user_id' => $userId];

        $allowedOrderBy = ['review_id', 'rating', 'created_at', 'updated_at', 'is_approved']; 
        $allowedOrderDirection = ['ASC', 'DESC'];

        $orderByCol = 'created_at'; 
        if (in_array(strtolower($orderBy), $allowedOrderBy)) {
            $orderByCol = strtolower($orderBy);
        }
        $orderDirection = in_array(strtoupper($orderDirection), $allowedOrderDirection) ? strtoupper($orderDirection) : 'DESC';
        $sql .= " ORDER BY r.{$orderByCol} {$orderDirection}, r.review_id {$orderDirection}";

        if ($limit !== null && $limit > 0) {
            $sql .= " LIMIT :limit OFFSET :offset";
            $params[':limit'] = (int)$limit;
            $params[':offset'] = (int)$offset;
        }

        try {
            $results = executeQuery($sql, $params);
            $reviews = [];
            foreach ($results as $data) {
                $review = new self($data);
                $review->product_object = new Product(['product_id' => $review->product_id, 'name' => $data['product_name'] ?? 'Prodotto Sconosciuto']);
                $reviews[] = $review;
            }
            return $reviews;
        } catch (PDOException $e) {
            error_log("Failed to get reviews by user ID {$userId}: " . $e->getMessage());
            throw $e;
        }
    }

    public static function countByUserId(int $userId): int {
         $sql = "SELECT COUNT(*) FROM Reviews WHERE user_id = :user_id";
         $params = [':user_id' => $userId];
         try {
              $result = executeQuery($sql, $params, false);
              return $result ? (int)$result['COUNT(*)'] : 0;
         } catch (PDOException $e) {
              error_log("Failed to count reviews for user ID {$userId}: " . $e->getMessage());
              throw $e;
         }
    }


    public static function userHasReviewedProduct(int $userId, int $productId): bool {
        $sql = "SELECT COUNT(*) FROM Reviews WHERE user_id = :user_id AND product_id = :product_id";
        $params = [':user_id' => $userId, ':product_id' => $productId];
        try {
            $result = executeQuery($sql, $params, false);
            return $result && (int)$result['COUNT(*)'] > 0;
        } catch (PDOException $e) {
            error_log("Failed to check if user {$userId} reviewed product {$productId}: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Gets all reviews, optionally filtered by approval status, with pagination.
     * Includes joined product name and username for display in admin panel.
     *
     * @param string|null $statusFilter 'approved', 'pending' (maps to is_approved=false), or null for all.
     * @param int|null $limit Optional pagination limit.
     * @param int $offset Optional pagination offset.
     * @param string $orderBy Column to order by.
     * @param string $orderDirection 'ASC' or 'DESC'.
     * @return array An array of Review objects.
     * @throws PDOException On database error.
     */
    public static function getAll(?string $statusFilter = null, ?int $limit = 10, int $offset = 0, string $orderBy = 'created_at', string $orderDirection = 'DESC'): array {
        $sql = "SELECT r.*, p.name AS product_name, u.username 
                FROM Reviews r 
                JOIN Products p ON r.product_id = p.product_id 
                JOIN Users u ON r.user_id = u.user_id";
        $params = [];
        $whereClauses = [];

        if ($statusFilter === 'approved') {
            $whereClauses[] = "r.is_approved = TRUE";
        } elseif ($statusFilter === 'pending') { // 'pending' or 'not_approved'
            $whereClauses[] = "r.is_approved = FALSE";
        }
        // No specific filter for 'rejected' separate from 'pending' with current schema.

        if (!empty($whereClauses)) {
            $sql .= " WHERE " . implode(" AND ", $whereClauses);
        }

        $allowedOrderBy = ['review_id', 'product_id', 'user_id', 'rating', 'is_approved', 'created_at', 'updated_at', 'product_name', 'username']; 
        $allowedOrderDirection = ['ASC', 'DESC'];

        $orderByCol = 'r.created_at'; 
        if (in_array(strtolower($orderBy), ['product_name', 'username'])) {
             $orderByCol = strtolower($orderBy); 
        } elseif (in_array(strtolower($orderBy), $allowedOrderBy)) {
             $orderByCol = 'r.' . strtolower($orderBy);
        }

        $orderDirection = in_array(strtoupper($orderDirection), $allowedOrderDirection) ? strtoupper($orderDirection) : 'DESC';
        $sql .= " ORDER BY {$orderByCol} {$orderDirection}, r.review_id {$orderDirection}";

        if ($limit !== null && $limit > 0) {
            $sql .= " LIMIT :limit OFFSET :offset";
            $params[':limit'] = (int)$limit;
            $params[':offset'] = (int)$offset;
        }

        try {
            $results = executeQuery($sql, $params);
            $reviews = [];
            foreach ($results as $data) {
                 $review = new self($data);
                $review->product_object = new Product(['product_id' => $review->product_id, 'name' => $data['product_name'] ?? 'Prodotto Sconosciuto']);
                $review->user_object = new User(['user_id' => $review->user_id, 'username' => $data['username'] ?? 'Utente Sconosciuto']);
                $reviews[] = $review;
            }
            return $reviews;
        } catch (PDOException $e) {
            error_log("Failed to get all reviews (Status Filter: {$statusFilter}): " . $e->getMessage() . " SQL: " . $sql . " Params: " . json_encode($params));
            throw $e;
        }
    }
    
     /**
     * Counts total reviews, optionally filtered by approval status.
     *
     * @param string|null $statusFilter 'approved', 'pending', or null for all.
     * @return int
     * @throws PDOException On database error.
     */
    public static function countAll(?string $statusFilter = null): int {
        $sql = "SELECT COUNT(*) FROM Reviews r"; // Alias r for consistency if joins were needed for filtering
        $params = [];
        $whereClauses = [];

        if ($statusFilter === 'approved') {
            $whereClauses[] = "r.is_approved = TRUE";
        } elseif ($statusFilter === 'pending') {
            $whereClauses[] = "r.is_approved = FALSE";
        }

        if (!empty($whereClauses)) {
            $sql .= " WHERE " . implode(" AND ", $whereClauses);
        }

        try {
            $result = executeQuery($sql, $params, false);
            return $result ? (int)$result['COUNT(*)'] : 0;
        } catch (PDOException $e) {
            error_log("Failed to count all reviews (Status Filter: {$statusFilter}): " . $e->getMessage());
            throw $e;
        }
    }

    public static function getPendingReviews(?int $limit = null, int $offset = 0): array {
        return self::getAll('pending', $limit, $offset, 'created_at', 'ASC');
    }

    public static function countPendingReviews(): int {
        return self::countAll('pending');
    }

     public static function getApprovedReviews(?int $limit = null, int $offset = 0): array {
        return self::getAll('approved', $limit, $offset, 'created_at', 'DESC'); 
    }

    public static function countApprovedReviews(): int {
         return self::countAll('approved');
    }

    /**
     * Saves the current review object to the database (Insert or Update).
     * For admin edits, ensure the rating is not changed by the admin form.
     * The rating is only set when a new review is created by a user.
     */
    public function save(): bool {
        if ($this->product_id <= 0 || $this->user_id <= 0 || empty(trim($this->comment_text))) {
            error_log("Attempted to save review with invalid core data. ProductID: {$this->product_id}, UserID: {$this->user_id}, Comment empty?");
            return false;
        }
        // Rating validation for new reviews
        if ($this->review_id === 0 && ($this->rating < 1 || $this->rating > 5)) {
             error_log("Attempted to save new review with invalid rating: {$this->rating}");
             return false;
        }

        $productIdToUpdateRating = $this->product_id;
        $isApprovedBeforeSave = null;
        if ($this->review_id > 0) {
            $existingReview = self::getById($this->review_id); // Fetch to check old is_approved status
            if ($existingReview) {
                $isApprovedBeforeSave = $existingReview->is_approved;
                // IMPORTANT: Preserve original rating and user_id for admin edits
                $this->rating = $existingReview->rating;
                $this->user_id = $existingReview->user_id;
                $this->product_id = $existingReview->product_id; // Product should not change on edit
            } else {
                error_log("Review ID {$this->review_id} not found during save (update) attempt!");
                return false; 
            }

            $sql = "UPDATE Reviews SET
                        comment_text = :comment_text,
                        pros = :pros,
                        cons = :cons,
                        is_approved = :is_approved,
                        updated_at = CURRENT_TIMESTAMP 
                        /* rating, user_id, product_id are NOT updated by admin edit of text/status */
                    WHERE review_id = :review_id";
             $params = [
                 ':comment_text' => $this->comment_text,
                 ':pros' => $this->pros,
                 ':cons' => $this->cons,
                 ':is_approved' => $this->is_approved ? 1 : 0, 
                 ':review_id' => $this->review_id
             ];
        } else {
            // Insert new review (typically by a user, is_approved defaults to false/pending)
            $sql = "INSERT INTO Reviews (product_id, user_id, rating, comment_text, pros, cons, is_approved, created_at, updated_at)
                    VALUES (:product_id, :user_id, :rating, :comment_text, :pros, :cons, :is_approved, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
             $params = [
                 ':product_id' => $this->product_id,
                 ':user_id' => $this->user_id,
                 ':rating' => $this->rating,
                 ':comment_text' => $this->comment_text,
                 ':pros' => $this->pros,
                 ':cons' => $this->cons,
                 // New reviews are typically pending approval (is_approved = false)
                 ':is_approved' => $this->is_approved ? 1 : 0 
             ];
        }

        try {
            $rowCount = executeQuery($sql, $params, false);

            if ($this->review_id === 0 && $rowCount > 0) {
                 $pdo = connectDB(); 
                 $this->review_id = (int)$pdo->lastInsertId();
            }
            
            // Update product average rating if approval status changed or a new approved review was added.
            $needsRatingUpdate = false;
            if ($rowCount > 0) {
                if ($isApprovedBeforeSave !== null) { // It's an update
                    if ($isApprovedBeforeSave != $this->is_approved) { // Status changed
                        $needsRatingUpdate = true;
                    }
                } else { // It's a new insert
                    if ($this->is_approved) { // New review is approved
                        $needsRatingUpdate = true;
                    }
                }
            }

            if ($needsRatingUpdate && $productIdToUpdateRating > 0) {
                 $productToUpdate = Product::getById($productIdToUpdateRating);
                 if ($productToUpdate) {
                     $productToUpdate->updateAverageRating();
                 }
            }
            return $rowCount > 0;
        } catch (PDOException $e) {
            error_log("Failed to save review (Product ID: {$this->product_id}, User ID: {$this->user_id}): " . $e->getMessage());
             if ($e->getCode() == '23000') { // Unique constraint violation
                 throw new PDOException("Errore: Hai già recensito questo prodotto o si è verificato un duplicato.", (int)$e->getCode(), $e);
             }
            throw $e;
        }
    }

    public function delete(): bool {
        if ($this->review_id <= 0) {
            error_log("Attempted to delete review with invalid ID: {$this->review_id}");
            return false;
        }
        
        // Fetch review details before deletion to update product rating correctly
        $reviewToDelete = self::getById($this->review_id);
        if (!$reviewToDelete) {
            error_log("Review ID {$this->review_id} not found for deletion.");
            return false; // Or true if "not found" means "already deleted"
        }
        $productIdToUpdateRating = $reviewToDelete->product_id;
        $wasApproved = $reviewToDelete->is_approved;

        $sql = "DELETE FROM Reviews WHERE review_id = :review_id";
        $params = [':review_id' => $this->review_id];
        try {
            $rowCount = executeQuery($sql, $params, false);
            if ($rowCount > 0 && $wasApproved && $productIdToUpdateRating > 0) {
                $productToUpdate = Product::getById($productIdToUpdateRating);
                if ($productToUpdate) {
                    $productToUpdate->updateAverageRating();
                }
            }
            return $rowCount > 0;
        } catch (PDOException $e) {
            error_log("Failed to delete review ID {$this->review_id}: " . $e->getMessage());
            throw $e;
        }
    }

    public function approve(): bool {
        if ($this->review_id <= 0) return false;
        
        $existingReview = self::getById($this->review_id);
        if (!$existingReview || $existingReview->is_approved) { // Not found or already approved
            if(!$existingReview) error_log("Approve review failed: Review ID {$this->review_id} not found.");
            return $existingReview ? $existingReview->is_approved : false; 
        }

        $this->is_approved = true; 
        // Use save method for consistency in updating and recalculating rating
        return $this->save();
    }

     public function reject(): bool { // This means setting is_approved to false
        if ($this->review_id <= 0) return false;

        $existingReview = self::getById($this->review_id);
        if (!$existingReview || !$existingReview->is_approved) { // Not found or already not approved
            if(!$existingReview) error_log("Reject review failed: Review ID {$this->review_id} not found.");
            return true; 
        }
        
        $this->is_approved = false;
        // Use save method for consistency
        return $this->save();
     }


    public function getProduct(): ?Product {
        if ($this->product_id <= 0) return null;
        if ($this->product_object === null || $this->product_object->product_id !== $this->product_id) {
            try {
                 $this->product_object = Product::getById($this->product_id);
            } catch (PDOException $e) {
                error_log("Error fetching product {$this->product_id} for review {$this->review_id}: " . $e->getMessage());
                // Return a placeholder to avoid breaking UIs expecting an object
                $this->product_object = new Product(['product_id' => $this->product_id, 'name' => 'Prodotto Sconosciuto']);
            }
        }
        return $this->product_object;
    }

    public function getUser(): ?User {
        if ($this->user_id <= 0) return null;
        if ($this->user_object === null || $this->user_object->user_id !== $this->user_id || empty($this->user_object->username)) {
             try {
                $this->user_object = User::getById($this->user_id);
                if (!$this->user_object) { // If user not found (e.g. deleted)
                    $this->user_object = new User(['user_id' => $this->user_id, 'username' => 'Utente Sconosciuto']);
                }
             } catch (PDOException $e) {
                 error_log("Error fetching user {$this->user_id} for review {$this->review_id}: " . $e->getMessage());
                 $this->user_object = new User(['user_id' => $this->user_id, 'username' => 'Utente Sconosciuto']); 
             }
        }
        return $this->user_object;
    }
}



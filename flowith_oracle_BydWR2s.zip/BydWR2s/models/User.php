<?php
// models/User.php

require_once __DIR__ . '/../config/db.php';

/**
 * Represents the User data model and provides database interaction methods.
 */
class User {
    public int $user_id;
    public string $username;
    public string $email;
    private string $password_hash; // Keep hash private, only load when necessary
    public string $role; // e.g., 'user', 'admin'
    public string $created_at;

    /**
     * Constructor
     * @param array $data An associative array of user data, typically fetched from the database.
     */
    public function __construct(array $data) {
        $this->user_id = isset($data['user_id']) ? (int)$data['user_id'] : 0;
        $this->username = $data['username'] ?? '';
        $this->email = $data['email'] ?? '';
        $this->password_hash = $data['password_hash'] ?? ''; // May not always be present
        $this->role = $data['role'] ?? 'user';
        $this->created_at = $data['created_at'] ?? ''; // Set by DB
    }

     /**
     * Gets a single user by their ID. Includes password hash.
     *
     * @param int $id The user ID.
     * @return User|null The User object if found, null otherwise.
     * @throws PDOException On database error.
     */
    public static function getById(int $id): ?User {
        // Select password_hash as it's needed for operations like changing password or verifying if re-fetched
        $sql = "SELECT user_id, username, email, password_hash, role, created_at FROM Users WHERE user_id = :user_id";
        $params = [':user_id' => $id];

        try {
            $result = executeQuery($sql, $params, false); // fetch single row
            return $result ? new self($result) : null;
        } catch (PDOException $e) {
            error_log("Failed to get user by ID {$id}: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Gets a single user by their username. Includes password hash for login verification.
     *
     * @param string $username The username.
     * @return User|null The User object if found, null otherwise.
     * @throws PDOException On database error.
     */
    public static function getByUsername(string $username): ?User {
         $sql = "SELECT user_id, username, email, password_hash, role, created_at FROM Users WHERE username = :username";
         $params = [':username' => $username];

         try {
             $result = executeQuery($sql, $params, false);
             return $result ? new self($result) : null;
         } catch (PDOException $e) {
             error_log("Failed to get user by username '{$username}': " . $e->getMessage());
             throw $e;
         }
    }

    /**
     * Gets a single user by their email. Includes password hash for login verification.
     *
     * @param string $email The email address.
     * @return User|null The User object if found, null otherwise.
     * @throws PDOException On database error.
     */
    public static function getByEmail(string $email): ?User {
         $sql = "SELECT user_id, username, email, password_hash, role, created_at FROM Users WHERE email = :email";
         $params = [':email' => $email];

         try {
             $result = executeQuery($sql, $params, false);
             return $result ? new self($result) : null;
         } catch (PDOException $e) {
             error_log("Failed to get user by email '{$email}': " . $e->getMessage());
             throw $e;
         }
    }

     /**
     * Gets all users. Excludes password hash for security.
     * This is suitable for listing users in admin panels where passwords are not displayed.
     * If pagination is needed, use getAllPaginated.
     *
     * @return array An array of User objects.
     * @throws PDOException On database error.
     */
    public static function getAll(): array {
        $sql = "SELECT user_id, username, email, role, created_at FROM Users ORDER BY created_at DESC";
        try {
            $results = executeQuery($sql);
            $users = [];
            foreach ($results as $data) {
                // Note: password_hash will be empty as it's not selected
                $users[] = new self($data);
            }
            return $users;
        } catch (PDOException $e) {
            error_log("Failed to get all users: " . $e->getMessage());
            throw $e;
        }
    }

      /**
     * Gets users with pagination. Excludes password hash for security.
     *
     * @param int|null $limit Optional limit for pagination.
     * @param int $offset Optional offset for pagination.
     * @param string $orderBy Column to order by.
     * @param string $orderDirection 'ASC' or 'DESC'.
     * @return array An array of User objects.
     * @throws PDOException On database error.
     */
    public static function getAllPaginated(?int $limit = 10, int $offset = 0, string $orderBy = 'created_at', string $orderDirection = 'DESC'): array {
        // Validate orderBy and orderDirection
        $allowedOrderBy = ['user_id', 'username', 'email', 'role', 'created_at'];
        $allowedOrderDirection = ['ASC', 'DESC'];
        $orderBy = in_array(strtolower($orderBy), $allowedOrderBy) ? strtolower($orderBy) : 'created_at';
        $orderDirection = in_array(strtoupper($orderDirection), $allowedOrderDirection) ? strtoupper($orderDirection) : 'DESC';


        $sql = "SELECT user_id, username, email, role, created_at FROM Users ORDER BY {$orderBy} {$orderDirection}";
        $params = [];

        if ($limit !== null && $limit > 0) {
             $sql .= " LIMIT :limit OFFSET :offset";
             $params[':limit'] = (int)$limit;
             $params[':offset'] = (int)$offset;
        }

        try {
            $results = executeQuery($sql, $params);
            $users = [];

            foreach ($results as $data) {
                $users[] = new self($data);
            }
            return $users;
        } catch (PDOException $e) {
            error_log("Failed to get all users (paginated): " . $e->getMessage() . " SQL: " . $sql . " Params: " . json_encode($params));
            throw $e;
        }
    }

    /**
     * Counts total users.
     * @return int
     * @throws PDOException
     */
    public static function countAll(): int {
        $sql = "SELECT COUNT(*) FROM Users";
        try {
            $result = executeQuery($sql, [], false);
            return $result ? (int)$result['COUNT(*)'] : 0;
        } catch (PDOException $e) {
             error_log("Failed to count all users: " . $e->getMessage());
             throw $e;
        }
    }


    /**
     * Saves the current user object to the database (Insert or Update).
     * Use setPassword() before saving a new user or when updating the password.
     *
     * @return bool True on success, false on failure.
     * @throws PDOException On database error (e.g., unique constraint violation for username/email).
     */
    public function save(): bool {
        // Basic validation
        if (empty(trim($this->username)) || empty(trim($this->email))) {
            error_log("Attempted to save user with empty username or email.");
            return false;
        }
        if (!filter_var($this->email, FILTER_VALIDATE_EMAIL)) {
             error_log("Attempted to save user with invalid email: {$this->email}");
             return false;
        }


        if ($this->user_id > 0) {
            // Update existing user
            // Only include password_hash in the update if it's explicitly set (meaning it changed)
            $updateFields = ['username = :username', 'email = :email', 'role = :role'];
            $params = [
                ':username' => $this->username,
                ':email' => $this->email,
                ':role' => $this->role,
                ':user_id' => $this->user_id
            ];

            if (!empty($this->password_hash) && $this->password_hash !== (User::getById($this->user_id))->password_hash) { // Check if hash actually changed
                $updateFields[] = 'password_hash = :password_hash';
                $params[':password_hash'] = $this->password_hash;
            }

            $sql = "UPDATE Users SET " . implode(', ', $updateFields) . " WHERE user_id = :user_id";

        } else {
            // Insert new user
            if (empty($this->password_hash)) {
                 error_log("Cannot save new user: password hash is not set.");
                 // Consider throwing an exception: throw new InvalidArgumentException("Password hash must be set for new users.");
                 return false;
            }
            $sql = "INSERT INTO Users (username, email, password_hash, role) VALUES (:username, :email, :password_hash, :role)";
            $params = [
                ':username' => $this->username,
                ':email' => $this->email,
                ':password_hash' => $this->password_hash,
                ':role' => $this->role
            ];
        }

        try {
            $rowCount = executeQuery($sql, $params, false);
            if ($this->user_id === 0 && $rowCount > 0) {
                 $pdo = connectDB();
                $this->user_id = (int)$pdo->lastInsertId();
            }
            return $rowCount > 0;
        } catch (PDOException $e) {
            error_log("Failed to save user (ID: {$this->user_id}, Username: {$this->username}): " . $e->getMessage());
            // Specific check for unique constraint violation (MySQL error code 23000, SQLSTATE 23000)
            if ($e->getCode() == '23000') {
                // You can check $e->getMessage() for specific constraint name if needed
                // e.g. if (str_contains($e->getMessage(), 'username_UNIQUE'))
                 $message = "Nome utente o email già esistente.";
                if (stripos($e->getMessage(), 'username') !== false || stripos($e->getMessage(), $this->username) !== false) { // check for username constraint
                     $message = "Nome utente '" . htmlspecialchars($this->username) . "' già in uso.";
                } elseif (stripos($e->getMessage(), 'email') !== false || stripos($e->getMessage(), $this->email) !== false) { // check for email constraint
                    $message = "Email '" . htmlspecialchars($this->email) . "' già registrata.";
                }
                throw new PDOException($message, (int)$e->getCode(), $e);
            }
            throw $e; // Re-throw general database errors
        }
    }

    /**
     * Updates only the role of the user.
     *
     * @param string $newRole The new role to set ('user', 'admin').
     * @return bool True on success, false on failure or if no rows affected.
     * @throws PDOException On database error.
     */
    public function updateRole(string $newRole): bool {
        if ($this->user_id <= 0 || !in_array($newRole, ['user', 'admin'])) {
             error_log("Attempted to update role for user ID {$this->user_id} with invalid role '{$newRole}'.");
             return false;
        }
        if ($this->role === $newRole) {
             return true; // No change needed
        }

        $sql = "UPDATE Users SET role = :role WHERE user_id = :user_id";
        $params = [
            ':role' => $newRole,
            ':user_id' => $this->user_id
        ];

        try {
            $rowCount = executeQuery($sql, $params, false);
            if ($rowCount > 0) {
                 $this->role = $newRole; // Update object property on success
            }
            return $rowCount > 0;
        } catch (PDOException $e) {
            error_log("Failed to update role for user ID {$this->user_id} to '{$newRole}': " . $e->getMessage());
            throw $e;
        }
    }


    /**
     * Hashes a password and sets it to the object's password_hash property.
     * Use before calling save() for new users or password updates.
     *
     * @param string $password The plain text password.
     * @return void
     */
    public function setPassword(string $password): void {
        if (empty(trim($password))) {
            // Optionally throw an error or log if password is empty
            error_log("Attempted to set an empty password for user ID {$this->user_id}.");
            // Depending on policy, you might throw an InvalidArgumentException
            return; // Or allow it and let validation on save catch it
        }
        $this->password_hash = password_hash($password, PASSWORD_DEFAULT);
    }

    /**
     * Verifies a plain text password against the stored hash.
     *
     * @param string $password The plain text password to verify.
     * @return bool True if the password matches the hash, false otherwise.
     */
    public function verifyPassword(string $password): bool {
        if (empty($this->password_hash)) {
            // This can happen if the user object was instantiated without fetching the password_hash
            // e.g., from User::getAll() or if a new User object was created and password not set.
            // Try to fetch the user with hash if it's missing and ID is available
            if ($this->user_id > 0) {
                $userWithHash = User::getById($this->user_id);
                if ($userWithHash && !empty($userWithHash->password_hash)) {
                    $this->password_hash = $userWithHash->password_hash;
                } else {
                     error_log("Attempted to verify password for user '{$this->username}' (ID: {$this->user_id}) but password_hash could not be loaded.");
                     return false;
                }
            } else {
                error_log("Attempted to verify password for user '{$this->username}' (ID: {$this->user_id}) but password_hash was not loaded or set, and user ID is not available for fetching.");
                return false;
            }
        }
        return password_verify($password, $this->password_hash);
    }

     /**
     * Deletes the current user object from the database.
     * Related reviews and votes will be automatically deleted due to ON DELETE CASCADE constraints
     * in the Reviews table (FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE).
     * Review_Votes also has ON DELETE CASCADE for user_id.
     *
     * @return bool True on success, false on failure.
     * @throws PDOException On database error.
     */
     public function delete(): bool {
        if ($this->user_id <= 0) {
            error_log("Attempted to delete user with invalid ID: {$this->user_id}");
            return false;
        }

        // Additional check: prevent admin from deleting themselves if they are the only admin.
        // This logic is better placed in the controller/page script handling the delete action.
        // For now, the model method just performs the deletion.

        $pdo = connectDB();
        try {
            $pdo->beginTransaction();

            // Before deleting user, handle related data if ON DELETE CASCADE is not fully trusted or applicable for all relations.
            // For Reviews and Review_Votes, the DB schema (as inferred from User Story) should handle CASCADE.
            // If there were other tables, manual deletion might be needed here.

            $sql = "DELETE FROM Users WHERE user_id = :user_id";
            $params = [':user_id' => $this->user_id];
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $rowCount = $stmt->rowCount();
            
            $pdo->commit();
            return $rowCount > 0;

        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Failed to delete user ID {$this->user_id}: " . $e->getMessage());
            throw $e;
        }
     }

     /**
      * Check if the user has a specific role.
      *
      * @param string $roleToCheck The role to check against, e.g., 'admin'.
      * @return bool
      */
     public function hasRole(string $roleToCheck): bool {
         return strtolower($this->role) === strtolower($roleToCheck);
     }
}



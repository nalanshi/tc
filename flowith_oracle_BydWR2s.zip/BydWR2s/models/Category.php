<?php
// models/Category.php

require_once __DIR__ . '/../config/db.php';

/**
 * Represents the Category data model and provides database interaction methods.
 */
class Category {
    public int $category_id;
    public string $name;
    public ?string $description;

    /**
     * Constructor
     * @param array $data An associative array of category data, typically fetched from the database.
     */
    public function __construct(array $data) {
        $this->category_id = isset($data['category_id']) ? (int)$data['category_id'] : 0;
        $this->name = $data['name'] ?? '';
        $this->description = $data['description'] ?? null;
    }

    /**
     * Gets a single category by its ID.
     *
     * @param int $id The category ID.
     * @return Category|null The Category object if found, null otherwise.
     * @throws PDOException On database error.
     */
    public static function getById(int $id): ?Category {
        $sql = "SELECT * FROM Categories WHERE category_id = :category_id";
        $params = [':category_id' => $id];

        try {
            $result = executeQuery($sql, $params, false); // fetch single row
            return $result ? new self($result) : null;
        } catch (PDOException $e) {
            error_log("Failed to get category by ID {$id}: " . $e->getMessage());
            throw $e; // Re-throw for controller/caller to handle
        }
    }

    /**
     * Gets all categories.
     *
     * @param string $orderBy Column to order by (e.g., 'name').
     * @param string $orderDirection Direction ('ASC' or 'DESC').
     * @return array An array of Category objects.
     * @throws PDOException On database error.
     */
    public static function getAll(string $orderBy = 'name', string $orderDirection = 'ASC'): array {
        // Validate orderBy and orderDirection
        $allowedOrderBy = ['category_id', 'name'];
        $allowedOrderDirection = ['ASC', 'DESC'];
        $orderBy = in_array($orderBy, $allowedOrderBy) ? $orderBy : 'name';
        $orderDirection = in_array(strtoupper($orderDirection), $allowedOrderDirection) ? strtoupper($orderDirection) : 'ASC';

        $sql = "SELECT * FROM Categories ORDER BY {$orderBy} {$orderDirection}";

        try {
            $results = executeQuery($sql); // fetch all
            $categories = [];
            foreach ($results as $data) {
                $categories[] = new self($data);
            }
            return $categories;
        } catch (PDOException $e) {
            error_log("Failed to get all categories: " . $e->getMessage());
            throw $e; // Re-throw for controller/caller to handle
        }
    }

    /**
     * Saves the current category object to the database (Insert or Update).
     *
     * @return bool True on success, false on failure or if no rows affected.
     * @throws PDOException On database error.
     */
    public function save(): bool {
        // Basic validation
        if (empty(trim($this->name))) {
            // Optionally throw an InvalidArgumentException or return false
            error_log("Attempted to save category with empty name.");
            return false;
        }

        if ($this->category_id > 0) {
            // Update existing category
            $sql = "UPDATE Categories SET name = :name, description = :description WHERE category_id = :category_id";
            $params = [
                ':name' => $this->name,
                ':description' => $this->description, // Can be null
                ':category_id' => $this->category_id
            ];
        } else {
            // Insert new category
            $sql = "INSERT INTO Categories (name, description) VALUES (:name, :description)";
            $params = [
                ':name' => $this->name,
                ':description' => $this->description // Can be null
            ];
        }

        try {
            $rowCount = executeQuery($sql, $params, false); // DML query
            if ($this->category_id === 0 && $rowCount > 0) {
                // Get the last inserted ID for new categories
                $pdo = connectDB(); // Get a new connection for lastInsertId, or pass existing one
                $this->category_id = (int)$pdo->lastInsertId();
            }
            return $rowCount > 0;
        } catch (PDOException $e) {
            error_log("Failed to save category (ID: {$this->category_id}, Name: {$this->name}): " . $e->getMessage());
            throw $e; // Re-throw for controller/caller to handle
        }
    }

    /**
     * Deletes the current category object from the database.
     * Note: Products referencing this category might have their category_id set to NULL
     * due to the `ON DELETE SET NULL` constraint in the Products table.
     *
     * @return bool True on success, false on failure or if no rows affected.
     * @throws PDOException On database error.
     */
    public function delete(): bool {
        if ($this->category_id <= 0) {
            error_log("Attempted to delete category with invalid ID: {$this->category_id}");
            return false; // Cannot delete a category that doesn't exist (ID <= 0)
        }

        $sql = "DELETE FROM Categories WHERE category_id = :category_id";
        $params = [':category_id' => $this->category_id];

        try {
            $rowCount = executeQuery($sql, $params, false); // DML query
            return $rowCount > 0;
        } catch (PDOException $e) {
            error_log("Failed to delete category ID {$this->category_id}: " . $e->getMessage());
            throw $e; // Re-throw in case the caller needs to handle (e.g., display specific error)
        }
    }

    /**
     * Counts the number of products associated with this category.
     *
     * @return int The number of products in this category.
     * @throws PDOException On database error.
     */
    public function getProductCount(): int {
        if ($this->category_id <= 0) {
            return 0;
        }
        $sql = "SELECT COUNT(*) FROM Products WHERE category_id = :category_id";
        $params = [':category_id' => $this->category_id];
        try {
            $result = executeQuery($sql, $params, false);
            return $result ? (int)$result['COUNT(*)'] : 0;
        } catch (PDOException $e) {
            error_log("Failed to count products for category ID {$this->category_id}: " . $e->getMessage());
            throw $e;
        }
    }
}







